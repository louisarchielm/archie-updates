"""Archie working by himself while the app is open: watches the mail and the agenda, and tells the owner
(on screen and out loud, by text message, or by phone call when it is urgent)."""
import json
import os
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

from . import knowledge, lessons, memory, notify

SEEN = Path("archie-notified.json")
NOTICES = []
STATUS = {"mail": None, "agenda": None, "last": 0.0}
_L = threading.Lock()


def _seen():
    try:
        return set(json.loads(SEEN.read_text()))
    except (OSError, ValueError):
        return set()


def _remember(keys):
    SEEN.write_text(json.dumps(sorted(keys)[-500:]))


def push(text, level="normal"):
    with _L:
        NOTICES.append({"text": text, "level": level, "lang": memory.get_lang()})


def take():
    with _L:
        out = NOTICES[:]
        NOTICES.clear()
    return out


CRIT = """Email received by {owner}. From: {sender}. Subject: {subject}.
{body}
This sender is one of his BIGGEST clients. Is this email truly critical: a large contract, a signature or decision needed within hours, a big amount, or a risk of losing this client today? Routine questions, thanks, newsletters, scheduling and small requests are NOT critical.
JSON only: {{"critical": true or false}}"""


def book_followup(title, minutes=15, notes="Ajouté par Archie. Provisoire, déplaçable."):
    """Puts a task in the agenda at the first free slot (days run 7:00 to 18:00). Returns the start or None."""
    from . import icloud

    now = datetime.now(icloud.TZ)
    for k in range(0, 8):
        day = (now + timedelta(days=k)).date()
        for s in icloud.free_slots(day, minutes):
            if s >= now + timedelta(minutes=20):
                icloud.add_event(title, s, minutes, notes)
                return s
    return None


def _when(s, fr):
    from . import icloud

    today = datetime.now(icloud.TZ).date()
    d = "aujourd'hui" if s.date() == today else "demain" if (s.date() - today).days == 1 else s.strftime("%A")
    if not fr:
        d = "today" if s.date() == today else "tomorrow" if (s.date() - today).days == 1 else s.strftime("%A")
        return f"{d} at {s.strftime('%I:%M %p').lstrip('0')}"
    return f"{d} à {s.hour} h" + (f" {s.minute:02d}" if s.minute else "")


def _ask_vip(who, fr):
    from . import clients

    lab = clients.label(fr)
    push((f"{who} vous écrit pour la première fois. Est-ce un {lab} ? Répondez oui ou non."
          if fr else f"{who} is writing to you for the first time. Is this a {lab}? Answer yes or no."), "normal")


def check_mail():
    from . import brain, clients, inbox, mailbox

    try:
        mails = mailbox.fetch_new(10)
    except BaseException as e:  # SystemExit means mail is not set up
        STATUS["mail"] = str(e)[:140] or type(e).__name__
        return
    STATUS["mail"] = "ok"
    first = not Path("archie-autopilot-started").exists()  # the first pass only learns what is already there: no texts, no calls
    if first:
        Path("archie-autopilot-started").write_text("1")
    fr = memory.get_lang() == "fr"
    owner = os.environ.get("OWNER_NAME", "the owner")
    for m in mails:
        try:
            from . import prospect

            if prospect.is_prospect(m["from"]) and prospect.STOP_RE.search((m["body"] or "")[:300]):  # a prospect asked to stop: never write to them again
                prospect.optout(m["from"])
                push((f"{m['from_name'] or m['from']} demande de ne plus recevoir de messages : je ne leur \u00e9crirai plus." if fr
                      else f"{m['from_name'] or m['from']} asked to stop: I will not write to them again."), "normal")
        except BaseException:
            pass
        t = inbox.triage(m)
        if t["category"] == "ignore":
            continue
        who = m["from_name"] or m["from"]
        summary = (t.get("summary") or "").strip()
        draft = (t.get("draft") or "").strip()
        memory.remember("email", f"From {who} <{m['from']}>, subject '{m['subject']}' ({t['category']}): {summary}"
                        + (f" Draft prepared: {draft[:300]}" if draft else ""), "email")
        knowledge.add_text(f"mail:{m['uid']}", f"Email de {who}: {m['subject']}", m["body"], "mail")
        if draft:
            with inbox.LOCK:
                d = inbox._drafts()
                d[str(m["uid"])] = {"to": m["from"], "subject": m["subject"], "draft": draft, "message_id": m["message_id"],
                                    "graph_id": m.get("graph_id", ""), "status": "pending"}
                inbox._save(d)
        if first:
            clients.mark_seen(m["from"], m["from_name"])  # already in the inbox: not a newcomer
        if first or t["category"] == "fyi":
            continue  # nothing to tell for now
        newcomer = clients.first_contact(m["from_name"], m["from"])  # a real mail from someone new
        critical = False
        if t["category"] == "urgent" and clients.is_big(m["from_name"], m["from"]):
            c = brain.ask_json(CRIT.format(owner=owner, sender=f"{who} <{m['from']}>", subject=m["subject"], body=m["body"][:1500]),
                               "You judge email urgency strictly. JSON only.", max_tokens=60)
            critical = bool(c and c.get("critical") is True)
        base = ((f"{who} : {summary}" if fr else f"{who}: {summary}").rstrip(".") + ".")
        if critical:
            text = ("Très urgent, " if fr else "Very urgent, ") + base
            notify.route("urgent", text)  # phone call + text: only for a big client and a critical email
            push(text, "urgent")
            continue  # (a priority client is never a newcomer)
        # everything else: a text, and a task in the agenda
        try:
            s = book_followup((f"Répondre à {who}" if fr else f"Reply to {who}") + f" - {m['subject']}"[:60])
        except BaseException:
            s = None
        text = base + ((" Ajouté à votre agenda : " + _when(s, True) + ".") if (s and fr) else (" Added to your agenda: " + _when(s, False) + ".") if s else "")
        notify.route("normal", text)
        push(text, "normal")
        if newcomer:
            _ask_vip(who, fr)
            try:
                from . import research

                research.start(m['from_name'], m['from'], m['subject'], m['body'], fr, owner, push, notify.route,
                               lambda t: memory.remember('email', t, 'research'), t['category'])
            except BaseException:
                pass


def check_agenda():
    try:
        from . import icloud

        now = datetime.now(icloud.TZ)
        evs = icloud.events(now, now + timedelta(minutes=25))
    except BaseException as e:
        STATUS["agenda"] = str(e)[:140] or type(e).__name__
        return
    STATUS["agenda"] = "ok"
    seen = _seen()
    fr = memory.get_lang() == "fr"
    for e in evs:
        if not e["timed"] or e["start"] < now:
            continue
        key = f"ev|{e['title']}|{e['start']:%Y%m%d%H%M}"
        if key in seen:
            continue
        seen.add(key)
        mins = max(1, int((e["start"] - now).total_seconds() // 60))
        text = (f"Dans {mins} minutes : {e['title']}." if fr else f"In {mins} minutes: {e['title']}.")
        notify.route("normal", text)
        push(text, "normal")
    _remember(seen)


def loop():
    time.sleep(25)
    every = max(1, float(os.environ.get("ARCHIE_CHECK_MIN", "3"))) * 60
    while True:
        if not __import__("archie.license", fromlist=["x"]).active():  # not activated: no background work
            time.sleep(every)
            continue
        for fn in (check_mail, check_agenda):
            try:
                fn()
            except BaseException as e:
                print("Autopilot:", fn.__name__, str(e)[:120], flush=True)
                lessons.record_failure("autopilot " + fn.__name__, e)
        STATUS["last"] = time.time()
        if time.time() - STATUS.get("review", 0) > 6 * 3600:  # now and then: what went wrong lately, and what to do differently
            STATUS["review"] = time.time()
            try:
                lessons.review()
            except BaseException:
                pass
        if time.time() - STATUS.get("selfimprove", 0) > 3600:  # once a day Archie reviews his own conversations and improves himself
            STATUS["selfimprove"] = time.time()
            try:
                from . import selfimprove

                if selfimprove.due():
                    selfimprove.review()
            except BaseException as e:
                print("Self-review:", str(e)[:120], flush=True)
        time.sleep(every)


def start():
    if os.environ.get("ARCHIE_AUTOPILOT", "1") != "0":
        threading.Thread(target=loop, daemon=True).start()
