"""Alarms: stored in a small file, rung by the Archie window (music + his voice). Times use ARCHIE_TZ."""
import json
import os
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path
from zoneinfo import ZoneInfo

FILE = Path(__file__).resolve().parent.parent / "archie-alarms.json"
LOCK = threading.Lock()
RING_SECONDS = 600


def tz():
    return ZoneInfo(os.environ.get("ARCHIE_TZ", "America/Toronto"))


def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(items):
    FILE.write_text(json.dumps(items), encoding="utf-8")


def add(when, repeat="none", label="", kind="wake"):
    """when: aware datetime. repeat: none | daily | weekdays. kind: wake (full wake-up speech), alarm (a time of day: a short 'it is 7 AM'), timer (a length of time: 'your timer is done')."""
    with LOCK:
        items = _load()
        a = {"id": str(time.time_ns()), "t": when.timestamp(), "repeat": repeat if repeat in ("daily", "weekdays") else "none",
             "label": label, "status": "armed", "sent": 0, "kind": kind if kind in ("wake", "alarm", "timer") else "wake"}
        items.append(a)
        _save(items)
    return a


def active():
    with LOCK:
        return [a for a in _load() if a["status"] in ("armed", "ringing")]


def cancel_all():
    with LOCK:
        items = _load()
        n = sum(a["status"] in ("armed", "ringing") for a in items)
        _save([a for a in items if a["status"] not in ("armed", "ringing")])
    return n


def _next(a, now):
    """After a ring: the next time for repeating alarms, otherwise done."""
    if a["repeat"] == "none":
        a["status"] = "done"
        return
    dt = datetime.fromtimestamp(a["t"], tz())
    while dt.timestamp() <= now or (a["repeat"] == "weekdays" and dt.weekday() >= 5):
        dt += timedelta(days=1)
    a["t"], a["status"], a["sent"] = dt.timestamp(), "armed", 0


def due(now=None):
    """The alarm that should be ringing now (or None). Hands the same ringing alarm out again every 60 s."""
    now = now or time.time()
    with LOCK:
        items = _load()
        out = None
        for a in items:
            if a["status"] == "armed" and a["t"] <= now:
                if now - a["t"] > 1800:  # PC was off or asleep: too late to ring
                    _next(a, now)
                    continue
                a["status"], a["ring"], a["sent"] = "ringing", now, 0
            if a["status"] == "ringing":
                if now - a.get("ring", now) > RING_SECONDS:
                    _next(a, now)
                    continue
                if now - a.get("sent", 0) >= 60 and out is None:
                    a["sent"] = now
                    out = dict(a)
        _save(items)
    return out


def pending_due(now=None):
    now = now or time.time()
    return any(a["status"] == "ringing" or (a["status"] == "armed" and a["t"] <= now) for a in active())


def dismiss(alarm_id):
    with LOCK:
        items = _load()
        for a in items:
            if a["id"] == alarm_id:
                _next(a, time.time())
        _save(items)


def snooze(alarm_id, minutes=9):
    with LOCK:
        items = _load()
        for a in items:
            if a["id"] == alarm_id:
                a["t"], a["status"], a["sent"] = time.time() + minutes * 60, "armed", 0
        _save(items)


_JOURS = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]


def describe(a, lang):
    dt = datetime.fromtimestamp(a["t"], tz())
    rep = {"daily": (" tous les jours", " every day"), "weekdays": (" en semaine", " on weekdays")}.get(a["repeat"], ("", ""))
    if lang == "fr":
        return f"{_JOURS[dt.weekday()]} à {dt.hour} h {dt.minute:02d}{rep[0]}"
    return f"{dt.strftime('%A')} at {dt.strftime('%I:%M %p').lstrip('0')}{rep[1]}"
