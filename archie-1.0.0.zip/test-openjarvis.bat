@echo off
rem Tries OpenJarvis on this PC in its own test folder. Nothing else is changed.
cd /d "%~dp0"
if exist .oj-test rmdir /s /q .oj-test
py -3.12 -m venv .oj-test
call .oj-test\Scripts\activate.bat
pip install OpenJarvis==1.0.2 > oj-test.log 2>&1
if errorlevel 1 (
  echo INSTALL FAILED. Tell Claude. Last lines:
  powershell -command "Get-Content oj-test.log -Tail 15"
  pause
  exit /b 1
)
echo INSTALL OK
jarvis --help > oj-help.txt 2>&1
jarvis doctor >> oj-help.txt 2>&1
type oj-help.txt
echo.
echo Done. Take a screenshot of this window and send it to Claude.
pause
