@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
pip uninstall -y niquests urllib3-future >nul 2>&1
pip install --force-reinstall "caldav==1.4.0" requests
echo.
echo Now run test-calendar.bat again.
pause
