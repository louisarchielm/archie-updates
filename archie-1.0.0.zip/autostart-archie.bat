@echo off
cd /d "%~dp0"
echo Making Archie start by itself when this PC starts...
powershell -NoProfile -Command "$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\Archie.lnk'); $s.TargetPath='%~dp0open-archie-app.bat'; $s.WorkingDirectory='%~dp0'; $s.WindowStyle=7; $s.Save()"
if errorlevel 1 (echo Something went wrong. Tell Claude.) else (echo Done. Archie will open by itself at every start. To undo, run remove-autostart.bat)
pause
