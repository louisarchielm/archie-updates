@echo off
cd /d "%~dp0"
echo Copy each value from your Twilio dashboard. Phone numbers must start with + and the country code, like +15145551234
set /p A=Paste your Account SID (starts with AC), then press Enter: 
set /p T=Paste your Auth Token, then press Enter: 
set /p F=Type your Twilio phone number (+1...), then press Enter: 
set /p M=Type YOUR cell phone number (+1...), then press Enter: 
setx TWILIO_ACCOUNT_SID "%A%" >nul
setx TWILIO_AUTH_TOKEN "%T%" >nul
setx TWILIO_FROM "%F%" >nul
setx MY_PHONE "%M%" >nul
echo.
echo Saved. CLOSE this window, then run test-call.bat.
pause
