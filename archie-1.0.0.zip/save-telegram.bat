@echo off
cd /d "%~dp0"
echo Create a bot with BotFather in Telegram, send it any message, then fill in below.
set /p T=Paste Archie's bot token, then press Enter: 
set /p C=Type the Telegram chat id (Claude will help you find it), then press Enter: 
setx ARCHIE_BOT_TOKEN "%T%" >nul
setx TELEGRAM_CHAT_ID "%C%" >nul
echo Saved. Close this window.
pause
