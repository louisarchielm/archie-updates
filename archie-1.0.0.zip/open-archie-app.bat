@echo off
cd /d "%~dp0"
echo Closing any old Archie window...
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":8765 " ^| findstr LISTENING') do taskkill /F /PID %%p >nul 2>&1
call .venv\Scripts\activate.bat
echo Archie is starting... a window will open. Keep THIS window open while you use Archie.
python -m pip install -q pypdf requests caldav edge-tts msal >nul 2>&1
python -m archie app
pause
