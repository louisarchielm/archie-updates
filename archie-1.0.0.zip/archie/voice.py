"""Archie's voice: British English (Ryan) and Quebec French (Antoine), picked by the language of the text."""
import asyncio
import re
import tempfile
from pathlib import Path

VOICES = {"en": "en-GB-RyanNeural", "fr": "fr-CA-AntoineNeural"}
_FR_WORDS = {"le", "la", "les", "des", "un", "une", "et", "est", "vous", "je", "bonjour", "rendez-vous",
             "courriel", "pour", "avec", "que", "pas", "dans", "mon", "ma", "nous", "merci", "aujourd'hui"}


def language(text, default="en"):
    """Very small language check: French if it has accents or several common French words."""
    words = re.findall(r"[a-zà-ÿ'’-]+", text.lower())
    hits = sum(w in _FR_WORDS for w in words)
    if re.search(r"[àâçéèêëîïôûùüÿœ]", text.lower()) or hits >= 2:
        return "fr"
    return default if words else default


def speak_to_file(text, lang=None, out=None):
    """Writes an mp3 of Archie saying the text. Needs internet and `pip install edge-tts`."""
    import edge_tts

    lang = lang or language(text)
    out = Path(out) if out else Path(tempfile.gettempdir()) / f"archie-{lang}.mp3"
    asyncio.run(edge_tts.Communicate(text, VOICES[lang]).save(str(out)))
    return out
