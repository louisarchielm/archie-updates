"""Archie's big memory of the PC: the text of the owner's documents (and emails), searchable, so every answer can point to its source.
Local only (archie-knowledge.db). Off until the owner says yes; one sentence turns it off and erases it."""
import os
import re
import sqlite3
import threading
import time
from pathlib import Path

from . import pcaccess

DB = Path("archie-knowledge.db")
FLAG = Path("archie-knowledge-on")
EXT = {".txt", ".md", ".csv", ".json", ".log", ".rtf", ".docx", ".pdf"}
SKIP_DIR = re.compile(r"^(\.|node_modules$|__pycache__$|appdata$|\$recycle)", re.I)
# never read what looks like a secret
SENSITIVE = re.compile(r"(password|passwd|mots?.{0,2}de.{0,2}passe|secret|token|credential|api.?key|\.env|id_rsa|keepass|\.kdbx|wallet|seed.?phrase|recovery.?code|2fa|backup.?code|\bnas\b|\bsin\b|passport|passeport|banking|bank.?login)", re.I)
_L = threading.Lock()
STATE = {"running": False, "last": 0.0, "added": 0, "error": ""}


def enabled():
    return FLAG.exists()


def set_enabled(on):
    if on:
        FLAG.write_text("1")
    else:
        try:
            FLAG.unlink()
        except OSError:
            pass


class _C(sqlite3.Connection):
    fts = True


def _db():
    c = sqlite3.connect(DB, timeout=30, factory=_C)
    c.execute("CREATE TABLE IF NOT EXISTS docs(path TEXT PRIMARY KEY, mtime REAL, title TEXT, kind TEXT)")
    try:
        c.execute("CREATE VIRTUAL TABLE IF NOT EXISTS chunks USING fts5(path UNINDEXED, title UNINDEXED, text, tokenize='unicode61 remove_diacritics 2')")
        c.fts = True
    except sqlite3.OperationalError:  # no FTS5 in this Python: plain table, slower search
        c.execute("CREATE TABLE IF NOT EXISTS chunks(path TEXT, title TEXT, text TEXT)")
        c.fts = False
    return c


def _chunks(text, size=1100, over=150, cap=60):
    text = re.sub(r"\s+", " ", text).strip()
    out, i = [], 0
    while i < len(text) and len(out) < cap:
        out.append(text[i:i + size])
        i += size - over
    return out


def add_text(key, title, text, kind="mail", mtime=None):
    """Put one piece of text (an email, a note) in the memory under a name."""
    if not enabled() or not text or SENSITIVE.search(title or ""):
        return
    with _L:
        c = _db()
        c.execute("DELETE FROM chunks WHERE path=?", (key,))
        c.execute("INSERT OR REPLACE INTO docs VALUES(?,?,?,?)", (key, mtime or time.time(), title, kind))
        for ch in _chunks(text):
            c.execute("INSERT INTO chunks(path,title,text) VALUES(?,?,?)", (key, title, ch))
        c.commit()
        c.close()


def _files(budget_s):
    t0 = time.time()
    for root in pcaccess.ROOTS:
        for d, dirs, files in os.walk(root):
            dirs[:] = [x for x in dirs if not SKIP_DIR.match(x) and not SENSITIVE.search(x)]
            if d[len(str(root)):].count(os.sep) > 6:
                dirs[:] = []
            for f in files:
                if time.time() - t0 > budget_s:
                    return
                p = Path(d) / f
                if p.suffix.lower() in EXT and not SENSITIVE.search(f):
                    yield p


def index(budget_s=600):
    """Reads new and changed documents. Returns how many were added or updated."""
    if STATE["running"] or not enabled():
        return 0
    STATE.update(running=True, error="")
    n = 0
    try:
        with _L:
            c = _db()
            known = dict(c.execute("SELECT path, mtime FROM docs WHERE kind='file'").fetchall())
            c.close()
        seen = set()
        for p in _files(budget_s):
            sp = str(p)
            seen.add(sp)
            try:
                st = p.stat()
                if st.st_size > 20_000_000 or known.get(sp) == st.st_mtime:
                    continue
                text = pcaccess.read_file(sp, maxchars=80000, quiet=True)
            except BaseException:
                continue
            if len(text) < 40:
                continue
            with _L:
                c = _db()
                c.execute("DELETE FROM chunks WHERE path=?", (sp,))
                c.execute("INSERT OR REPLACE INTO docs VALUES(?,?,?,?)", (sp, st.st_mtime, p.name, "file"))
                for ch in _chunks(text):
                    c.execute("INSERT INTO chunks(path,title,text) VALUES(?,?,?)", (sp, p.name, ch))
                c.commit()
                c.close()
            n += 1
            time.sleep(0.02)  # stay gentle on the PC
        with _L:  # files that no longer exist
            c = _db()
            for sp in set(known) - seen:
                if not Path(sp).exists():
                    c.execute("DELETE FROM chunks WHERE path=?", (sp,))
                    c.execute("DELETE FROM docs WHERE path=?", (sp,))
            c.commit()
            c.close()
    except BaseException as e:
        STATE["error"] = str(e)[:140]
    finally:
        STATE.update(running=False, last=time.time(), added=n)
    return n


def count():
    try:
        with _L:
            c = _db()
            n = c.execute("SELECT COUNT(*) FROM docs").fetchone()[0]
            c.close()
        return n
    except sqlite3.Error:
        return 0


def search(query, n=4):
    """Best passages for a question: [{path, title, text}]."""
    if not enabled() or not DB.exists():
        return []
    words = [w for w in re.findall(r"\w+", query.lower()) if len(w) > 3][:8]
    if not words:
        return []
    try:
        with _L:
            c = _db()
            if c.fts:
                q = " OR ".join(f'"{w}"*' for w in words)
                rows = c.execute("SELECT path,title,text FROM chunks WHERE chunks MATCH ? ORDER BY bm25(chunks) LIMIT ?", (q, n * 3)).fetchall()
            else:
                rows = c.execute("SELECT path,title,text FROM chunks WHERE " + " OR ".join("text LIKE ?" for _ in words) + " LIMIT ?",
                                 [f"%{w}%" for w in words] + [n * 3]).fetchall()
            c.close()
    except sqlite3.Error:
        return []
    out, seen = [], set()
    for path, title, text in rows:
        if path in seen:
            continue
        seen.add(path)
        out.append({"path": path, "title": title, "text": text})
        if len(out) >= n:
            break
    return out


def clear():
    set_enabled(False)
    with _L:
        try:
            DB.unlink()
        except OSError:
            pass


def start_background():
    def loop():
        time.sleep(40)
        while True:
            try:
                if enabled():
                    index()
            except BaseException:
                pass
            time.sleep(1800)
    threading.Thread(target=loop, daemon=True).start()


def index_now(notify_fn=None):
    """Index in the background right away; tell the owner when it is done."""
    def run():
        n = index()
        if notify_fn:
            notify_fn(n, count())
    threading.Thread(target=run, daemon=True).start()
