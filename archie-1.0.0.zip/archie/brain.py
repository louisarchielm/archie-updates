"""Asks the AI. Uses a paid AI service if ARCHIE_LLM_URL is set, otherwise local Ollama."""
import json
import os
import re

import requests


def ask(prompt, system="", timeout=300, web=False, max_tokens=900):
    try:
        from . import lessons

        system = (system or "") + lessons.for_prompt(prompt)  # what Archie has learned from his mistakes
    except Exception:
        pass
    url = os.environ.get("ARCHIE_LLM_URL")  # any OpenAI-compatible base URL, e.g. https://api.openai.com/v1
    if url and "anthropic.com" in url:  # Claude, through Anthropic's own API
        model = os.environ.get("ARCHIE_LLM_MODEL", "").strip().strip('"\'').lower().replace(".", "-").replace(" ", "-")
        if not model.startswith("claude"):
            model = "claude-haiku-5-5"
        from . import usage

        lv = usage.level()
        if lv == "stop":
            raise RuntimeError("Le plafond d'utilisation du mois est atteint. Archie reprend le mois prochain (ou demandez d'augmenter le plafond).")
        if lv == "over":
            model, web = usage.CHEAP, False  # over the cap: cheapest model, no paid web searches
        body = {"model": model, "max_tokens": max_tokens, "system": system, "messages": [{"role": "user", "content": prompt}]}
        if web:  # Claude can search the internet by itself when the question needs it
            body["tools"] = [{"type": "web_search_20250305", "name": "web_search", "max_uses": 3}]
        hdr = {"x-api-key": os.environ.get("ARCHIE_LLM_KEY", "").strip(), "anthropic-version": "2023-06-01"}
        r = requests.post("https://api.anthropic.com/v1/messages", headers=hdr, json=body, timeout=timeout)
        if not r.ok and web:  # web search not enabled on this account: answer without it
            body.pop("tools")
            r = requests.post("https://api.anthropic.com/v1/messages", headers=hdr, json=body, timeout=timeout)
        if not r.ok:
            raise RuntimeError(f"Claude said {r.status_code} for model '{model}': {r.text[:200]}")
        j = r.json()
        usage.record(model, j.get("usage") or {})
        return "".join(c.get("text", "") for c in j["content"] if c.get("type") == "text").strip()
    if url:
        r = requests.post(
            url.rstrip("/") + "/chat/completions",
            headers={"Authorization": "Bearer " + os.environ.get("ARCHIE_LLM_KEY", "")},
            json={"model": os.environ.get("ARCHIE_LLM_MODEL", "gpt-4o-mini"),
                  "messages": [{"role": "system", "content": system}, {"role": "user", "content": prompt}]},
            timeout=timeout)
        r.raise_for_status()
        return r.json()["choices"][0]["message"]["content"]
    r = requests.post(
        os.environ.get("OLLAMA_URL", "http://localhost:11434/api/generate"),
        json={"model": os.environ.get("OLLAMA_MODEL", "qwen3:8b"), "system": system, "prompt": prompt,
              "stream": False, "think": False},
        timeout=int(os.environ.get("OLLAMA_TIMEOUT", "300")))
    r.raise_for_status()
    return r.json().get("response", "")


def ask_json(prompt, system="", timeout=300, max_tokens=900):
    """Returns a dict, or None if the AI did not answer with usable JSON."""
    text = re.sub(r"(?s)<think>.*?</think>", "", ask(prompt, system, timeout, max_tokens=max_tokens))
    a, b = text.find("{"), text.rfind("}")
    if a < 0 or b <= a:
        return None
    try:
        d = json.loads(text[a:b + 1])
    except ValueError:
        return None
    return d if isinstance(d, dict) else None
