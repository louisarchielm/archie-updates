import os
import sys
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

TZ = ZoneInfo(os.environ.get("ARCHIE_TZ", "America/Toronto"))
WORK_START = int(os.environ.get("WORK_START", "7"))
WORK_END = int(os.environ.get("WORK_END", "18"))


def _client():
    import caldav

    user = os.environ.get("ICLOUD_USER")
    pw = os.environ.get("ICLOUD_APP_PASSWORD")
    if not user or not pw:
        raise SystemExit(
            "Set ICLOUD_USER (your Apple ID email) and ICLOUD_APP_PASSWORD "
            "(an app-specific password from appleid.apple.com)."
        )
    return caldav.DAVClient(url="https://caldav.icloud.com/", username=user, password=pw)


def calendars():
    return _client().principal().calendars()


def _tz(d):
    return d.replace(tzinfo=TZ) if d.tzinfo is None else d.astimezone(TZ)


def events(start, end):
    """All calendar events between two aware datetimes, sorted by start."""
    out = []
    for cal in calendars():
        try:
            comps = cal.get_supported_components() or ["VEVENT"]
            if "VEVENT" not in comps:
                continue  # reminder lists show up as calendars too
            found = cal.date_search(start=start, end=end, expand=True)
        except Exception as e:
            print(f"warning: could not read calendar {cal.name}: {e}", file=sys.stderr)
            continue
        for ev in found:
            try:
                comp = ev.icalendar_component
                s = comp["dtstart"].dt
                e = comp["dtend"].dt if "dtend" in comp else s
            except Exception:
                continue
            timed = isinstance(s, datetime)
            if timed:
                s = _tz(s)
                e = _tz(e) if isinstance(e, datetime) else s
            out.append({
                "start": s, "end": e, "timed": timed,
                "title": str(comp.get("summary", "(no title)")),
                "calendar": cal.name,
            })
    out.sort(key=lambda x: x["start"] if x["timed"] else datetime.combine(x["start"], time(0), TZ))
    return out


def _busy(start, end):
    return [(e["start"], e["end"]) for e in events(start, end) if e["timed"]]


def free_slots(day, minutes=30, step=30):
    """Open slots on `day` (a date) inside working hours. Weekends return nothing."""
    if day.weekday() >= 5:
        return []
    start = datetime.combine(day, time(WORK_START), TZ)
    end = datetime.combine(day, time(WORK_END), TZ)
    busy = _busy(start, end)
    out, t = [], start
    while t + timedelta(minutes=minutes) <= end:
        t2 = t + timedelta(minutes=minutes)
        if not any(t < be and t2 > bs for bs, be in busy):
            out.append(t)
        t += timedelta(minutes=step)
    return out


def _target():
    name = os.environ.get("ICLOUD_CALENDAR")
    cals = [c for c in calendars() if "VEVENT" in (c.get_supported_components() or ["VEVENT"])]
    if name:
        for c in cals:
            if c.name == name:
                return c
        raise SystemExit(f"No calendar named '{name}'. Found: {[c.name for c in cals]}")
    if not cals:
        raise SystemExit("No event calendars found on this iCloud account.")
    return cals[0]


def add_event(title, start, minutes=30, notes=""):
    """Add an event. Refuses to double-book."""
    end = start + timedelta(minutes=minutes)
    if _busy(start, end):
        raise SystemExit("That time overlaps an existing event. Pick another slot.")
    _target().save_event(dtstart=start, dtend=end, summary=title, description=notes)


def find_events(start, end):
    """Real calendar objects (not expanded) between two datetimes: [(object, info)]. Recurring events are flagged."""
    out = []
    for cal in calendars():
        try:
            if "VEVENT" not in (cal.get_supported_components() or ["VEVENT"]):
                continue
            found = cal.date_search(start=start, end=end, expand=False)
        except Exception:
            continue
        for ev in found:
            try:
                comp = ev.icalendar_component
                s = comp["dtstart"].dt
                if not isinstance(s, datetime):
                    continue
                e = comp["dtend"].dt if "dtend" in comp else s + timedelta(minutes=30)
                out.append((ev, {"start": _tz(s), "end": _tz(e) if isinstance(e, datetime) else _tz(s) + timedelta(minutes=30),
                                 "title": str(comp.get("summary", "(no title)")), "recurring": "rrule" in comp}))
            except Exception:
                continue
    out.sort(key=lambda x: x[1]["start"])
    return out


def cancel_event(obj):
    obj.delete()


def move_event(obj, info, new_start):
    """Moves one event to a new start (same length). Refuses to land on top of another event."""
    new_end = new_start + (info["end"] - info["start"])
    if any(bs < new_end and be > new_start and not (abs((bs - info["start"]).total_seconds()) < 60 and abs((be - info["end"]).total_seconds()) < 60)
           for bs, be in _busy(new_start, new_end)):
        raise SystemExit("That time overlaps an existing event. Pick another slot.")
    comp = obj.icalendar_component
    comp["dtstart"].dt, comp["dtend"].dt = new_start, new_end
    obj.save()
