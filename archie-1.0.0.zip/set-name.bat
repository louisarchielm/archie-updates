@echo off
cd /d "%~dp0"
set /p N=Type the owner's name (as it should sign emails), then press Enter: 
setx OWNER_NAME "%N%" >nul
echo Saved. Close this window.
pause
