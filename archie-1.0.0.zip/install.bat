@echo off
rem Archie installer. Double-click this file from inside the archie folder.
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 (
  echo Python is not installed. Install Python 3.12 from python.org, tick "Add to PATH", then run this again.
  pause
  exit /b 1
)
if exist .venv rmdir /s /q .venv
py -3.12 -m venv .venv
if errorlevel 1 (
  echo Could not create the environment. Python 3.12 may be missing.
  pause
  exit /b 1
)
call .venv\Scripts\activate.bat
pip install -r requirements.txt
if errorlevel 1 (
  echo The install failed. Copy the red text above and send it to Claude.
  pause
  exit /b 1
)
echo.
echo Install finished. Next: double-click open-archie-app.bat, then click the gear at the top to enter your keys.
pause
