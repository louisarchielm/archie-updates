@echo off
cd /d "%~dp0"
echo Your Apple ID is the email you use for iCloud.
set /p U=Type your Apple ID email, then press Enter: 
set /p P=Paste the app password (abcd-efgh-ijkl-mnop), then press Enter: 
setx ICLOUD_USER "%U%" >nul
setx ICLOUD_APP_PASSWORD "%P%" >nul
echo.
echo Saved. Now CLOSE this window, then run test-calendar.bat.
pause
