@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie agenda
echo.
echo If you see your upcoming events above (or "no events"), the calendar works.
echo If you see a red error instead, take a screenshot and send it to Claude.
pause
