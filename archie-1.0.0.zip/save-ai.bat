@echo off
cd /d "%~dp0"
echo Optional. Leave all three EMPTY (just press Enter) to use the free local AI (Ollama).
echo.
echo For CLAUDE use:   address = https://api.anthropic.com     model = claude-haiku-5-5
echo For OpenAI use:   address = https://api.openai.com/v1     model = gpt-4o-mini
echo.
set /p U=AI service address: 
set /p K=AI service key: 
set /p M=Model name: 
if not "%U%"=="" setx ARCHIE_LLM_URL "%U%" >nul
if not "%K%"=="" setx ARCHIE_LLM_KEY "%K%" >nul
if not "%M%"=="" setx ARCHIE_LLM_MODEL "%M%" >nul
echo Saved. Close this window.
pause
