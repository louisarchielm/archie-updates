@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
pip install msal >nul 2>&1
python -m archie msauth
echo.
echo If it says "Signed in as ...", close this window and run test-inbox.bat.
pause
