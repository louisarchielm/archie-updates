@echo off
del "%APPDATA%\Microsoft\Windows\Start Menu\Programs\Startup\Archie.lnk" 2>nul
echo Archie will no longer start by itself.
pause
