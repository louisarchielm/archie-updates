@echo off
rem Owner only: makes a signed update for your clients' Archie.
cd /d "%~dp0"
call .venv\Scripts\activate.bat
if not exist "..\archie-update-private.key" python tools\make_release.py --init-key
set /p V=Numero de version (ex. 1.1.0) : 
set /p N=Ce qui change (une phrase) : 
python tools\make_release.py %V% "%N%"
pause
