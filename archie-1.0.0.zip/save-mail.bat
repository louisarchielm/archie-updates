@echo off
cd /d "%~dp0"
echo Works with Outlook, Gmail, iCloud, Yahoo and most others. Use an APP PASSWORD, not the normal password.
set /p U=Type the mail address, then press Enter: 
set /p P=Paste the app password, then press Enter: 
setx MAIL_USER "%U%" >nul
setx MAIL_APP_PASSWORD "%P%" >nul
echo.
echo If the provider is unusual, Claude will give you two more settings.
echo Saved. Close this window, then run test-inbox.bat.
pause
