@echo off
cd /d "%~dp0"
echo This is the Application (client) ID from the Microsoft app registration. It is NOT a password.
set /p I=Paste the Application (client) ID, then press Enter: 
setx MS_CLIENT_ID "%I%" >nul
echo Saved. Close this window, then run sign-in-microsoft.bat.
pause
