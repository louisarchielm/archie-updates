@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie inbox --max 3
echo.
echo If Telegram got up to 3 messages about your latest emails, it works. Nothing is sent until you tap Approve.
pause
