@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie selftest
echo.
echo Le resultat est aussi dans archie-check.txt
pause
