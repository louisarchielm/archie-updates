@echo off
rem Reads OpenJarvis help pages for skills, voice and channels into oj-explore.txt. Changes nothing.
cd /d "%~dp0"
call .oj-test\Scripts\activate.bat
(
echo ===== skill
jarvis skill --help
echo ===== digest
jarvis digest --help
echo ===== channel
jarvis channel --help
echo ===== vault
jarvis vault --help
echo ===== scheduler
jarvis scheduler --help
echo ===== agents
jarvis agents --help
echo ===== pip extras speech
pip download OpenJarvis[speech]==1.0.2 --no-deps -d nul
pip show -f OpenJarvis
) > oj-explore.txt 2>&1
echo Done. Tell Claude it finished.
pause
