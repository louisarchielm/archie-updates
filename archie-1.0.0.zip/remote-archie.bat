@echo off
rem Opens Archie's window connected to your Archie server (the first time it asks for the address and the access code).
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie remote
