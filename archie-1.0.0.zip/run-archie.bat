@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
echo Archie is watching the inbox. Leave this window open (minimise it).
python -m archie watch
pause
