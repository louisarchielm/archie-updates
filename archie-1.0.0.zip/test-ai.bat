@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie testai > archie-ai-check.txt 2>&1
type archie-ai-check.txt
echo.
echo Done. Tell Claude: it is done.
pause
