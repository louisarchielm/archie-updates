@echo off
rem Lets Archie use the same Telegram bot as the client finder. No secret to type.
if "%PROSPECT_BOT_TOKEN%"=="" (
  echo The client finder's bot token is not saved on this PC. Use save-telegram.bat instead.
  pause
  exit /b 1
)
setx ARCHIE_BOT_TOKEN "%PROSPECT_BOT_TOKEN%" >nul
echo Done. Archie will use the client finder's bot. Close this window.
echo Do NOT run the client finder and Archie at the same time (they would steal each other's taps).
pause
