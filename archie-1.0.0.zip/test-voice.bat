@echo off
rem Makes two short voice samples (English and French) and plays them. Changes nothing else.
cd /d "%~dp0"
call .oj-test\Scripts\activate.bat
pip install edge-tts >nul 2>&1
edge-tts --voice en-GB-RyanNeural --text "Good afternoon. I am Archie, your personal assistant. You have two meetings today, and one urgent email." --write-media voice-en.mp3
edge-tts --voice fr-CA-AntoineNeural --text "Bonjour. Je suis Archie, votre assistant personnel. Vous avez deux rendez-vous aujourd'hui, et un courriel urgent." --write-media voice-fr.mp3
edge-tts --voice fr-FR-HenriNeural --text "Bonjour. Je suis Archie, votre assistant personnel. Vous avez deux rendez-vous aujourd'hui, et un courriel urgent." --write-media voice-fr2.mp3
start "" voice-en.mp3
timeout /t 12 >nul
start "" voice-fr.mp3
timeout /t 12 >nul
start "" voice-fr2.mp3
echo.
echo Played 3 voices: English (British), French (Quebec), French (France). Tell Claude what you think.
pause
