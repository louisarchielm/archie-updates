@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie diagnose > archie-diagnose.txt 2>&1
type archie-diagnose.txt
echo.
echo Done. Tell Claude it finished.
pause
