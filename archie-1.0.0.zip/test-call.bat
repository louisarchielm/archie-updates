@echo off
cd /d "%~dp0"
call .venv\Scripts\activate.bat
python -m archie callme "Hello, this is Archie. Your phone calls work."
echo.
echo Your phone should ring in a few seconds. Answer it (a trial message plays first; if asked, press any key).
echo If you see a red error instead, take a screenshot and send it to Claude.
pause
