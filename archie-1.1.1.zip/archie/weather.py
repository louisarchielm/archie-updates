"""Today's weather for the greeting. Free service (open-meteo), no account needed. Place = your internet connection's city,
or set ARCHIE_CITY / ARCHIE_LAT / ARCHIE_LON to fix it."""
import json
import os
import threading
import time
from pathlib import Path

import requests

_CACHE = {"t": 0.0, "v": None}
_LOCK = threading.Lock()
DEFAULT = (45.5017, -73.5673, "Montréal")

EN = {0: "clear", 1: "mostly clear", 2: "partly cloudy", 3: "cloudy", 45: "foggy", 48: "foggy", 51: "light drizzle",
      53: "drizzle", 55: "heavy drizzle", 56: "freezing drizzle", 57: "freezing drizzle", 61: "light rain", 63: "rain",
      65: "heavy rain", 66: "freezing rain", 67: "freezing rain", 71: "light snow", 73: "snow", 75: "heavy snow",
      77: "snow grains", 80: "light showers", 81: "showers", 82: "heavy showers", 85: "snow showers",
      86: "heavy snow showers", 95: "thunderstorms", 96: "thunderstorms with hail", 99: "thunderstorms with hail"}
FR = {0: "dégagé", 1: "plutôt dégagé", 2: "partiellement nuageux", 3: "nuageux", 45: "brumeux", 48: "brumeux",
      51: "de la bruine légère", 53: "de la bruine", 55: "de la forte bruine", 56: "de la bruine verglaçante",
      57: "de la bruine verglaçante", 61: "de la pluie légère", 63: "de la pluie", 65: "de la forte pluie",
      66: "de la pluie verglaçante", 67: "de la pluie verglaçante", 71: "de la neige légère", 73: "de la neige",
      75: "de la forte neige", 77: "du grésil", 80: "des averses légères", 81: "des averses", 82: "de fortes averses",
      85: "des averses de neige", 86: "de fortes averses de neige", 95: "de l'orage", 96: "de l'orage avec grêle",
      99: "de l'orage avec grêle"}


def _place():
    if os.environ.get("ARCHIE_LAT") and os.environ.get("ARCHIE_LON"):
        return float(os.environ["ARCHIE_LAT"]), float(os.environ["ARCHIE_LON"]), os.environ.get("ARCHIE_CITY", "")
    try:
        j = requests.get("https://ipwho.is/", timeout=3).json()
        if j.get("success") and j.get("latitude") is not None:
            return float(j["latitude"]), float(j["longitude"]), os.environ.get("ARCHIE_CITY") or j.get("city", "")
    except Exception:
        pass
    return DEFAULT


_PLACE_FILE = Path(__file__).resolve().parent.parent / "archie-place.json"
_BUSY = {"on": False}


def _place_cached():
    """The place is looked up once and remembered, so the greeting never waits for it again."""
    try:
        v = json.loads(_PLACE_FILE.read_text(encoding="utf-8"))
        return float(v[0]), float(v[1]), v[2]
    except (OSError, ValueError, IndexError, TypeError):
        pass
    p = _place()
    if p is not DEFAULT:
        try:
            _PLACE_FILE.write_text(json.dumps(list(p)), encoding="utf-8")
        except OSError:
            pass
    return p


def _refresh_bg():
    if _BUSY["on"]:
        return
    _BUSY["on"] = True

    def go():
        try:
            _fetch()
        finally:
            _BUSY["on"] = False

    threading.Thread(target=go, daemon=True).start()


def warm():
    """Keeps the weather fresh in the background (every 15 minutes), so saying it at start-up is instant."""
    def loop():
        while True:
            try:
                _fetch()
            except Exception:
                pass
            time.sleep(900)

    threading.Thread(target=loop, daemon=True).start()


def today():
    """{'city','temp','code','high','low','rain'} or None. Instant when known; a stale one (up to 6 hours) is used while a new one loads."""
    with _LOCK:
        age = time.time() - _CACHE["t"]
        if _CACHE["v"] and age < 1200:
            return _CACHE["v"]
        if _CACHE["v"] and age < 6 * 3600:
            _refresh_bg()
            return _CACHE["v"]
    return _fetch()


def _fetch():
    try:
        lat, lon, city = _place_cached()
        j = requests.get("https://api.open-meteo.com/v1/forecast", timeout=4, params={
            "latitude": lat, "longitude": lon, "timezone": "auto", "forecast_days": 1,
            "current": "temperature_2m,weather_code",
            "daily": "temperature_2m_max,temperature_2m_min,precipitation_probability_max"}).json()
        v = {"city": city, "temp": round(j["current"]["temperature_2m"]), "code": int(j["current"]["weather_code"]),
             "high": round(j["daily"]["temperature_2m_max"][0]), "low": round(j["daily"]["temperature_2m_min"][0]),
             "rain": j["daily"].get("precipitation_probability_max", [0])[0] or 0}
    except Exception:
        return None
    with _LOCK:
        _CACHE.update(t=time.time(), v=v)
    return v


def _n(x, lang):
    return (f"moins {abs(x)}" if lang == "fr" else f"minus {abs(x)}") if x < 0 else str(x)


def sentence(lang):
    w = today()
    if not w:
        return ""
    if lang == "fr":
        s = f"Il fait {_n(w['temp'], 'fr')} degrés" + (f" à {w['city']}" if w["city"] else "")
        s += f", ciel {FR.get(w['code'], '')}." if w["code"] in (0, 1, 2, 3, 45, 48) else f", avec {FR.get(w['code'], 'un temps variable')}."
        if w["rain"] >= 40:
            s += f" Il y a {w['rain']} % de probabilité de précipitations."
        return s
    s = f"It is {_n(w['temp'], 'en')} degrees" + (f" in {w['city']}" if w["city"] else "")
    s += f", {EN.get(w['code'], 'changeable')}."
    if w["rain"] >= 40:
        s += f" There is a {w['rain']} percent chance of precipitation."
    return s
