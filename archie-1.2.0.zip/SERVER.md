# Archie on a server (hosted version)

Archie runs on a rented server (a small Linux machine). The PC only has the thin app, which opens a window connected to the server with an access code.
Without a paid subscription the access code is not given or is switched off, so the app opens nothing.

## On the server (one client = one Archie, kept separate)
1. Python 3.12, then in the archie folder: `pip install -r requirements.txt`.
2. Make an access code for the client: `python -m archie token` (keep it, it is shown once here).
3. Set the settings (keys) once, in a file or the environment:
   `ARCHIE_SERVER_TOKEN=<the code>`, `ARCHIE_HOST=127.0.0.1`, `ARCHIE_PORT=8765`, plus the client's AI key, name, mail, etc.
4. Start it: `python -m archie server` (Archie refuses to start without a code of 24+ characters).
5. Put HTTPS in front of it. Example with Caddy (free certificate), file `Caddyfile`:
   ```
   archie-client1.example.com {
       reverse_proxy 127.0.0.1:8765
   }
   ```
   Never open port 8765 to the internet directly: the code would travel unencrypted.
6. Keep it running (systemd service or similar) and back up the folder every night (memory, drafts, settings).

## On the client's PC
Double-click `remote-archie.bat`. The first time it asks for the server address (https://...) and the access code
(typed by the client, hidden), then it remembers them in `archie-remote.json`. The microphone works because the address is HTTPS.

## What works and what does not yet
- Works: chat, voice, mail, agenda, memory, alarms, notifications, skills, the AI usage cap.
- Not yet: access to the client's PC files and programs (needs the small agent of phase 3), alarms that open the window on the PC when it is closed.
- Voice recognition (Whisper) runs on the server's processor: not tested for speed on a small rented machine.
- Several clients on one machine: each needs its own folder, port, access code and web address. Isolation between clients is phase 4.

## Security in this phase
Access code compared in constant time, 10 wrong tries lock that address for 5 minutes, every request carries the code, no code in the web address after the first load.
Not done yet: per-client accounts and subscription check (phase 2), encrypted storage of the keys on the server.
