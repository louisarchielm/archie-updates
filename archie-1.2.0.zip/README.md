# Archie

Personal AI voice assistant (English / French) for a professional's Windows PC: voice, email with approval, calendar, phone alerts, PC access, skills.

**Quick start:** 1. double-click `install.bat` (needs Python 3.12)  2. double-click `open-archie-app.bat`  3. click the gear in the app and type your keys (Claude, email, iCloud, Twilio). Nothing else to run.
Never put passwords or keys in this repository; each PC keeps its own (`archie-config.json`, ignored by git). Archie never sends an email until the owner approves it.
The older `save-*.bat` / `test-*.bat` helpers are kept for troubleshooting only; the gear in the app replaces them.

## Trois versions
Réglage « Version d'Archie » (roue dentée, section Général) : `base`, `avance` ou `expert`. Sans réglage = Base.
- **Base** : tout sauf Twilio. Pas d'appels ni de textos ; les alertes s'affichent à l'écran et se disent à voix haute.
- **Avancée** : Base + Twilio (textos, appels d'urgence, conversations téléphoniques).
- **Expert** : Avancée + réseaux sociaux et comptabilité (modules vendus à part, pas encore installés).

## Archie desktop app (voice + memory)
Double-click `open-archie-app.bat`. A window opens with Archie's screen: press SPEAK, talk (English or French),
press again to send. Archie answers out loud. Everything Archie sees or does (emails, approvals, notes, your
conversations) is kept in `archie-memory.db` on this PC, so you can ask later "what did Marc want?".
Say or type "note: ..." / "souviens-toi: ..." to save a note. Needs internet for the voice (edge-tts) and the AI.

## Alarm, music and welcome-back
- Say: "Archie, wake me up at 7 tomorrow" (or "réveille-moi à 7 h", "on weekdays", "every day"). "What alarms do I have?" / "Cancel my alarms."
- When it rings: music rises slowly, then Archie says good morning with the time and weather. Say "stop" / "arrête" to end it, "snooze" for 9 more minutes.
- Music: put your own mp3 files in the `archie-music` folder (a song you have the right to use). With none, Archie plays a built-in chime.
- Archie keeps Windows from falling asleep while he runs. Keep the PC plugged in and on. `autostart-archie.bat` opens Archie at every PC start.
- If you have not touched the PC for 20 minutes and have not spoken to Archie for 3 hours, he welcomes you back when you return (ARCHIE_GREET_HOURS / ARCHIE_AWAY_MIN change this).

## Visuels, agenda et accès au PC

- Archie peut afficher graphiques (barres, lignes, camembert), tableaux, dessins et photos (Wikipédia) quand on le demande.
- Agenda : « montre-moi mon agenda (demain, cette semaine) » ; « réserve un lunch avec Marc demain à midi » (refuse les conflits et propose des plages libres).
- PC : niveau 1 (ouvrir un programme/site, chercher et lire un fichier) tout de suite ; niveau 2 (créer un fichier, déplacer) seulement après un « oui » sur la carte. Supprimer, installer, payer, mots de passe : jamais seul.
- Tout est écrit dans `archie-actions.log`. Dossiers permis : Documents, Bureau, Téléchargements, Images, OneDrive.

## Archie tout-en-un (version finale)

Tout tourne dans l'application (`open-archie-app.bat`), sans autre fenêtre :
- **Voix et écran** : conversation mains libres, orbe, visuels, fenêtres intégrées (sites, cartes, PDF).
- **Courriel** : rédige, montre, envoie après votre accord ; surveille la boîte de réception toutes les 3 minutes.
- **Agenda** : montre et réserve (iCloud).
- **Alerte** : urgent → appel téléphonique (+ texto), moins urgent → texto, le reste → à l'écran et à voix haute. Appels coupés la nuit (`ARCHIE_QUIET`, défaut 22-7). Rappel texto 25 min avant un rendez-vous.
- **Compétences** : « apprends : quand je dis rapport du matin, montre-moi mon agenda et lis mes courriels importants » ; « quelles sont mes compétences » ; « oublie la compétence … ». Une compétence peut enchaîner plusieurs actions (« quand je dis bonne journée : donne-moi la météo, mon agenda, puis mes courriels ») ; Archie tolère les petites erreurs de reconnaissance vocale sur le déclencheur.
- **Téléphone** : « appelle-moi », « texte-moi que … », « appelle <contact> » (contacts.json + PUBLIC_URL).
- **PC** : niveaux 1 et 2, journal `archie-actions.log`.
- **État** : dites « status » pour voir ce qui est branché.

## Un seul programme

Tout se lance avec `open-archie-app.bat` (ou automatiquement au démarrage de Windows : case dans les réglages). Les clés et mots de passe se saisissent dans l'application (roue dentée ⚙ ou « ouvre les réglages ») et sont gardés dans `archie-config.json`, jamais sur GitHub. Les anciens `save-*.bat` et `test-*.bat` ne sont plus nécessaires. Le bouton ✓ vérifie que tout fonctionne.

## Apprendre de ses erreurs

Quand vous corrigez Archie (« non, ce n'est pas ce que j'ai demandé », « tu t'es trompé », « arrête de… »), il en tire une règle courte (`archie-lessons.json`), la répète à l'IA à chaque demande, et refait sa réponse si c'était une simple réponse. Il note aussi ses échecs techniques et en tire des règles toutes les 6 heures. « Qu'as-tu appris ? » les liste, « oublie la leçon … » en efface une.

## Hébergé sur un serveur (en préparation)
Archie peut tourner sur un serveur loué : `python -m archie server`, avec un code d'accès (`python -m archie token`). Sur le PC, `remote-archie.bat` ouvre la fenêtre connectée au serveur. Voir `SERVER.md`.

## Mises à jour à distance
Archie vérifie seul s'il y a une nouvelle version (adresse dans les réglages, section Mises à jour) et prévient : « Une mise à jour est prête ». Dites « mets à jour Archie » : il demande confirmation, installe, garde l'ancienne copie et redémarre.
Seuls les fichiers du programme sont remplacés : réglages, mémoire, brouillons, leçons, compétences et contacts ne sont jamais touchés. Chaque mise à jour est signée : une version non signée par le propriétaire est refusée.
`python -m archie update` vérifie, `python -m archie update --apply` installe, `python -m archie rollback` remet la version précédente.
Pour le propriétaire : `make-release.bat` fabrique la mise à jour signée (3 fichiers dans le dossier releases) à téléverser à l'adresse des mises à jour. La clé privée reste à côté du dossier, jamais sur GitHub.

## Apprendre de ses erreurs, et signalements anonymes
Quand vous corrigez Archie (« non, je préfère… », « c'est faux »), il en tire une règle qu'il applique ensuite en permanence (jusqu'à 100 règles, la plus récente gagne). Ces règles restent chez vous.
Au premier lancement, un écran demande si vous acceptez que les **erreurs générales** d'Archie soient signalées, de façon anonyme, à AnchorLine pour améliorer les mises à jour. Les préférences personnelles (ton, longueur, noms, signature) ne sont jamais envoyées, ni vos courriels, agenda, fichiers ou contacts. Chaque signalement vous est montré mot pour mot (« montre le signalement ») et ne part qu'après votre oui. « Arrête de partager » coupe tout. Le choix se change dans les réglages, section Confidentialité.
Côté propriétaire : `tools/feedback_server.py` reçoit les signalements, `tools/review_feedback.py` regroupe les erreurs signalées par plusieurs clients.
