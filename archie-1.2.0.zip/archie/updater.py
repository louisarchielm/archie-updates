"""Remote updates. The owner publishes a signed release; every Archie checks for it, shows a notice, and installs it after a yes
(or by itself at a quiet moment if ARCHIE_AUTO_UPDATE=oui). Only program files are replaced: settings, memory, drafts, lessons, skills,
contacts and keys are never touched. A copy of the old files is kept so one command puts everything back (python -m archie rollback).

Trust: update.json is signed with the owner's private key (Ed25519). The public key ships in archie/update_key.pub. A download that is not
signed by it, or whose checksum does not match, is refused, so a stolen web address cannot push code onto a client's PC."""
import base64
import hashlib
import io
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile
from pathlib import Path

import requests

PKG = Path(__file__).resolve().parent
ROOT = PKG.parent
# what an update may replace (everything else on the PC is the client's and stays as it is)
ALLOWED = [re.compile(p) for p in (r"^archie/[\w./-]+\.(py|html|txt|md|pub)$", r"^archie/VERSION$", r"^archie/ui/[\w./-]+$", r"^[\w-]+\.bat$",
                                   r"^(README|SERVER|NOTICE)\.(md|txt)$", r"^requirements\.txt$")]
NEVER = re.compile(r"(^|/)(archie-[\w.-]+|contacts\.json|\.env|\.venv|archie-backup|archie-cache|archie-music)(/|$)", re.I)
STATE = {"available": None, "notified": "", "last_check": 0.0, "error": ""}


def version(root=None):
    try:
        return ((root or ROOT) / "archie" / "VERSION").read_text(encoding="utf-8").strip() or "0"
    except OSError:
        return "0"


def _vt(v):
    return tuple(int(x) for x in re.findall(r"\d+", v)[:4]) or (0,)


DEFAULT_URL = "https://raw.githubusercontent.com/louisarchielm/archie-updates/main"  # AnchorLine's signed updates; the owner can override in settings


def base_url():
    u = (os.environ.get("ARCHIE_UPDATE_URL", "") or ("" if os.environ.get("ARCHIE_NO_DEFAULT_UPDATE") else DEFAULT_URL)).strip().rstrip("/")
    if u and not (u.startswith("https://") or u.startswith("http://127.0.0.1")):
        return ""  # updates only travel over HTTPS
    return u


def _pubkey(root):
    f = root / "archie" / "update_key.pub"
    try:
        raw = base64.b64decode(f.read_text(encoding="utf-8").strip())
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

        return Ed25519PublicKey.from_public_bytes(raw)
    except Exception:
        return None


def _verify(root, data, sig_b64):
    k = _pubkey(root)
    if not k:
        raise RuntimeError("Pas de clé de mise à jour installée.")
    try:
        k.verify(base64.b64decode(sig_b64.strip()), data)
    except Exception:
        raise RuntimeError("La signature de la mise à jour est invalide : refusée.")


def check(root=None, url=None):
    """The newer release as a dict {version, notes, zip, sha256} (signature checked), or None when up to date."""
    root = root or ROOT
    base = url or base_url()
    if not base:
        raise RuntimeError("Aucune adresse de mises à jour n'est réglée.")
    r = requests.get(base + "/update.json", timeout=20)
    s = requests.get(base + "/update.json.sig", timeout=20)
    if not r.ok or not s.ok:
        raise RuntimeError(f"Serveur de mises à jour : {r.status_code}/{s.status_code}")
    _verify(root, r.content, s.text)
    m = json.loads(r.content)
    if not re.fullmatch(r"[\w.-]+\.zip", m.get("zip", "")) or not re.fullmatch(r"[0-9a-f]{64}", m.get("sha256", "")):
        raise RuntimeError("Mise à jour mal formée : refusée.")
    return m if _vt(m.get("version", "0")) > _vt(version(root)) else None


def _safe_members(z):
    out = []
    for n in z.namelist():
        if n.endswith("/"):
            continue
        if n.startswith("/") or ".." in n.split("/") or "\\" in n or NEVER.search(n) or not any(p.match(n) for p in ALLOWED):
            raise RuntimeError(f"Fichier non permis dans la mise à jour : {n[:80]}")
        out.append(n)
    return out


def apply(m, root=None, url=None, check_import=True):
    """Downloads, verifies and installs release m. Returns the old version. On any failure the old files are put back."""
    root = root or ROOT
    base = url or base_url()
    data = requests.get(base + "/" + m["zip"], timeout=120).content
    if hashlib.sha256(data).hexdigest() != m["sha256"]:
        raise RuntimeError("La somme de contrôle ne correspond pas : mise à jour refusée.")
    z = zipfile.ZipFile(io.BytesIO(data))
    names = _safe_members(z)
    if "archie/VERSION" not in names or z.read("archie/VERSION").decode().strip() != m["version"]:
        raise RuntimeError("La version dans le fichier ne correspond pas : refusée.")
    old = version(root)
    bk = root / "archie-backup" / old
    if bk.exists():
        shutil.rmtree(bk)
    added = []
    for n in names:  # 1. keep the old copy
        dst = root / n
        if dst.exists():
            (bk / n).parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(dst, bk / n)
        else:
            added.append(n)
    (bk).mkdir(parents=True, exist_ok=True)
    (bk / "_added.json").write_text(json.dumps(added), encoding="utf-8")
    try:
        for n in names:  # 2. put the new files in
            dst = root / n
            dst.parent.mkdir(parents=True, exist_ok=True)
            tmp = dst.with_name(dst.name + ".new")
            tmp.write_bytes(z.read(n))
            os.replace(tmp, dst)
        if check_import:  # 3. the new code must at least load
            res = subprocess.run([sys.executable, "-I", "-c", "import sys; sys.path.insert(0, %r); import archie.assistant, archie.server" % str(root)],
                                 cwd=str(root), capture_output=True, text=True, timeout=120)
            if res.returncode:
                raise RuntimeError("La nouvelle version ne démarre pas : " + (res.stderr or "")[-200:])
    except BaseException:
        rollback(root, old)
        raise
    old_dirs = sorted((p for p in (root / "archie-backup").iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime)
    for p in old_dirs[:-2]:
        shutil.rmtree(p, ignore_errors=True)  # keeps the last two copies
    return old


def rollback(root=None, which=None):
    """Puts back the files kept before the last update."""
    root = root or ROOT
    bdir = root / "archie-backup"
    if which:
        bk = bdir / which
    else:
        c = sorted((p for p in bdir.iterdir() if p.is_dir()), key=lambda p: p.stat().st_mtime) if bdir.exists() else []
        if not c:
            raise RuntimeError("Aucune copie à remettre.")
        bk = c[-1]
    for p in bk.rglob("*"):
        if p.is_file() and p.name != "_added.json":
            dst = root / p.relative_to(bk)
            dst.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, dst)
    try:
        for n in json.loads((bk / "_added.json").read_text(encoding="utf-8")):
            (root / n).unlink(missing_ok=True)
    except (OSError, ValueError):
        pass
    return bk.name


def restart(args=None):
    """Starts Archie again with the new files, then closes this one."""
    a = args or (["server"] if os.environ.get("ARCHIE_SERVER_MODE", "").lower() in ("1", "oui", "yes", "true", "on") else ["app", "--no-window"])
    code = "import time,subprocess,sys;time.sleep(3);subprocess.Popen([sys.executable,'-m','archie']+%r)" % a
    flags = (0x00000008 | 0x00000200) if os.name == "nt" else 0  # detached, own group
    subprocess.Popen([sys.executable, "-c", code], cwd=str(ROOT), creationflags=flags, close_fds=True)
    threading.Timer(1.5, lambda: os._exit(0)).start()


def look(notify=None):
    """One check; tells the owner once per version. Returns the release found or None."""
    STATE["last_check"] = time.time()
    try:
        m = check()
        STATE["error"] = ""
    except BaseException as e:
        STATE["error"] = str(e)[:150]
        return None
    STATE["available"] = m
    if m and notify and STATE["notified"] != m["version"] and os.environ.get("ARCHIE_AUTO_UPDATE", "").lower() not in ("oui", "yes", "1", "true"):
        STATE["notified"] = m["version"]
        notify(f"Une mise à jour d'Archie est prête : version {m['version']}. {m.get('notes', '')[:160]} Dites « mets à jour Archie » pour l'installer.")
    return m


def background(notify, quiet, hours=6):
    """Checks a minute after start and then every few hours. With ARCHIE_AUTO_UPDATE=oui it installs when `quiet()` says nobody is using Archie."""
    def loop():
        time.sleep(60)
        while True:
            try:
                if base_url():
                    m = look(notify)
                    if m and os.environ.get("ARCHIE_AUTO_UPDATE", "").lower() in ("oui", "yes", "1", "true"):
                        while not quiet():
                            time.sleep(60)
                        apply(m)
                        restart()
                        return
            except BaseException as e:
                STATE["error"] = str(e)[:150]
            time.sleep(hours * 3600)

    threading.Thread(target=loop, daemon=True).start()
