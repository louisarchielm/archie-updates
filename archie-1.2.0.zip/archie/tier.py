"""The three versions of Archie. Base: no phone (no calls, no texts). Advanced: Twilio (texts, calls, phone conversations).
Expert: Advanced + social networks and accounting (those modules are sold separately and are not built in yet)."""
import os
import re

NAMES = {"base": ("Base", "Base"), "advanced": ("Advanced", "Avancée"), "expert": ("Expert", "Expert")}


def normalize(v):
    v = re.sub(r"[^a-z]", "", (v or "").lower().replace("é", "e").replace("è", "e"))
    if v.startswith("adv") or v.startswith("avan"):
        return "advanced"
    if v.startswith("exp"):
        return "expert"
    return "base" if v in ("", "base", "basic", "basique", "de") or v.startswith("bas") else None


def get():
    """The version comes from the signed license (license.py), never from a setting."""
    from . import license

    return license.tier()


def label(lang="en"):
    return NAMES[get()][1 if lang == "fr" else 0]


def phone_ok():
    return get() in ("advanced", "expert")


def expert_ok():
    return get() == "expert"
