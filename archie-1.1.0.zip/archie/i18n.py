"""English texts for the settings and the self-check (the app is written in French first)."""
import re

SECTIONS = {"Général": "General", "Intelligence": "Intelligence", "Téléphone": "Phone", "Mises à jour": "Updates",
            "Confidentialité": "Privacy", "Courriel": "Email", "Courriel Outlook / Microsoft 365": "Outlook / Microsoft 365 email",
            "Agenda iCloud": "iCloud calendar", "Expert": "Expert"}

FIELDS = {
    "OWNER_NAME": ("Your name (as Archie signs your emails)", ""),
    "ARCHIE_LLM_KEY": ("Claude key (starts with sk-ant-)", "console.anthropic.com → API keys → Create key"),
    "ARCHIE_LLM_MODEL": ("Model (claude-haiku-5-5 fast, claude-sonnet-5-5 more refined)", ""),
    "ARCHIE_VIP_LABEL": ("What to call your important clients (e.g. priority client, key client)", "Archie uses this word everywhere. Leave empty for “priority client”"),
    "ARCHIE_MONTHLY_CAP": ("Monthly spending limit for the AI, in dollars (e.g. 15)", "At 80% Archie warns you, at 100% he switches to the cheaper model, at 150% he pauses until next month"),
    "ARCHIE_UPDATE_URL": ("Update address (given by AnchorLine)", "Archie checks by himself for a new signed version"),
    "ARCHIE_AUTO_UPDATE": ("Install updates by himself at a quiet moment? (yes or no)", "No: Archie asks first. Yes: he updates when you are not using him"),
    "ARCHIE_SHARE_FEEDBACK": ("Share anonymous general error reports with AnchorLine? (yes or no)", "Never your emails, calendar, files, contacts or preferences. You approve every report before it is sent"),
    "ARCHIE_FEEDBACK_URL": ("Report address (given by AnchorLine)", ""),
    "MAIL_USER": ("Email address", "Gmail, Outlook.com, iCloud, Yahoo"),
    "MAIL_APP_PASSWORD": ("Email app password", "Not your normal password: an app password"),
    "MS_CLIENT_ID": ("Outlook: Microsoft application ID (not a password)", "portal.azure.com → App registrations → Application (client) ID"),
    "ICLOUD_USER": ("Apple ID (iCloud email)", ""),
    "ICLOUD_APP_PASSWORD": ("Apple app password (abcd-efgh-ijkl-mnop)", "appleid.apple.com → Sign-In and Security → App-Specific Passwords"),
    "TWILIO_ACCOUNT_SID": ("Twilio Account SID (starts with AC)", "twilio.com → dashboard"),
    "TWILIO_AUTH_TOKEN": ("Twilio Auth Token", ""),
    "TWILIO_FROM": ("Twilio number (+1...)", ""),
    "MY_PHONE": ("Your cell phone (+1...)", "Archie calls and texts you at this number"),
    "PUBLIC_URL": ("Public address (only to call clients)", "Optional"),
    "BUFFER_API_KEY": ("Buffer: API key (social networks)", "buffer.com → Settings → API → create a key"),
    "BUFFER_MODE": ("Buffer: “draft” (default) or “queue” (scheduled directly)", ""),
    "PROSPECT_CITY": ("Prospecting: your city", ""),
    "PROSPECT_TARGETS": ("Prospecting: who to look for (e.g. real estate agents, lawyers, accountants)", ""),
    "PROSPECT_PITCH": ("Prospecting: your offer in one or two sentences", "Archie uses it to write the emails"),
    "PROSPECT_DAILY": ("Prospecting: how many prospects to find per day (1 to 10)", ""),
    "PROSPECT_AUTO": ("Automatic prospecting every working day: yes or no", "Archie searches on his own but never sends without your approval"),
    "PROSPECT_OPTOUT": ("“Reply no thanks” line in the emails: yes (recommended) or no", "Canada's anti-spam law (CASL) requires a way to unsubscribe"),
    "PROSPECT_ADDRESS": ("Mailing address for prospecting emails (CASL)", ""),
}

ERRORS = {
    "Le numéro doit ressembler à +15145551234": "The number must look like +15145551234",
    "La clé Claude commence par sk-ant-": "The Claude key starts with sk-ant-",
    "Il faut une adresse courriel": "An email address is needed",
    "L'adresse des mises à jour commence par https://": "The update address starts with https://",
    "Écrivez oui ou non": "Write yes or no",
    "L'adresse des signalements commence par https://": "The report address starts with https://",
    "Un mot ou deux, 30 lettres au plus (ex. client clé)": "One or two words, 30 letters at most (e.g. key client)",
    "Le plafond est un nombre de dollars (ex. 15), ou vide pour aucun plafond": "The limit is a number of dollars (e.g. 15), or empty for no limit",
    "Le modèle commence par claude (ex. claude-haiku-5-5)": "The model starts with claude (e.g. claude-haiku-5-5)",
}

SELF = {
    "Intelligence (Claude)": "Intelligence (Claude)", "Courriel": "Email", "Agenda iCloud": "iCloud calendar",
    "Téléphone et textos": "Phone and texts", "Voix d'Archie": "Archie's voice", "Cours de la bourse": "Stock prices",
    "Photos et internet": "Photos and internet", "Accès au PC": "PC access", "Mémoire des documents": "Document memory",
    "Clients prioritaires (appels)": "Priority clients (calls)",
    "répond": "answering", "connecté": "connected", "voix prête": "voice ready", "cours disponibles": "prices available",
    "internet et photos": "internet and photos", "compte complet": "full account",
    "version Base : pas d'appels ni de textos": "Base version: no calls or texts",
    "non configuré (ouvrez les réglages ⚙)": "not set up (open the settings ⚙)",
    "compte d'ESSAI : les appels ne disent que le message de Twilio": "TRIAL account: calls only play Twilio's message",
    "pas de voix": "no voice", "aucun dossier trouvé": "no folder found",
    "éteinte (dites « indexe tous mes documents »)": "off (say “index all my documents”)",
    "aucun : Archie ne téléphonera jamais": "none: Archie will never phone you",
    "no answer": "no answer",
}


def section(s, lang):
    return SECTIONS.get(s, s) if lang == "en" else s


def field(key, label, hint, lang):
    if lang == "en" and key in FIELDS:
        return FIELDS[key]
    return label, hint


def err(msg, lang):
    return ERRORS.get(msg, msg) if lang == "en" else msg


def selftest(s, lang):
    if lang != "en":
        return s
    if s in SELF:
        return SELF[s]
    s = re.sub(r"journée (\S+) h à (\S+) h", r"day \1:00 to \2:00", s)
    s = re.sub(r"Twilio refuse le compte", "Twilio refuses the account", s)
    s = re.sub(r"(\d+) client\(s\)", r"\1 client(s)", s)
    return s
