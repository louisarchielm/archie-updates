"""Archie's daily self-review. Once a day (and when asked) he reads his own conversations with the owner, finds where he was slow,
wrong, or asked the same thing again and again, and turns that into rules and skills that are used from the next message on.
Everything is logged in archie-improve.json and can be undone. He never edits his own program: the program only changes
through signed updates."""
import json
import re
import time
from pathlib import Path

from . import brain, lessons, memory, skills

LOG = Path("archie-improve.json")
EVERY = 20 * 3600
UNSAFE = re.compile(r"\b(ignore|override|bypass|disable|without (asking|approval|permission|confirm)|never ask|don'?t ask|password|api key|token|"
                    r"send (money|payment)|wire|transfer|delete (all|everything)|reveal|secret)\b", re.I)
PROMPT = """You are auditing an AI assistant, Archie, from its own conversations with its owner over the last day. Lines starting with Owner are
what he said; lines starting with Archie are the answers.

{convo}

Find real, repeated or clear problems: answers that were wrong, too long, too slow to get to the point, not understood, a request Archie
could not do, a correction by the owner, the same request made several times. Also note what the owner repeatedly asks for.
Return JSON only:
{{"score": 1 to 10 (how well Archie served him),
"rules": ["up to 4 short imperative rules in English (max 25 words) that would prevent the problems; general, never about one-time facts; nothing about security, passwords, sending or deleting"],
"skills": [{{"request": "only if the owner asked for the SAME routine at least 3 times: 'When I say X, do Y' in his words"}}],
"gaps": ["things he asked that Archie could not do, max 3, short"],
"summary": "one plain sentence in the owner's language ({lang}) on what you improved"}}
If nothing needs improving, return empty lists."""


def _log():
    try:
        return json.loads(LOG.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(v):
    LOG.write_text(json.dumps(v[-90:], ensure_ascii=False, indent=1), encoding="utf-8")


def due():
    v = _log()
    return not v or time.time() - v[-1]["ts"] > EVERY


def review(force=False):
    """One self-review. Returns the log entry, or None if there was too little to learn from."""
    since = (_log() or [{"ts": time.time() - 86400}])[-1]["ts"]
    rows = [r for r in memory._rows("SELECT * FROM events WHERE kind IN ('chat_user','chat_archie') AND ts>? ORDER BY id LIMIT 80", (since,))]
    if len([r for r in rows if r["kind"] == "chat_user"]) < (1 if force else 5):
        return None
    convo = "\n".join(("Owner: " if r["kind"] == "chat_user" else "Archie: ") + r["text"][:220] for r in rows)[-6000:]
    lang = memory.get_lang()
    d = brain.ask_json(PROMPT.format(convo=convo, lang="French" if lang == "fr" else "English"), "You audit an AI assistant. JSON only.", max_tokens=700)
    if not d:
        return None
    added_l, added_s = [], []
    for r in (d.get("rules") or [])[:4]:
        r = str(r).strip()
        if r and not UNSAFE.search(r):
            l = lessons.add(r)
            if l and l.get("hits", 1) == 1:
                added_l.append(l["text"])
    for s in (d.get("skills") or [])[:2]:
        q = str((s or {}).get("request") or "").strip()
        if q and not UNSAFE.search(q):
            sk = skills.learn(q)
            if sk:
                added_s.append(sk["name"])
    try:
        score = max(1, min(10, int(d.get("score"))))
    except (TypeError, ValueError):
        score = None
    e = {"ts": time.time(), "date": time.strftime("%Y-%m-%d"), "score": score, "lessons": added_l, "skills": added_s,
         "gaps": [str(g)[:100] for g in (d.get("gaps") or [])[:3]], "summary": str(d.get("summary") or "")[:240]}
    _save(_log() + [e])
    return e


def undo_last():
    v = _log()
    for e in reversed(v):
        if (e.get("lessons") or e.get("skills")) and not e.get("undone"):
            for t in e.get("lessons", []):
                lessons.forget(t)
            for s in e.get("skills", []):
                skills.forget(s)
            e["undone"] = True
            _save(v)
            return e
    return None


def report(fr):
    v = [e for e in _log() if not e.get("undone")][-7:]
    if not v:
        return ("Je n'ai pas encore fait d'auto-évaluation. Elle se fait seule chaque jour, ou dites « améliore-toi »." if fr else
                "I have not done a self-review yet. It runs by itself every day, or say 'improve yourself'.")
    sc = [e["score"] for e in v if e.get("score")]
    nl, ns = sum(len(e["lessons"]) for e in v), sum(len(e["skills"]) for e in v)
    trend = f" {sc[0]}/10 → {sc[-1]}/10." if len(sc) > 1 else (f" {sc[0]}/10." if sc else "")
    gaps = list(dict.fromkeys(g for e in v for g in e.get("gaps", [])))[:3]
    if fr:
        t = f"Ces derniers jours : {nl} règle(s) et {ns} compétence(s) apprises seul.{trend}"
        if gaps:
            t += " Ce que je ne savais pas encore faire : " + "; ".join(gaps) + "."
        return t + " Dites « annule ce que tu as appris » pour revenir en arrière."
    t = f"Recently: {nl} rule(s) and {ns} skill(s) learned on my own.{trend}"
    if gaps:
        t += " What I could not do yet: " + "; ".join(gaps) + "."
    return t + " Say 'undo what you learned' to roll it back."
