"""Archie's desktop app: a local page (only this PC can open it) with voice in and voice out."""
import ctypes
import hmac
import json
import time
import os
import subprocess
import sys
import tempfile
import threading
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from . import alarms, assistant, autopilot, memory, voice

CACHE = Path(__file__).resolve().parent.parent / "archie-cache"
FILLERS = {
    "en": ["One moment, sir.", "Let me check, sir.", "Still working on it, sir."],
    "fr": ["Un instant, monsieur.", "Je vérifie, monsieur.", "Je m'en occupe toujours, monsieur."],
}


def _ql(u):
    v = (parse_qs(u.query).get("lang") or [memory.get_lang()])[0]
    return v if v in ("en", "fr") else "fr"


ACK = {"en": "Yes, sir?", "fr": "Oui, monsieur ?"}


MUSIC = Path(__file__).resolve().parent.parent / "archie-music"
STATE = {"last_seen": time.time(), "greet": False, "away": False, "poll": time.time(), "launched": 0.0}
GREET_HOURS = float(os.environ.get("ARCHIE_GREET_HOURS", "3"))
AWAY_MIN = float(os.environ.get("ARCHIE_AWAY_MIN", "20"))


def idle_seconds():
    """Seconds since the last keyboard or mouse use on this PC (Windows only)."""
    if os.name != "nt":
        return 0.0

    class LII(ctypes.Structure):
        _fields_ = [("cbSize", ctypes.c_uint), ("dwTime", ctypes.c_uint)]

    li = LII()
    li.cbSize = ctypes.sizeof(li)
    ctypes.windll.user32.GetLastInputInfo(ctypes.byref(li))
    return (ctypes.windll.kernel32.GetTickCount() - li.dwTime) / 1000.0


def keep_awake():
    """While Archie runs, Windows does not go to sleep on its own (so alarms can ring)."""
    if os.name != "nt":
        return
    ctypes.windll.kernel32.SetThreadExecutionState(0x80000000 | 0x00000001)  # continuous + system required
    while True:
        time.sleep(3600)


WINS = {}  # app windows that are alive: id -> (when it was opened, last time it called)


def _keep(wid, born):
    """Only the newest window stays: an older one is told to close, so a second click never leaves two Archies talking at once."""
    if not wid:
        return True
    now = time.time()
    try:
        born = float(born)
    except (TypeError, ValueError):
        born = now * 1000
    WINS[wid] = (born, now)
    for k in [k for k, (b, t) in WINS.items() if now - t > 45]:
        WINS.pop(k, None)
    newest = max(WINS.items(), key=lambda kv: (kv[1][0], kv[0]))[0]
    return newest == wid


def watcher(url):
    """Notices when you come back after a long time away, and reopens the window if an alarm is due and it is closed."""
    while True:
        time.sleep(5)
        try:
            now, idle = time.time(), idle_seconds()
            if idle >= AWAY_MIN * 60:
                STATE["away"] = True
            elif STATE["away"] and idle < 30:
                STATE["away"] = False
                if now - STATE["last_seen"] >= GREET_HOURS * 3600:
                    STATE["greet"] = True
            if alarms.pending_due() and now - STATE["poll"] > 40 and now - STATE["launched"] > 120:
                STATE["launched"] = now
                open_window(url)
        except Exception:
            pass


def greeting_parts(lang, kind="start", label=""):
    """Three parts: a short hello (cached, plays at once), the time and weather (made while the hello plays), and the closing question."""
    from datetime import datetime
    from zoneinfo import ZoneInfo

    from . import weather

    now = datetime.now(ZoneInfo(os.environ.get("ARCHIE_TZ", "America/Toronto")))
    h = now.hour
    if kind == "remind" and label:
        return [f"Monsieur, rappel : {label}." if lang == "fr" else f"Sir, a reminder: {label}."]
    if kind == "nudge":
        return [f"Monsieur, il est {h} h {now.minute:02d}. C'est l'heure de se lever." if lang == "fr"
                else f"Sir, it is {now.strftime('%I:%M %p').lstrip('0')}. Time to get up."]
    if lang == "fr":
        hello = ("Bonsoir" if h >= 18 or h < 5 else "Bonjour") + ", monsieur."
        if kind == "alarm":
            hello += " C'est l'heure de se réveiller."
        elif kind == "back":
            hello = "Content de vous revoir, monsieur."
        info = f"Il est {h} h {now.minute:02d}. " + weather.sentence("fr")
        end = "Bonne journée, monsieur." if kind == "alarm" else "Que puis-je faire pour vous ?"
    else:
        hello = ("Good evening" if h >= 18 or h < 5 else "Good morning" if h < 12 else "Good afternoon") + ", sir."
        if kind == "alarm":
            hello += " It is time to wake up."
        elif kind == "back":
            hello = "Welcome back, sir."
        info = f"It is {now.strftime('%I:%M %p').lstrip('0')}. " + weather.sentence("en")
        end = "Have a wonderful day, sir." if kind == "alarm" else "What can I do for you?"
    return [hello, info.strip(), end]


def greeting(lang):
    return greeting_parts(lang)[0]


def kn_state():
    from . import knowledge, pcaccess

    return {"on": knowledge.enabled(), "count": knowledge.count(), "running": bool(knowledge.STATE["running"]),
            "folders": ", ".join(dict.fromkeys(r.name for r in pcaccess.ROOTS)), "error": knowledge.STATE.get("error", "")}


def speech_file(text, lang):
    """mp3 of Archie saying the text; kept on disk so the same sentence is instant next time."""
    import hashlib
    from . import address

    text = address.apply(text)
    CACHE.mkdir(exist_ok=True)
    out = CACHE / (hashlib.sha1(f"{lang}|{text}".encode()).hexdigest()[:20] + ".mp3")
    if not out.exists():
        tmp = CACHE / f"tmp-{threading.get_ident()}-{time.time_ns()}.mp3"
        voice.speak_to_file(text[:1500], lang if lang in voice.VOICES else "en", tmp)
        os.replace(tmp, out)
    return out


def prewarm():
    try:
        from . import weather

        weather.today()
    except Exception:
        pass
    for lang in (memory.get_lang(), "en", "fr"):
        for t in [greeting(lang), greeting_parts(lang)[2], ACK[lang]] + FILLERS[lang]:
            try:
                speech_file(t, lang)
            except Exception:
                return  # offline: try again next time

UI = Path(__file__).resolve().parent / "ui"
PORT = int(os.environ.get("ARCHIE_PORT", "8765"))


def server_mode():
    """Server mode: Archie runs on a rented server and the app on the PC only connects to it with an access code."""
    return os.environ.get("ARCHIE_SERVER_MODE", "").strip().lower() in ("1", "oui", "yes", "true", "on")


FAILS = {}  # address -> [count, locked until]


def panel():
    from . import msgraph

    return {
        "agenda": assistant._agenda(1),
        "drafts": assistant.pending_drafts(),
        "memory": [{"when": memory.when(r["ts"]), "kind": r["kind"], "channel": r["channel"], "text": r["text"][:160]}
                   for r in reversed(memory.recent(8, ["email", "action", "call", "note"]))],
        "owner": os.environ.get("OWNER_NAME", ""),
        "mail": bool(os.environ.get("MAIL_USER") or msgraph.enabled()),
        "telegram": bool(os.environ.get("ARCHIE_BOT_TOKEN")),
    }


class H(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _ok_host(self):
        if server_mode():  # behind the web address of the server: the access code protects it, not the host name
            return True
        return self.headers.get("Host", "") in (f"127.0.0.1:{PORT}", f"localhost:{PORT}")

    def _authed(self):
        """Local mode: always. Server mode: the access code must match; 10 wrong tries lock that address for 5 minutes."""
        if not server_mode():
            return True
        ip = self.client_address[0]
        n, until = FAILS.get(ip, [0, 0])
        if until > time.time():
            return False
        tok = os.environ.get("ARCHIE_SERVER_TOKEN", "").strip()
        got = self.headers.get("Authorization", "")
        if tok and got.startswith("Bearer ") and hmac.compare_digest(got[7:].strip().encode(), tok.encode()):
            FAILS.pop(ip, None)
            return True
        n += 1
        FAILS[ip] = [n, time.time() + 300 if n >= 10 else 0]
        time.sleep(1)  # slows down guessing
        return False

    def _send(self, code, body, ctype="application/json"):
        if isinstance(body, (dict, list)):
            body = json.dumps(body, ensure_ascii=False).encode()
        elif isinstance(body, str):
            body = body.encode()
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        if not self._ok_host():
            return self._send(403, {"error": "forbidden"})
        u = urlparse(self.path)
        if u.path == "/":
            return self._send(200, (UI / "index.html").read_bytes(), "text/html; charset=utf-8")
        if u.path in ("/archie.ico", "/archie.png"):  # the app icon (the orb)
            return self._send(200, (UI / u.path[1:]).read_bytes(), "image/x-icon" if u.path.endswith(".ico") else "image/png")
        if u.path == "/api/file":  # a one-time unguessable link made by Archie for a file he was asked to show
            from . import pcaccess
            import mimetypes

            fp = pcaccess.view_path(parse_qs(u.query).get("t", [""])[0])
            if not fp:
                return self._send(404, {"error": "gone"})
            return self._send(200, open(fp, "rb").read(), mimetypes.guess_type(fp)[0] or "application/octet-stream")
        if u.path == "/api/hello":  # lets the page know if an access code is needed, and if the one it has works
            return self._send(200, {"auth": server_mode(), "ok": self._authed() if server_mode() and self.headers.get("Authorization") else not server_mode()})
        if self.headers.get("X-Archie") != "1":
            return self._send(403, {"error": "forbidden"})
        if not self._authed():
            return self._send(401, {"error": "access code needed"})
        if u.path == "/api/events":
            wait = min(float(parse_qs(u.query).get("wait", ["0"])[0] or 0), 25)
            end = time.time() + wait
            q = parse_qs(u.query)
            wid, born = q.get("wid", [""])[0][:30], q.get("born", [""])[0]
            if not _keep(wid, born):
                return self._send(200, {"keep": False})
            while True:
                STATE["poll"] = time.time()
                if not _keep(wid, born):
                    return self._send(200, {"keep": False})
                al = alarms.due()
                gr = STATE["greet"]
                nt = autopilot.take() if autopilot.NOTICES else []
                if al or gr or nt or time.time() >= end:
                    break
                time.sleep(0.5)
            if gr:
                STATE["greet"] = False
                STATE["last_seen"] = time.time()
            from . import updater

            return self._send(200, {"alarm": al, "greet": gr, "notices": nt, "lang": memory.get_lang(), "ver": updater.version()})
        if u.path == "/api/ms/state":
            from . import msgraph

            return self._send(200, msgraph.sign_in_state())
        if u.path == "/api/config":
            from . import config

            from . import feedback

            return self._send(200, {"fields": config.status(_ql(u)), "autostart": config.autostart_state(), "windows": os.name == "nt", "needs_consent": feedback.consent() is None, "knowledge": kn_state(), "license": __import__("archie.license", fromlist=["x"]).info(_ql(u))})
        if u.path == "/api/knowledge":
            return self._send(200, kn_state())
        if u.path == "/api/photo":
            from . import visuals

            try:
                data, ctype = visuals.photo(parse_qs(u.query).get("q", [""])[0])
                return self._send(200, data, ctype if ctype.startswith("image/") else "image/jpeg")
            except Exception as e:
                return self._send(404, {"error": str(e)[:100]})
        if u.path == "/api/music":
            MUSIC.mkdir(exist_ok=True)
            files = sorted(p.name for p in MUSIC.iterdir() if p.suffix.lower() in (".mp3", ".m4a", ".wav", ".ogg", ".aac"))
            return self._send(200, {"files": files})
        if u.path == "/api/music/file":
            name = os.path.basename(parse_qs(u.query).get("name", [""])[0])
            f = MUSIC / name
            if not name or not f.is_file():
                return self._send(404, {"error": "not found"})
            ctype = {".mp3": "audio/mpeg", ".m4a": "audio/mp4", ".wav": "audio/wav", ".ogg": "audio/ogg", ".aac": "audio/aac"}.get(f.suffix.lower(), "audio/mpeg")
            return self._send(200, f.read_bytes(), ctype)
        if u.path == "/api/greeting":
            lang = memory.get_lang()
            STATE["last_seen"] = time.time()
            kind = parse_qs(u.query).get("kind", ["start"])[0]
            parts = greeting_parts(lang, kind if kind in ("start", "alarm", "back", "nudge", "remind") else "start", parse_qs(u.query).get("label", [""])[0][:160])
            return self._send(200, {"parts": parts, "text": " ".join(parts), "lang": lang, "fillers": FILLERS, "ack": ACK})
        if u.path == "/api/panel":
            return self._send(200, panel())
        if u.path == "/api/speak":
            q = parse_qs(u.query)
            text, lang = q.get("text", [""])[0], q.get("lang", ["en"])[0]
            try:
                t0 = time.time()
                out = speech_file(text, lang)
                print(f"[timing] voice took {time.time() - t0:.1f}s", flush=True)
                return self._send(200, out.read_bytes(), "audio/mpeg")
            except Exception as e:
                return self._send(503, {"error": str(e)[:200]})
        self._send(404, {"error": "not found"})

    def do_POST(self):
        if not self._ok_host() or self.headers.get("X-Archie") != "1":
            return self._send(403, {"error": "forbidden"})
        if not self._authed():
            return self._send(401, {"error": "access code needed"})
        n = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(n) if n else b""
        u = urlparse(self.path)
        try:
            if u.path == "/api/config":
                from . import config

                body = json.loads(raw or b"{}")
                try:
                    st = config.save(body.get("values") or {}, body.get("lang") if body.get("lang") in ("en", "fr") else "fr")
                    if body.get("autostart") is not None:
                        config.set_autostart(bool(body["autostart"]))
                except ValueError as e:
                    return self._send(400, {"error": str(e)})
                return self._send(200, {"fields": st, "autostart": config.autostart_state()})
            if u.path == "/api/knowledge":  # the switch in the settings: read my documents or not
                from . import knowledge, pcaccess

                on = bool(json.loads(raw or b"{}").get("on"))
                if on:
                    knowledge.set_enabled(True)
                    pcaccess.log("knowledge: reading documents enabled by the owner (settings switch)")
                    knowledge.index_now(lambda n, t: autopilot.push(f"J'ai fini de lire vos documents : {t} en mémoire." if memory.get_lang() == "fr" else f"I finished reading your documents: {t} in memory.", "normal"))
                else:
                    knowledge.clear()
                st = kn_state()
                st["running"] = on
                return self._send(200, st)
            if u.path == "/api/ms/start":
                from . import msgraph

                try:
                    return self._send(200, msgraph.begin_sign_in())
                except SystemExit as e:
                    return self._send(400, {"error": str(e)})
                except Exception as e:
                    return self._send(400, {"error": str(e)[:200]})
            if u.path == "/api/selftest":
                from . import selftest

                return self._send(200, {"rows": [{"name": n, "ok": ok, "detail": d} for n, ok, d in selftest.run(_ql(u))]})
            if u.path in ("/api/alarm/dismiss", "/api/alarm/snooze"):
                body = json.loads(raw or b"{}")
                if u.path.endswith("dismiss"):
                    alarms.dismiss(body.get("id", ""))
                else:
                    alarms.snooze(body.get("id", ""), int(body.get("minutes", 9)))
                return self._send(200, {"ok": True})
            if u.path == "/api/chat":
                body = json.loads(raw or b"{}")
                text, hint, pitch, typed = body.get("text", ""), body.get("hint"), body.get("pitch"), bool(body.get("typed"))
                if not text.strip():
                    return self._send(400, {"error": "empty"})
                STATE["last_seen"] = t0 = time.time()
                key = " ".join(text.lower().split())
                last = STATE.get("last_chat")
                if last and last[0] == key and time.time() - last[1] < 5:
                    return self._send(200, {"reply": "", "dup": True})  # the same sentence twice: answer it only once
                STATE["last_chat"] = (key, time.time())
                ans, lang, card, visual = assistant.reply(text, "app", hint, pitch, typed)
                print(f"[timing] thinking took {time.time() - t0:.1f}s", flush=True)
                return self._send(200, {"reply": ans, "lang": lang, "card": card, "visual": visual})
            if u.path == "/api/transcribe":
                from .inbox import transcribe

                t0 = time.time()
                txt = transcribe(raw)
                print(f"[timing] listening (whisper) took {time.time() - t0:.1f}s", flush=True)
                return self._send(200, {"text": txt})
        except Exception as e:
            try:
                from . import lessons

                lessons.record_failure(u.path, e)
            except Exception:
                pass
            return self._send(500, {"error": str(e)[:300]})
        self._send(404, {"error": "not found"})


def open_window(url):
    edge = next((p for p in (r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe",
                              r"C:\Program Files\Microsoft\Edge\Application\msedge.exe") if os.path.exists(p)), None)
    if edge:
        subprocess.Popen([edge, f"--app={url}", "--window-size=1280,820", "--autoplay-policy=no-user-gesture-required",
                          "--use-fake-ui-for-media-stream"])
    else:
        webbrowser.open(url)


def notify_ok():
    from . import notify

    return notify.configured()


def run(open_win=True):
    from . import config

    config.load_into_env()  # keys typed in the app's settings
    srv_mode = server_mode()
    if srv_mode:
        if len(os.environ.get("ARCHIE_SERVER_TOKEN", "").strip()) < 24:
            raise SystemExit("Server mode needs ARCHIE_SERVER_TOKEN (24+ characters). Make one with: python -m archie token")
        open_win = False
    os.environ.setdefault("ARCHIE_WHISPER", "base")  # quick enough on a normal PC
    MUSIC.mkdir(exist_ok=True)
    threading.Thread(target=prewarm, daemon=True).start()
    host = os.environ.get("ARCHIE_HOST", "127.0.0.1").strip() or "127.0.0.1"
    srv = ThreadingHTTPServer((host, PORT), H)
    url = f"http://127.0.0.1:{PORT}/"
    if not srv_mode:  # a PC-only helper: sleep guard and reopening the window for alarms
        threading.Thread(target=keep_awake, daemon=True).start()
        threading.Thread(target=watcher, args=(url,), daemon=True).start()
    from . import knowledge

    knowledge.start_background()  # keeps the memory of the documents up to date
    from . import updater

    from . import feedback

    def _flush():
        while True:
            time.sleep(3600)
            try:
                feedback.flush()
            except BaseException:
                pass

    threading.Thread(target=_flush, daemon=True).start()
    updater.background(lambda t: autopilot.push(t), lambda: time.time() - STATE["last_seen"] > 600 and not alarms.pending_due() and not assistant._PENDING)
    autopilot.start()  # mail and agenda watch: tells the owner on screen, by text, or by phone when urgent
    if os.environ.get("PUBLIC_URL") and notify_ok():
        from . import phone

        threading.Thread(target=lambda: phone.serve(int(os.environ.get("ARCHIE_PHONE_PORT", "8080"))), daemon=True).start()
    if srv_mode:
        print(f"Archie server running on {host}:{PORT}. Put HTTPS in front of it (see SERVER.md).", flush=True)
    else:
        print("Archie app running at", url, "- close this window to stop it.", flush=True)
    if open_win:
        open_window(url)
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        pass


def remote():
    """The thin app on the PC: opens the window on the Archie server. Asks once for the address and access code, then remembers them."""
    import getpass

    f = Path(__file__).resolve().parent.parent / "archie-remote.json"
    try:
        d = json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        d = {}
    if not d.get("url") or not d.get("token"):
        d["url"] = input("Adresse du serveur Archie (https://...) : ").strip()
        d["token"] = getpass.getpass("Code d'accès (invisible pendant la frappe) : ").strip()
        if not d["url"].startswith("https://") and not d["url"].startswith("http://127.0.0.1"):
            raise SystemExit("L'adresse doit commencer par https://")
        f.write_text(json.dumps(d), encoding="utf-8")
    from urllib.parse import quote

    try:  # the thin app keeps itself up to date: signed, checked, with the old copy kept
        from . import updater

        os.environ.setdefault("ARCHIE_UPDATE_URL", d.get("update_url", ""))
        m = updater.check() if updater.base_url() else None
        if m:
            print(f"Mise à jour de l'application : version {m['version']}...")
            updater.apply(m)
            print("Mise à jour installée. Relancez remote-archie.bat si une erreur apparaît.")
    except BaseException as e:
        print("Mise à jour ignorée :", str(e)[:120])
    open_window(d["url"].rstrip("/") + "/#t=" + quote(d["token"], safe=""))
    print("La fenêtre d'Archie est ouverte. Vous pouvez fermer cette fenêtre noire.")
