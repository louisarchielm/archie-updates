"""Skills Archie learns from the owner: "when I say X, do Y". Stored in archie-skills.json and used on every message."""
import json
import re
import time
from pathlib import Path

from . import brain

FILE = Path("archie-skills.json")
LEARN = """The owner wants to teach his assistant a new skill (a routine or a rule). He said: "{request}"
Return JSON only: {{"name": "2-4 word name", "triggers": ["short phrases he will say to start it, in his language, 1 to 3"],
"instructions": "what to do, written as a direct request in the first person as if he said it again, complete and specific; for a rule that always applies (style, signature, habit) start with 'Always'",
"steps": ["if the routine has several distinct actions, one short direct request per action, in order (max 5); otherwise an empty list"],
"always": true or false (true if it is a standing rule rather than something started by a phrase)}}"""


def load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(v):
    FILE.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding="utf-8")


def _n(s):
    return " ".join(re.findall(r"\w+", (s or "").lower()))


def learn(request):
    d = brain.ask_json(LEARN.format(request=request), "You turn a request into a skill. JSON only.", max_tokens=600)
    if not d or not d.get("instructions") or not d.get("name"):
        return None
    sk = {"name": str(d["name"])[:40], "triggers": [str(t)[:60] for t in (d.get("triggers") or [])][:3],
          "instructions": str(d["instructions"])[:600],
          "steps": [str(x)[:300] for x in (d.get("steps") or []) if str(x).strip()][:5], "always": bool(d.get("always")), "created": time.strftime("%Y-%m-%d")}
    v = [s for s in load() if _n(s["name"]) != _n(sk["name"])] + [sk]
    _save(v)
    return sk


def forget(name):
    v, n = load(), _n(name)
    keep = [s for s in v if n not in _n(s["name"]) and _n(s["name"]) not in n]
    _save(keep)
    return len(v) - len(keep)


def match(text):
    """Exact or close match of a trigger phrase (tolerates small speech-recognition slips)."""
    import difflib

    t = _n(text)
    best, score = None, 0.0
    for s in load():
        if s.get("always"):
            continue
        for trg in s.get("triggers", []):
            g = _n(trg)
            if len(g) < 4:
                continue
            if t == g or (g in t and len(t.split()) <= len(g.split()) + 4):
                return s
            if abs(len(t.split()) - len(g.split())) <= 1:
                r = difflib.SequenceMatcher(None, t, g).ratio()
                if r >= 0.82 and r > score:
                    best, score = s, r
    return best


def for_prompt():
    v = load()
    if not v:
        return ""
    return "Skills and rules the owner taught you (follow them):\n" + "\n".join(
        f"- {s['name']}: {s['instructions']}" + (f" (started by: {', '.join(s['triggers'])})" if s.get("triggers") else "") for s in v)
