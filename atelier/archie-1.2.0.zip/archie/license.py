"""Which version of Archie this PC may run. The version is NOT a setting: it comes from a license that AnchorLine signs
(archie-license.json, Ed25519, the same key pair as the updates). Without a valid license Archie runs as Base.
The license file is never replaced by an update. Make one with outils-proprietaire\\make-license.bat (owner only)."""
import base64
import hashlib
import json
import os
import time
from datetime import date, timedelta
from pathlib import Path

PKG = Path(__file__).resolve().parent
FILE = Path("archie-license.json")
PUBKEY_FILE = PKG / "update_key.pub"
KEY_FP = "fe0765212022f84d7e723e0179a1532b439c1819fc3d42fa7d306aef764c67d7"  # fingerprint of AnchorLine's public key: a swapped key file makes every license invalid
PREFIX = b"archie-license-v1\n"  # a license signature can never be mistaken for an update signature
GRACE_DAYS = 7
DEV = False  # the test harness only
_C = {"sig": None, "at": 0.0, "v": None}


def canon(d):
    """The exact bytes that are signed: every field except the signature, in a fixed order."""
    return PREFIX + json.dumps({k: d[k] for k in sorted(d) if k != "sig"}, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _key():
    raw = base64.b64decode(PUBKEY_FILE.read_text(encoding="utf-8").strip())
    if hashlib.sha256(raw).hexdigest() != KEY_FP:
        raise ValueError("unknown key")
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

    return Ed25519PublicKey.from_public_bytes(raw)


def _check():
    out = {"tier": "base", "valid": False, "customer": "", "expires": "", "reason": "none"}
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
    except OSError:
        return out
    except ValueError:
        out["reason"] = "invalid"
        return out
    try:
        _key().verify(base64.b64decode(str(d.get("sig", ""))), canon(d))
        from . import tier

        t = tier.normalize(d.get("tier")) if d.get("tier") else None
        if not t:
            raise ValueError("tier")
        exp = str(d.get("expires") or "")
        late = None
        if exp:
            late = (date.today() - date.fromisoformat(exp)).days
    except Exception:
        out["reason"] = "invalid"
        return out
    out.update(customer=str(d.get("customer", ""))[:60], expires=exp)
    if late is not None and late > GRACE_DAYS:
        out["reason"] = "expired"
        return out
    out.update(tier=t, valid=True, reason="grace" if (late is not None and late > 0) else "")
    return out


def status():
    """{tier, valid, customer, expires, reason} with reason: none, invalid, expired, grace or empty."""
    try:
        st = FILE.stat()
        sig = (st.st_mtime_ns, st.st_size)
    except OSError:
        sig = None
    if _C["v"] is not None and _C["sig"] == sig and time.time() - _C["at"] < 60:
        return _C["v"]
    v = _check()
    _C.update(sig=sig, at=time.time(), v=v)
    return v


def tier():
    if DEV:  # tests only: the code itself has to be edited to turn this on
        from . import tier as T

        return T.normalize(os.environ.get("ARCHIE_TIER", "")) or "base"
    s = status()
    return s["tier"] if s["valid"] else "base"


def active():
    """True when this copy may run: a valid signed license (or the test harness)."""
    return True if DEV else bool(status()["valid"])


def info(lang="fr"):
    from . import tier as T

    s = dict(status())
    s["label"] = T.label(lang)
    return s
