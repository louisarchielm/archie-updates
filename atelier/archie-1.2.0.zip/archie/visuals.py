"""Things Archie can put on screen: charts, tables, drawings, photos, the agenda. Everything is checked before it is shown."""
import re
import threading
from datetime import datetime, timedelta
from urllib.parse import quote

import requests

_PHOTO = {}
_LOCK = threading.Lock()


def _num(x):
    try:
        v = float(x)
        return v if abs(v) < 1e12 else None
    except (TypeError, ValueError):
        return None


def clean(v):
    """Returns a safe version of a visual asked for by the AI, or None."""
    if not isinstance(v, dict):
        return None
    t, title = v.get("type"), str(v.get("title", ""))[:90]
    if t == "chart":
        labels = [str(x)[:28] for x in (v.get("labels") or [])][:24]
        series = v.get("series") or [{"name": "", "values": v.get("values")}]
        out = []
        for s in series[:4]:
            vals = [_num(x) for x in (s.get("values") or [])][:24]
            if len(vals) == len(labels) and labels and all(x is not None for x in vals):
                out.append({"name": str(s.get("name", ""))[:24], "values": vals})
        if not out:
            return None
        return {"type": "chart", "kind": v.get("kind") if v.get("kind") in ("bar", "line", "pie") else "bar",
                "title": title, "labels": labels, "series": out}
    if t == "table":
        cols = [str(c)[:30] for c in (v.get("columns") or [])][:8]
        rows = [[str(c)[:60] for c in r][:len(cols)] for r in (v.get("rows") or []) if isinstance(r, list)][:20]
        return {"type": "table", "title": title, "columns": cols, "rows": rows} if cols and rows else None
    if t == "model3d":
        shapes = ("box", "cylinder", "cone", "sphere")
        parts = []
        for p in (v.get("parts") or [])[:60]:
            if not isinstance(p, dict) or p.get("shape") not in shapes:
                continue
            pos = [_num(x) for x in (p.get("pos") or [0, 0, 0])][:3]
            size = [_num(x) for x in (p.get("size") or [1, 1, 1])][:3]
            if len(pos) != 3 or len(size) != 3 or any(x is None or abs(x) > 1000 for x in pos + size) or any(x <= 0 for x in size):
                continue
            parts.append({"shape": p["shape"], "pos": pos, "size": size, "label": str(p.get("label", ""))[:24]})
        return {"type": "model3d", "title": title, "parts": parts} if parts else None
    if t == "svg":
        svg = str(v.get("svg", ""))[:40000].strip()
        if not svg.lower().startswith("<svg"):
            return None
        svg = re.sub(r"(?is)<(script|foreignObject|iframe|image|use)\b.*?(</\1>|/>)", "", svg)
        svg = re.sub(r"(?i)\son\w+\s*=\s*(\"[^\"]*\"|'[^']*')", "", svg)
        svg = re.sub(r"(?i)(href|xlink:href)\s*=\s*(\"[^\"]*\"|'[^']*')", "", svg)
        if "xmlns" not in svg[:300]:
            svg = svg.replace("<svg", '<svg xmlns="http://www.w3.org/2000/svg"', 1)
        return {"type": "svg", "title": title, "svg": svg}
    if t == "photo":
        q = str(v.get("query", "")).strip()[:80]
        return {"type": "photo", "title": title or q, "query": q} if q else None
    if t == "web":
        u = str(v.get("url", ""))
        return {"type": "web", "title": title, "url": u} if re.match(r"^https://", u) else None
    if t == "agenda":
        return v
    return None


def photo(query):
    """(bytes, content_type) of a picture for the topic, from Wikipedia (free). Raises if none is found."""
    with _LOCK:
        if query in _PHOTO:
            return _PHOTO[query]
    h = {"User-Agent": "Archie/1.0 (personal assistant)"}
    s = requests.get("https://en.wikipedia.org/w/rest.php/v1/search/title", params={"q": query, "limit": 1}, headers=h, timeout=10)
    pages = s.json().get("pages") or []
    if not pages:
        raise LookupError("no page")
    j = requests.get("https://en.wikipedia.org/api/rest_v1/page/summary/" + quote(pages[0]["key"], safe=""), headers=h, timeout=10).json()
    url = (j.get("originalimage") or j.get("thumbnail") or {}).get("source")
    if not url:
        raise LookupError("no image")
    if (j.get("thumbnail") or {}).get("source") and (j.get("originalimage") or {}).get("width", 0) > 1600:
        url = j["thumbnail"]["source"]  # the big original can be huge
    r = requests.get(url, headers=h, timeout=20)
    r.raise_for_status()
    out = (r.content, r.headers.get("Content-Type", "image/jpeg"))
    with _LOCK:
        _PHOTO[query] = out
    return out


_J = ["lundi", "mardi", "mercredi", "jeudi", "vendredi", "samedi", "dimanche"]
_M = ["janv.", "févr.", "mars", "avr.", "mai", "juin", "juil.", "août", "sept.", "oct.", "nov.", "déc."]


def agenda(first_day, days, lang, highlight=""):
    """Agenda visual for `days` days starting at the date `first_day`. Reads the real calendar."""
    from . import icloud

    start = datetime.combine(first_day, datetime.min.time(), icloud.TZ)
    evs = icloud.events(start, start + timedelta(days=days))
    out = []
    for i in range(days):
        d = (start + timedelta(days=i)).date()
        items = []
        for e in evs:
            ed = e["start"].date() if e["timed"] else e["start"]
            if ed != d:
                continue
            when = (f"{e['start']:%H:%M}–{e['end']:%H:%M}" if e["timed"] else ("Toute la journée" if lang == "fr" else "All day"))
            items.append({"time": when, "title": e["title"][:70], "new": bool(highlight) and e["title"] == highlight})
        label = (f"{_J[d.weekday()].capitalize()} {d.day} {_M[d.month - 1]}" if lang == "fr" else f"{d:%A, %b} {d.day}")
        out.append({"label": label, "events": items, "today": d == datetime.now(icloud.TZ).date()})
    return {"type": "agenda", "title": "Agenda", "days": out}
