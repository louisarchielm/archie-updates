"""Archie's shared memory: one place where emails, actions, calls and conversations are kept, on this PC only."""
import re
import sqlite3
import threading
import time
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
DB = HERE / "archie-memory.db"
_lock = threading.Lock()


def _conn():
    c = sqlite3.connect(DB, timeout=30)
    c.row_factory = sqlite3.Row
    c.execute("CREATE TABLE IF NOT EXISTS events(id INTEGER PRIMARY KEY, ts REAL, channel TEXT, kind TEXT, text TEXT)")
    return c


def remember(kind, text, channel="system"):
    """kind: email, action, call, note, chat_user, chat_archie. channel: where it happened."""
    text = (text or "").strip()
    if not text:
        return
    with _lock:
        c = _conn()
        c.execute("INSERT INTO events(ts, channel, kind, text) VALUES (?,?,?,?)", (time.time(), channel, kind, text[:4000]))
        c.commit()
        c.close()


def _rows(sql, args=()):
    with _lock:
        c = _conn()
        rows = [dict(r) for r in c.execute(sql, args).fetchall()]
        c.close()
    return rows


def recent(n=20, kinds=None):
    if kinds:
        q = ",".join("?" * len(kinds))
        rows = _rows(f"SELECT * FROM events WHERE kind IN ({q}) ORDER BY id DESC LIMIT ?", (*kinds, n))
    else:
        rows = _rows("SELECT * FROM events ORDER BY id DESC LIMIT ?", (n,))
    return list(reversed(rows))


def search(query, n=8):
    """Events that share words with the question (simple word match), best first."""
    words = {w for w in re.findall(r"[\w'-]+", query.lower()) if len(w) > 3}
    if not words:
        return []
    scored = []
    for r in _rows("SELECT * FROM events WHERE kind NOT IN ('chat_user','chat_archie') ORDER BY id DESC LIMIT 500"):
        low = r["text"].lower()
        s = sum(w in low for w in words)
        if s:
            scored.append((s, r["id"], r))
    scored.sort(key=lambda x: (-x[0], -x[1]))
    return [r for _, _, r in scored[:n]]


def when(ts):
    return time.strftime("%a %b %d %H:%M", time.localtime(ts))


LANG_FILE = HERE / "archie-lang.txt"


def get_lang():
    try:
        v = LANG_FILE.read_text(encoding="utf-8").strip()
        return v if v in ("en", "fr") else "en"
    except OSError:
        return "en"


def set_lang(lang):
    if lang in ("en", "fr") and lang != get_lang():
        try:
            LANG_FILE.write_text(lang, encoding="utf-8")
        except OSError:
            pass
