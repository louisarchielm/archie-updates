"""Microsoft mail (Outlook, Hotmail, Microsoft 365) through Microsoft's own sign-in. No password is stored."""
import hashlib
import json
import os
import threading
from datetime import datetime, timedelta, timezone
from pathlib import Path

import requests

HERE = Path(__file__).resolve().parent.parent
CACHE = HERE / "archie-ms-token.json"  # the sign-in token: a secret, never uploaded to GitHub
STATE = HERE / "archie-ms-state.json"
SCOPES = ["Mail.Read", "Mail.Send"]
GRAPH = "https://graph.microsoft.com/v1.0"


def enabled():
    return bool(os.environ.get("MS_CLIENT_ID")) and CACHE.exists()


def _app():
    import msal

    cid = os.environ.get("MS_CLIENT_ID")
    if not cid:
        raise SystemExit("Enter the Microsoft application ID in Archie's settings first.")
    cache = msal.SerializableTokenCache()
    if CACHE.exists():
        cache.deserialize(CACHE.read_text(encoding="utf-8"))
    app = msal.PublicClientApplication(cid, authority="https://login.microsoftonline.com/common", token_cache=cache)
    return app, cache


def _store(cache):
    if cache.has_state_changed:
        CACHE.write_text(cache.serialize(), encoding="utf-8")


def sign_in():
    """Shows a short code. The owner types it at microsoft.com/devicelogin and signs in once."""
    app, cache = _app()
    flow = app.initiate_device_flow(scopes=SCOPES)
    if "user_code" not in flow:
        raise SystemExit("Could not start the sign-in: " + str(flow.get("error_description", flow))[:300])
    print("\n" + flow["message"] + "\n", flush=True)
    res = app.acquire_token_by_device_flow(flow)
    if "access_token" not in res:
        raise SystemExit("Sign-in failed: " + str(res.get("error_description", res))[:300])
    _store(cache)
    return (res.get("id_token_claims") or {}).get("preferred_username", "")


_FLOW = {"state": "idle", "msg": "", "user": ""}


def begin_sign_in():
    """Starts the Microsoft sign-in from the app. Returns the web address and the short code the owner types there himself."""
    app, cache = _app()
    flow = app.initiate_device_flow(scopes=SCOPES)
    if "user_code" not in flow:
        raise RuntimeError("Could not start the sign-in: " + str(flow.get("error_description", flow))[:200])
    _FLOW.update(state="pending", user="", msg="")

    def wait():
        try:
            res = app.acquire_token_by_device_flow(flow)
            if "access_token" in res:
                _store(cache)
                _FLOW.update(state="ok", user=(res.get("id_token_claims") or {}).get("preferred_username", ""))
            else:
                _FLOW.update(state="error", msg=str(res.get("error_description", res))[:200])
        except BaseException as e:
            _FLOW.update(state="error", msg=str(e)[:200])
    threading.Thread(target=wait, daemon=True).start()
    return {"url": flow.get("verification_uri", "https://microsoft.com/devicelogin"), "code": flow["user_code"]}


def sign_in_state():
    return dict(_FLOW, signed=enabled())


def _token():
    app, cache = _app()
    accounts = app.get_accounts()
    if not accounts:
        raise SystemExit("Not signed in to Microsoft yet. Sign in to Outlook again in Archie's settings.")
    res = app.acquire_token_silent(SCOPES, account=accounts[0])
    _store(cache)
    if not res or "access_token" not in res:
        raise SystemExit("The Microsoft sign-in expired. Sign in to Outlook again in Archie's settings.")
    return res["access_token"]


def _state():
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def fetch_new(limit=10):
    """New inbox messages since the last check (first run: the last 24 hours). Nothing is marked as read."""
    tok = _token()
    st = _state()
    since = st.get("last") or (datetime.now(timezone.utc) - timedelta(days=1)).strftime("%Y-%m-%dT%H:%M:%SZ")
    r = requests.get(
        f"{GRAPH}/me/mailFolders/inbox/messages",
        headers={"Authorization": "Bearer " + tok, "Prefer": 'outlook.body-content-type="text"'},
        params={"$filter": f"receivedDateTime gt {since}", "$orderby": "receivedDateTime asc", "$top": str(limit),
                "$select": "id,subject,from,receivedDateTime,body,internetMessageId,internetMessageHeaders"},
        timeout=60)
    if r.status_code != 200:
        raise RuntimeError(f"Microsoft mail error {r.status_code}: {r.text[:200]}")
    out, last = [], None
    for m in r.json().get("value", []):
        addr = (m.get("from") or {}).get("emailAddress") or {}
        heads = {h.get("name", "").lower(): h.get("value", "") for h in m.get("internetMessageHeaders") or []}
        out.append({
            "uid": hashlib.sha1(m["id"].encode()).hexdigest()[:12],  # short, fits in a Telegram button
            "graph_id": m["id"],
            "from_name": addr.get("name", ""), "from": addr.get("address", ""),
            "subject": m.get("subject") or "(no subject)",
            "message_id": m.get("internetMessageId", ""),
            "bulk": bool("list-unsubscribe" in heads or heads.get("precedence", "").lower() in ("bulk", "list")),
            "body": ((m.get("body") or {}).get("content") or "")[:3000],
        })
        last = m.get("receivedDateTime") or last
    if last:
        st["last"] = last
        STATE.write_text(json.dumps(st), encoding="utf-8")
    return out


def latest(n=1, scan=25):
    r = requests.get(f"{GRAPH}/me/mailFolders/inbox/messages",
                     headers={"Authorization": "Bearer " + _token(), "Prefer": 'outlook.body-content-type="text"'},
                     params={"$orderby": "receivedDateTime desc", "$top": str(scan),
                             "$select": "id,subject,from,body,internetMessageId"}, timeout=60)
    if r.status_code != 200:
        raise RuntimeError(f"Microsoft mail error {r.status_code}: {r.text[:200]}")
    out = []
    for m in r.json().get("value", []):
        addr = (m.get("from") or {}).get("emailAddress") or {}
        out.append({"uid": m["id"][:12], "graph_id": m["id"], "from_name": addr.get("name", ""),
                    "from": addr.get("address", ""), "subject": m.get("subject") or "(no subject)",
                    "message_id": m.get("internetMessageId", ""), "bulk": False,
                    "body": ((m.get("body") or {}).get("content") or "")[:3000]})
    return out[:n]


def send_reply(graph_id, body):
    """Replies in the same conversation; the original is quoted below the reply."""
    r = requests.post(f"{GRAPH}/me/messages/{graph_id}/reply",
                      headers={"Authorization": "Bearer " + _token()}, json={"comment": body}, timeout=60)
    if r.status_code not in (200, 202):
        raise RuntimeError(f"Microsoft could not send ({r.status_code}): {r.text[:200]}")


def send_new(to, subject, body):
    r = requests.post(f"{GRAPH}/me/sendMail", headers={"Authorization": "Bearer " + _token()}, timeout=60,
                      json={"message": {"subject": subject, "body": {"contentType": "Text", "content": body},
                                        "toRecipients": [{"emailAddress": {"address": to}}]}})
    if r.status_code not in (200, 202):
        raise RuntimeError(f"Microsoft could not send ({r.status_code}): {r.text[:200]}")


def whoami():
    r = requests.get(f"{GRAPH}/me", headers={"Authorization": "Bearer " + _token()}, timeout=30)
    r.raise_for_status()
    return r.json().get("mail") or r.json().get("userPrincipalName", "")
