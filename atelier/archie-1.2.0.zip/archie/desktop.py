"""Archie working the open apps on the owner's Windows PC: type in Word, fill Excel cells, paste text into the front window, read what is open.
Done through Windows' own COM automation (PowerShell, nothing to install). Every change is confirmed first by the caller."""
import json
import os
import subprocess
import sys
import tempfile

WINDOWS = sys.platform.startswith("win")
_HEAD = r'''
$ErrorActionPreference = "Stop"
$d = Get-Content -Raw -Encoding UTF8 -LiteralPath $args[0] | ConvertFrom-Json
function Get-App($name) {
  try { return [Runtime.InteropServices.Marshal]::GetActiveObject($name) } catch { $a = New-Object -ComObject $name; $a.Visible = $true; return $a }
}
'''
WORD_TYPE = _HEAD + r'''
$w = Get-App "Word.Application"
if ($w.Documents.Count -eq 0 -or $d.new) { $null = $w.Documents.Add() }
$w.Visible = $true
$sel = $w.Selection
$sel.EndKey(6) | Out-Null
$sel.TypeText([string]$d.text)
if ($d.newline) { $sel.TypeParagraph() }
"ok"
'''
EXCEL_FILL = _HEAD + r'''
$x = Get-App "Excel.Application"
if ($x.Workbooks.Count -eq 0 -or $d.new) { $null = $x.Workbooks.Add() }
$x.Visible = $true
$ws = $x.ActiveSheet
$start = $ws.Range([string]$d.start)
$r0 = $start.Row; $c0 = $start.Column
$rows = @($d.rows)
if ($rows.Count -gt 0 -and ($rows[0] -isnot [array])) { $rows = ,$rows }
$i = 0
foreach ($row in $rows) {
  if ($row -isnot [array]) { $row = @($row) }
  $j = 0
  foreach ($v in $row) {
    $cell = $ws.Cells.Item($r0 + $i, $c0 + $j)
    if ($v -is [string] -and $v.StartsWith("=")) { $cell.Formula = $v } else { $cell.Value2 = $v }
    $j++
  }
  $i++
}
$ws.Columns.AutoFit() | Out-Null
"ok"
'''
PASTE = _HEAD + r'''
Add-Type -AssemblyName System.Windows.Forms
Set-Clipboard -Value ([string]$d.text)
Start-Sleep -Milliseconds 250
[System.Windows.Forms.SendKeys]::SendWait("^v")
"ok"
'''
READ_WORD = _HEAD + r'''
$w = [Runtime.InteropServices.Marshal]::GetActiveObject("Word.Application")
$t = $w.ActiveDocument.Content.Text
if ($t.Length -gt 6000) { $t = $t.Substring(0, 6000) }
$t
'''
READ_EXCEL = _HEAD + r'''
$x = [Runtime.InteropServices.Marshal]::GetActiveObject("Excel.Application")
$ws = $x.ActiveSheet
$ur = $ws.UsedRange
$out = @()
$rows = [Math]::Min($ur.Rows.Count, 40); $cols = [Math]::Min($ur.Columns.Count, 12)
for ($i = 1; $i -le $rows; $i++) { $line = @(); for ($j = 1; $j -le $cols; $j++) { $line += [string]$ur.Cells.Item($i, $j).Text }; $out += ($line -join " | ") }
$out -join "`n"
'''


def _run(script, data, timeout=60):
    if not WINDOWS:
        raise RuntimeError("Cette fonction demande Windows." if False else "This needs Windows.")
    with tempfile.TemporaryDirectory() as td:
        sp, dp = os.path.join(td, "a.ps1"), os.path.join(td, "d.json")
        with open(sp, "w", encoding="utf-8-sig") as f:
            f.write(script)
        with open(dp, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False)
        r = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-File", sp, dp], capture_output=True, text=True, timeout=timeout, encoding="utf-8", errors="replace")
    if r.returncode != 0:
        msg = (r.stderr or r.stdout or "error").strip().splitlines()
        raise RuntimeError(msg[0][:160] if msg else "error")
    return (r.stdout or "").strip()


def word_type(text, new=False, newline=True):
    return _run(WORD_TYPE, {"text": str(text)[:20000], "new": bool(new), "newline": bool(newline)})


def excel_fill(rows, start="A1", new=False):
    rows = [[(c if isinstance(c, (int, float)) else str(c)) for c in r][:30] for r in (rows or [])][:200]
    if not rows:
        raise ValueError("no data")
    import re

    if not re.fullmatch(r"[A-Za-z]{1,3}[0-9]{1,5}", str(start)):
        start = "A1"
    return _run(EXCEL_FILL, {"rows": rows, "start": start, "new": bool(new)})


def paste_text(text):
    return _run(PASTE, {"text": str(text)[:5000]})


def read_word():
    return _run(READ_WORD, {})


def read_excel():
    return _run(READ_EXCEL, {})
