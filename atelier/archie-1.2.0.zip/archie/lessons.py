"""Archie learns from his mistakes: what the owner corrects, and what fails. Lessons are short rules kept in archie-lessons.json
and added to everything Archie asks the AI, so the same mistake is not repeated."""
import json
import re
import time
from pathlib import Path

FILE = Path("archie-lessons.json")
FAILS = Path("archie-failures.json")
MAX = 100
DISTILL = """An AI assistant made a mistake and its owner corrected it.
Owner asked: "{asked}"
Assistant answered or did: "{answered}"
Owner's correction: "{correction}"
Write ONE short rule (max 25 words, imperative, general enough to apply next time, in English) that stops this mistake from happening again.
If the correction is only about a one-time fact and no rule helps, return an empty rule.
JSON only: {{"rule": "..."}}"""
REVIEW = """These problems happened to an AI assistant recently (what was attempted: error):
{items}
Write 1 to 3 short rules (max 25 words each, imperative, English) the assistant should follow to avoid or handle these better. If there is nothing useful to learn, return an empty list.
JSON only: {{"rules": ["..."]}}"""


def _load(p):
    try:
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _n(s):
    return set(w for w in re.findall(r"\w+", (s or "").lower()) if len(w) > 3)


def load():
    return _load(FILE)


def add(rule):
    rule = (rule or "").strip().strip('"')[:220]
    if len(rule) < 8:
        return None
    v = load()
    nw = _n(rule)
    for l in v:
        ow = _n(l["text"])
        if nw and ow and len(nw & ow) / min(len(nw), len(ow)) >= 0.7:
            l["hits"] = l.get("hits", 1) + 1  # same lesson again: it matters more
            l["text"] = rule if len(rule) > len(l["text"]) else l["text"]
            FILE.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding="utf-8")
            return l
    new = {"text": rule, "created": time.strftime("%Y-%m-%d"), "ts": time.time(), "hits": 1}
    v.append(new)
    v.sort(key=lambda l: (l.get("hits", 1), l.get("ts", 0), l["created"]))
    v = v[-MAX:]
    FILE.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding="utf-8")
    try:
        from . import feedback

        feedback.consider_async(rule)  # a generic mistake may become an anonymous report, only with his consent and his yes
    except Exception:
        pass
    return new


def forget(words):
    w = _n(words)
    v = load()
    keep = [l for l in v if not (w and len(w & _n(l["text"])) >= max(1, len(w) // 2))]
    FILE.write_text(json.dumps(keep, ensure_ascii=False, indent=1), encoding="utf-8")
    return len(v) - len(keep)


def for_prompt(query="", limit=3200):
    """The lessons to put in front of the AI: the ones that fit what is being asked come first, then the most repeated.
    They are listed oldest to newest, because when two lessons disagree the newest wins."""
    q = _n(query)
    v = sorted(load(), key=lambda l: (-(3 * len(q & _n(l["text"])) + l.get("hits", 1)), -l.get("ts", 0)))  # same weight: the newest first
    chosen, n = [], 0
    for l in v:
        line = f"- ({l['created']}) {l['text']}"
        if n + len(line) > limit:
            continue  # a long one does not fit: a shorter one still can
        chosen.append(l)
        n += len(line)
    chosen.sort(key=lambda l: (l["created"], l.get("ts", 0)))
    return ("\n\nLessons learned from the owner's corrections and from past mistakes. Always follow them. If two lessons disagree, the most recent one wins:\n"
            + "\n".join(f"- ({l['created']}) {l['text']}" for l in chosen)) if chosen else ""


def learn_from_correction(asked, answered, correction):
    from . import brain

    d = brain.ask_json(DISTILL.format(asked=asked[:300], answered=answered[:300], correction=correction[:300]),
                       "You distill one rule from a correction. JSON only.", max_tokens=150)
    rule = (d or {}).get("rule", "") if d else ""
    return add(rule) if rule else None


JUDGE = """An AI assistant answered its owner, and the owner then said something. Decide if the owner is correcting the assistant or telling it how he wants things done from now on.
Owner asked: "{asked}"
Assistant answered or did: "{answered}"
Owner then said: "{correction}"
If it is a correction or a lasting preference, return the ONE rule (max 25 words, imperative, general enough to apply next time, English).
If the owner is only answering, thanking, or asking something new, it is not a correction.
JSON only: {{"correction": true or false, "rule": "..."}}"""


def judge(asked, answered, text):
    """For corrections that do not use the usual words ("rather do it this way", "too long"): the AI decides. Returns the lesson or None."""
    from . import brain

    d = brain.ask_json(JUDGE.format(asked=asked[:300], answered=answered[:300], correction=text[:300]), "You detect corrections. JSON only.", max_tokens=150)
    if d and d.get("correction") is True and str(d.get("rule") or "").strip():
        return add(str(d["rule"]))
    return None


def record_failure(where, error):
    v = _load(FAILS)
    v.append({"ts": time.time(), "where": str(where)[:80], "error": str(error)[:160]})
    FAILS.write_text(json.dumps(v[-100:], ensure_ascii=False), encoding="utf-8")


def failure_count():
    return len(_load(FAILS))


def review():
    """Looks at the failures since the last review and turns the useful ones into lessons. Returns how many lessons were added."""
    from . import brain

    v = _load(FAILS)
    fresh = [f for f in v if not f.get("seen")]
    if len(fresh) < 3:
        return 0
    seen = {}
    for f in fresh:
        seen[(f["where"], f["error"])] = seen.get((f["where"], f["error"]), 0) + 1
    items = "\n".join(f"- {w}: {e} (x{n})" for (w, e), n in list(seen.items())[:12])
    d = brain.ask_json(REVIEW.format(items=items), "You turn failures into rules. JSON only.", max_tokens=300)
    n = 0
    for r in ((d or {}).get("rules") or [])[:3] if d else []:
        if add(str(r)):
            n += 1
    for f in v:
        f["seen"] = True
    FAILS.write_text(json.dumps(v, ensure_ascii=False), encoding="utf-8")
    return n
