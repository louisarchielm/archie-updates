"""The big clients: the only senders whose emails can make Archie phone the owner (and only if the email is critical)."""
import json
import os
import re
import threading
import time
from pathlib import Path

FILE = Path("archie-clients.json")


def load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(v):
    FILE.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding="utf-8")


def _n(s):
    return " ".join(re.findall(r"\w+", (s or "").lower()))


def add(name, email=""):
    v = [c for c in load() if _n(c["name"]) != _n(name)]
    v.append({"name": name.strip()[:60], "email": (email or "").lower()})
    _save(v)


def remove(name):
    v, n = load(), _n(name)
    keep = [c for c in v if n not in _n(c["name"]) and _n(c["name"]) not in n and not (c["email"] and n in c["email"])]
    _save(keep)
    return len(v) - len(keep)


def is_big(from_name, from_email):
    e, n = (from_email or "").lower(), _n(from_name)
    for c in load():
        if c["email"] and (c["email"] == e or (c["email"].startswith("@") and e.endswith(c["email"]))):
            return True
        if n and _n(c["name"]) and (_n(c["name"]) in n or n in _n(c["name"])):
            return True
    return False


# ---------- the word for them (the owner picks it) ----------
def label(fr=True, plural=False):
    """'client prioritaire' by default; the owner can set ARCHIE_VIP_LABEL (e.g. 'client clé')."""
    w = (os.environ.get("ARCHIE_VIP_LABEL") or "").strip()[:30]
    if not w:
        w = "client prioritaire" if fr else "priority client"
    if plural:
        pl = lambda x: x if x.endswith(("s", "x")) or len(x) < 3 else x + "s"
        w = " ".join(pl(x) for x in w.split()) if fr else " ".join(w.split()[:-1] + [pl(w.split()[-1])])
    return w


# ---------- first contact: who has written before ----------
SEEN = Path("archie-seen.json")
_L = threading.Lock()
ASKING = []  # senders Archie is waiting to ask about, oldest first: {name, email, ts}


def _seen():
    try:
        return json.loads(SEEN.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _key(email, name=""):
    return (email or "").lower().strip() or _n(name)


def is_seen(email, name=""):
    return _key(email, name) in _seen()


def mark_seen(email, name="", answer="seen"):
    with _L:
        d = _seen()
        d[_key(email, name)] = {"name": (name or "")[:60], "answer": answer, "ts": int(time.time())}
        if len(d) > 2000:  # keep the file small: drop the oldest
            for k in sorted(d, key=lambda k: d[k].get("ts", 0))[:200]:
                d.pop(k, None)
        SEEN.write_text(json.dumps(d, ensure_ascii=False), encoding="utf-8")


def first_contact(name, email):
    """True (and queued for the question) if this sender is new and not already a priority client."""
    if not (email or name) or is_seen(email, name):
        return False
    if is_big(name, email):
        mark_seen(email, name, "client")
        return False
    mark_seen(email, name, "asked")  # asked once, never again, even if the owner ignores it
    with _L:
        ASKING.append({"name": (name or email)[:60], "email": (email or "").lower(), "ts": time.time()})
        del ASKING[:-5]
    return True


def next_question():
    with _L:
        return ASKING[0] if ASKING else None


def answer(yes):
    """Resolve the oldest question. yes=True: add as priority client; False: remember as 'no'."""
    with _L:
        q = ASKING.pop(0) if ASKING else None
    if not q:
        return None
    if yes:
        add(q["name"], q["email"])
    mark_seen(q["email"], q["name"], "client" if yes else "no")
    return q
