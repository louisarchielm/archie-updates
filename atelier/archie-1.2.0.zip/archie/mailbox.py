"""Reads mail (IMAP) and sends replies (SMTP). Works with any provider that gives an app password."""
import imaplib
import json
import os
import re
import smtplib
from datetime import datetime, timedelta
from email import message_from_bytes
from email.header import decode_header, make_header
from email.message import EmailMessage
from email.utils import formatdate, make_msgid, parseaddr
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
STATE = HERE / "archie-mail-state.json"

HOSTS = {
    "outlook.com": ("outlook.office365.com", "smtp.office365.com"),
    "hotmail.com": ("outlook.office365.com", "smtp.office365.com"),
    "live.com": ("outlook.office365.com", "smtp.office365.com"),
    "gmail.com": ("imap.gmail.com", "smtp.gmail.com"),
    "icloud.com": ("imap.mail.me.com", "smtp.mail.me.com"),
    "me.com": ("imap.mail.me.com", "smtp.mail.me.com"),
    "yahoo.com": ("imap.mail.yahoo.com", "smtp.mail.yahoo.com"),
    "videotron.ca": ("mail.videotron.ca", "smtp.videotron.ca"),
}


def settings():
    user, pw = os.environ.get("MAIL_USER"), os.environ.get("MAIL_APP_PASSWORD")
    if not user or not pw:
        raise SystemExit("Open Archie's settings (gear at the top) and enter the mail address and app password.")
    imap, smtp = os.environ.get("MAIL_IMAP_HOST"), os.environ.get("MAIL_SMTP_HOST")
    known = HOSTS.get(user.split("@")[-1].lower(), (None, None))
    imap, smtp = imap or known[0], smtp or known[1]
    if not imap or not smtp:
        raise SystemExit("Unknown mail provider. Set MAIL_IMAP_HOST and MAIL_SMTP_HOST (ask Claude).")
    return user, pw, imap, smtp


def _load():
    try:
        return json.loads(STATE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _save(d):
    STATE.write_text(json.dumps(d), encoding="utf-8")


def _text(msg):
    plain, html = "", ""
    for part in msg.walk():
        if part.get_content_maintype() != "text" or part.get_filename():
            continue
        try:
            body = part.get_payload(decode=True).decode(part.get_content_charset() or "utf-8", "replace")
        except Exception:
            continue
        if part.get_content_subtype() == "plain":
            plain += body
        elif part.get_content_subtype() == "html":
            html += body
    if not plain and html:
        plain = re.sub(r"<[^>]+>", " ", re.sub(r"(?is)<(script|style).*?</\1>", " ", html))
    return re.sub(r"\n{3,}", "\n\n", re.sub(r"[ \t]+", " ", plain)).strip()


def fetch_new(limit=10):
    """New messages since the last check (first run: the last 24 hours). Does not mark anything as read."""
    from . import msgraph

    if msgraph.enabled():
        return msgraph.fetch_new(limit)
    user, pw, imap_host, _ = settings()
    state = _load()
    last = int(state.get("last_uid", 0))
    out = []
    m = imaplib.IMAP4_SSL(imap_host)
    try:
        m.login(user, pw)
        m.select("INBOX", readonly=True)
        if last:
            _, data = m.uid("search", None, f"UID {last + 1}:*")
        else:
            since = (datetime.now() - timedelta(days=1)).strftime("%d-%b-%Y")
            _, data = m.uid("search", None, "SINCE", since)
        uids = [int(u) for u in (data[0] or b"").split() if int(u) > last]
        for uid in uids[-limit:]:
            _, d = m.uid("fetch", str(uid), "(BODY.PEEK[])")
            if not d or not d[0] or not isinstance(d[0], tuple):
                continue
            msg = message_from_bytes(d[0][1])
            name, addr = parseaddr(str(make_header(decode_header(msg.get("From", "")))))
            out.append({
                "uid": uid, "from_name": name, "from": addr,
                "subject": str(make_header(decode_header(msg.get("Subject", "")))),
                "message_id": msg.get("Message-ID", ""),
                "bulk": bool(msg.get("List-Unsubscribe") or msg.get("Precedence", "").lower() in ("bulk", "list")),
                "body": _text(msg)[:3000],
            })
        if uids:
            state["last_uid"] = max(uids)
            _save(state)
    finally:
        try:
            m.logout()
        except Exception:
            pass
    return out


def send_reply(to, subject, body, in_reply_to="", graph_id=""):
    if graph_id:
        from . import msgraph

        return msgraph.send_reply(graph_id, body)
    user, pw, _, smtp_host = settings()
    msg = EmailMessage()
    msg["From"], msg["To"] = user, to
    msg["Subject"] = subject if subject.lower().startswith(("re:", "réf", "ref:")) else "Re: " + subject
    msg["Date"], msg["Message-ID"] = formatdate(localtime=True), make_msgid()
    if in_reply_to:
        msg["In-Reply-To"] = msg["References"] = in_reply_to
    msg.set_content(body)
    with smtplib.SMTP(smtp_host, 587, timeout=60) as s:
        s.starttls()
        s.login(user, pw)
        s.send_message(msg)


def send_new(to, subject, body):
    """Sends a brand-new email (not a reply)."""
    if msgraph_on():
        from . import msgraph

        return msgraph.send_new(to, subject, body)
    user, pw, _, smtp_host = settings()
    msg = EmailMessage()
    msg["From"], msg["To"], msg["Subject"] = user, to, subject
    msg["Date"], msg["Message-ID"] = formatdate(localtime=True), make_msgid()
    msg.set_content(body)
    with smtplib.SMTP(smtp_host, 587, timeout=60) as s:
        s.starttls()
        s.login(user, pw)
        s.send_message(msg)


def msgraph_on():
    try:
        from . import msgraph

        return msgraph.enabled()
    except BaseException:
        return False


def latest(n=1, scan=25):
    """The most recent messages that people sent you (newest first), skipping your own and newsletters when possible.
    Does not change what Archie considers 'new'."""
    from . import msgraph

    if msgraph.enabled():
        return msgraph.latest(n, scan)
    user, pw, imap_host, _ = settings()
    found = []
    m = imaplib.IMAP4_SSL(imap_host)
    try:
        m.login(user, pw)
        m.select("INBOX", readonly=True)
        _, data = m.uid("search", None, "ALL")
        for uid in [int(u) for u in (data[0] or b"").split()][-scan:][::-1]:
            _, d = m.uid("fetch", str(uid), "(BODY.PEEK[])")
            if not d or not d[0] or not isinstance(d[0], tuple):
                continue
            msg = message_from_bytes(d[0][1])
            name, addr = parseaddr(str(make_header(decode_header(msg.get("From", "")))))
            found.append({
                "uid": uid, "from_name": name, "from": addr,
                "subject": str(make_header(decode_header(msg.get("Subject", "")))),
                "message_id": msg.get("Message-ID", ""),
                "bulk": bool(msg.get("List-Unsubscribe") or msg.get("Precedence", "").lower() in ("bulk", "list")),
                "body": _text(msg)[:3000],
            })
    finally:
        try:
            m.logout()
        except Exception:
            pass
    good = [x for x in found if x["from"].lower() != user.lower() and not x["bulk"]]
    return (good or found)[:n]
