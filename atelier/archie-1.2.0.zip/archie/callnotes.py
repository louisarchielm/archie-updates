"""Call notes: the owner starts a note mode (phone call, meeting), Archie stays silent and the page transcribes.
At the end he keeps a short summary (and the transcript) so he can talk about it later."""
import json
import os
import re
import threading
import time

from . import brain, memory

FILE = memory.HERE / "archie-calls.json"
_lock = threading.Lock()
MAX_CALLS = 40
MAX_TEXT = 60000


def _load():
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        return d if isinstance(d, list) else []
    except (OSError, ValueError):
        return []


def _save(calls):
    tmp = FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(calls[-MAX_CALLS:], ensure_ascii=False), encoding="utf-8")
    os.replace(tmp, FILE)


def _llm():
    return bool(os.environ.get("ARCHIE_LLM_KEY") or os.environ.get("ARCHIE_LLM_URL") or os.environ.get("OLLAMA_URL") or os.environ.get("OLLAMA_MODEL"))


def _fallback(text, fr):
    words = text.split()
    head = " ".join(words[:60]) + ("…" if len(words) > 60 else "")
    return ("Notes brutes : " if fr else "Raw notes: ") + head


def summarize(text, fr):
    prompt = ("Here is the transcript of one side of a phone call or meeting, taken by speech recognition (errors are possible; the other person may be missing). "
              "Write a short summary in " + ("French" if fr else "English") + ": the topic, the key points, decisions, and anything the owner promised or must do, with names and numbers. "
              "At most 6 short lines, plain text, no markdown. Never invent anything that is not in the transcript.\n\nTRANSCRIPT:\n" + text[:12000])
    try:
        out = brain.ask(prompt, "You write faithful, concise call notes.", timeout=60, max_tokens=500)
        out = re.sub(r"(?s)<think>.*?</think>", "", out).strip()
        return out or _fallback(text, fr)
    except Exception:
        return _fallback(text, fr)


def save(text, fr, started=None):
    text = re.sub(r"\s+", " ", (text or "")).strip()[:MAX_TEXT]
    if len(text.split()) < 4:
        return None
    ts = time.time()
    summ = summarize(text, fr)
    with _lock:
        calls = _load()
        calls.append({"ts": ts, "started": started or ts, "summary": summ, "transcript": text})
        _save(calls)
    memory.remember("call", ("Call notes " if not fr else "Notes d'appel ") + memory.when(ts) + ": " + summ)
    return {"summary": summ, "ts": ts}


CALL_Q = re.compile(r"(what did (we|i|they|he|she) (discuss|decide|say|agree|talk)|what (was|were) (the|that) .*(call|meeting)|(last|previous|that|the|my) (phone )?call|call notes|notes (from|of) (the|my|that|our)|what happened (on|in|during) (the|that|my) call"
                    r"|de quoi (a-t-on|avait-on|a[- ]t[- ]on) parl|qu'?est[- ]ce (qu'on|que (nous|j'ai|il|elle)) (a |avons |avait )?(d[ée]cid|dit|convenu|parl)|dernier appel|mon appel|notes? de l'?appel|r[ée]sum[ée] de l'?appel|cet appel|(call|appel) (avec|with))", re.I)


def question(text, fr):
    """Answers a question about the notes he kept. None if it is not about them or there are none."""
    if not CALL_Q.search(text):
        return None
    calls = _load()
    if not calls:
        return None
    words = {w for w in re.findall(r"[\w'-]+", text.lower()) if len(w) > 3}
    scored = []
    for i, c in enumerate(calls):
        low = (c["summary"] + " " + c["transcript"]).lower()
        scored.append((sum(w in low for w in words), i, c))
    scored.sort(key=lambda x: (-x[0], -x[1]))
    pick = [c for s, _, c in scored[:3] if s > 0] or [calls[-1]]
    pick = sorted(pick, key=lambda c: c["ts"])
    if not _llm():
        c = pick[-1]
        return (memory.when(c["ts"]) + " : " if fr else memory.when(c["ts"]) + ": ") + c["summary"]
    ctx = "\n\n".join("CALL " + memory.when(c["ts"]) + "\nSUMMARY: " + c["summary"] + "\nTRANSCRIPT: " + c["transcript"][:6000] for c in pick)
    prompt = ("Answer the owner's question using only these call notes (speech-recognition transcripts of the owner's side, so details may be missing). "
              "If the notes do not say, say so. Reply in " + ("French" if fr else "English") + ", in two or three short spoken sentences, no markdown.\n\nNOTES:\n" + ctx + "\n\nQUESTION: " + text)
    try:
        out = re.sub(r"(?s)<think>.*?</think>", "", brain.ask(prompt, "You answer from call notes only.", timeout=60, max_tokens=400)).strip()
        return out or pick[-1]["summary"]
    except Exception:
        return pick[-1]["summary"]
