"""One check of everything Archie needs. Each line: (name, ok, detail). Nothing is sent, nobody is called."""
import os
import time

import requests


def _try(fn):
    try:
        r = fn()
        return (True, r if isinstance(r, str) else "")
    except BaseException as e:
        return (False, (str(e) or type(e).__name__)[:120])


def run(lang="fr"):
    from . import i18n

    return [(i18n.selftest(n, lang), ok, i18n.selftest(d, lang)) for n, ok, d in _run()]


def _run():
    from . import brain, icloud, knowledge, mailbox, notify, pcaccess, phone, server

    out = []

    def add(name, fn):
        ok, d = _try(fn)
        out.append((name, ok, d))

    def ai():
        t = brain.ask("Answer with the single word OK.", max_tokens=10, timeout=30)
        if not t:
            raise RuntimeError("no answer")
        return "répond"
    add("Intelligence (Claude)", ai)

    def mail():
        from . import msgraph

        if not msgraph.enabled():
            mailbox.settings()
        return ("Outlook" if msgraph.enabled() else "connecté") if mailbox.latest(1, 3) is not None else ""
    add("Courriel", mail)

    def cal():
        from datetime import datetime, timedelta
        now = datetime.now(icloud.TZ)
        icloud.events(now, now + timedelta(days=1))
        return f"journée {icloud.WORK_START} h à {icloud.WORK_END} h"
    add("Agenda iCloud", cal)

    def tw():
        from . import tier

        if not tier.phone_ok():
            return "version Base : pas d'appels ni de textos"
        if not notify.configured():
            raise RuntimeError("non configuré (ouvrez les réglages ⚙)")
        c = phone.cfg(need_url=False)
        r = requests.get(f"https://api.twilio.com/2010-04-01/Accounts/{c['TWILIO_ACCOUNT_SID']}.json",
                         auth=(c["TWILIO_ACCOUNT_SID"], c["TWILIO_AUTH_TOKEN"]), timeout=15)
        if r.status_code >= 300:
            raise RuntimeError(f"Twilio refuse le compte ({r.status_code})")
        if r.json().get("type") == "Trial":
            return "compte d'ESSAI : les appels ne disent que le message de Twilio"
        return "compte complet"
    add("Téléphone et textos", tw)

    def voice():
        f = server.speech_file("Test.", "fr")
        if not f or not os.path.exists(f):
            raise RuntimeError("pas de voix")
        return "voix prête"
    add("Voix d'Archie", voice)

    def stock():
        r = requests.get("https://query1.finance.yahoo.com/v8/finance/chart/NVDA", params={"range": "5d", "interval": "1d"},
                         headers={"User-Agent": "Mozilla/5.0"}, timeout=15)
        r.raise_for_status()
        return "cours disponibles"
    add("Cours de la bourse", stock)

    def web():
        r = requests.get("https://en.wikipedia.org/api/rest_v1/page/summary/Earth", headers={"User-Agent": "Archie"}, timeout=15)
        r.raise_for_status()
        return "internet et photos"
    add("Photos et internet", web)

    add("Accès au PC", lambda: ", ".join(r.name for r in pcaccess.ROOTS) or (_ for _ in ()).throw(RuntimeError("aucun dossier trouvé")))
    add("Mémoire des documents", lambda: f"{knowledge.count()} documents" if knowledge.enabled() else (_ for _ in ()).throw(RuntimeError("éteinte (dites « indexe tous mes documents »)")))
    from . import clients, tier
    if tier.phone_ok():
      add("Clients prioritaires (appels)", lambda: f"{len(clients.load())} client(s)" if clients.load() else (_ for _ in ()).throw(RuntimeError("aucun : Archie ne téléphonera jamais")))
    return out


def text(lang="fr"):
    rows = run(lang)
    lines = [f"{'OK ' if ok else 'XX '} {n}: {d}" for n, ok, d in rows]
    lines.append("")
    bad = sum(1 for _, ok, _ in rows if not ok)
    lines.append(("All good." if not bad else f"{bad} thing(s) to fix.") if lang == "en" else ("Tout est bon." if not bad else f"{bad} point(s) à régler."))
    return "\n".join(lines)
