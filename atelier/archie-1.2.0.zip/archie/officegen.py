"""Word, Excel and PowerPoint files written by Archie himself: no Office, no extra package. Plain standard library (zipfile + XML)."""
import re
import zipfile
from pathlib import Path
from xml.sax.saxutils import escape

CT = "application/vnd.openxmlformats-officedocument."
XML = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'


def _x(t):
    return escape(re.sub(r"[\x00-\x08\x0b\x0c\x0e-\x1f]", "", str(t)))


def _unique(path):
    p = Path(path)
    n = 2
    while p.exists():
        p = p.with_name(f"{Path(path).stem} ({n}){Path(path).suffix}")
        n += 1
    return p


def _zip(path, files):
    path = _unique(path)
    with zipfile.ZipFile(path, "w", zipfile.ZIP_DEFLATED) as z:
        for name, data in files:
            z.writestr(name, data)
    return path


def _rels(items):
    return XML + '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">' + "".join(
        f'<Relationship Id="{i}" Type="{t}" Target="{g}"/>' for i, t, g in items) + "</Relationships>"


R = "http://schemas.openxmlformats.org/officeDocument/2006/relationships/"


# ---------------------------------------------------------------- Word
def make_docx(path, title, blocks):
    """blocks: {"h":"Heading"} {"h2":"Sub"} {"p":"text"} {"li":["a","b"]} {"table":[["h1","h2"],["a","b"]]}"""
    body = []

    def para(text, style=None, bold=False, ind=None, spacing=None):
        ppr = ""
        if style or ind or spacing:
            ppr = "<w:pPr>" + (f'<w:pStyle w:val="{style}"/>' if style else "") + (f'<w:ind w:left="{ind}" w:hanging="260"/>' if ind else "") + (spacing or "") + "</w:pPr>"
        rpr = "<w:rPr><w:b/></w:rPr>" if bold else ""
        return f'<w:p>{ppr}<w:r>{rpr}<w:t xml:space="preserve">{_x(text)}</w:t></w:r></w:p>'

    if title:
        body.append(para(title, "Title"))
    for b in blocks:
        if "h" in b:
            body.append(para(b["h"], "Heading1"))
        elif "h2" in b:
            body.append(para(b["h2"], "Heading2"))
        elif "li" in b:
            for it in b["li"]:
                body.append(para("•  " + str(it), ind=500))
        elif "table" in b and b["table"]:
            rows = []
            ncol = max(len(r) for r in b["table"])
            cw = 9360 // ncol
            for ri, row in enumerate(b["table"]):
                row = list(row) + [""] * (ncol - len(row))
                cells = "".join(
                    f'<w:tc><w:tcPr><w:tcW w:w="{cw}" w:type="dxa"/>' + ('<w:shd w:val="clear" w:color="auto" w:fill="DCE6F2"/>' if ri == 0 else "") +
                    f'</w:tcPr>{para(c, bold=(ri == 0))}</w:tc>' for c in row)
                rows.append(f"<w:tr>{cells}</w:tr>")
            border = "".join(f'<w:{s} w:val="single" w:sz="4" w:space="0" w:color="999999"/>' for s in ("top", "left", "bottom", "right", "insideH", "insideV"))
            body.append(f'<w:tbl><w:tblPr><w:tblW w:w="9360" w:type="dxa"/><w:tblBorders>{border}</w:tblBorders><w:tblLayout w:type="fixed"/></w:tblPr><w:tblGrid>{"".join(f'<w:gridCol w:w="{cw}"/>' for _ in range(ncol))}</w:tblGrid>{"".join(rows)}</w:tbl>' + para(""))
        elif "p" in b:
            body.append(para(b["p"], spacing='<w:spacing w:after="140"/>'))
    doc = (XML + '<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>' + "".join(body) +
           '<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="708" w:footer="708" w:gutter="0"/></w:sectPr></w:body></w:document>')
    styles = (XML + '<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">'
              '<w:docDefaults><w:rPrDefault><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri" w:cs="Calibri"/><w:sz w:val="22"/></w:rPr></w:rPrDefault>'
              '<w:pPrDefault><w:pPr><w:spacing w:after="120" w:line="264" w:lineRule="auto"/></w:pPr></w:pPrDefault></w:docDefaults>'
              '<w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/></w:style>'
              '<w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:color w:val="1F3864"/><w:sz w:val="48"/></w:rPr></w:style>'
              '<w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="320" w:after="100"/><w:outlineLvl w:val="0"/></w:pPr><w:rPr><w:b/><w:color w:val="1F3864"/><w:sz w:val="32"/></w:rPr></w:style>'
              '<w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:next w:val="Normal"/><w:pPr><w:keepNext/><w:spacing w:before="220" w:after="80"/><w:outlineLvl w:val="1"/></w:pPr><w:rPr><w:b/><w:color w:val="2F5496"/><w:sz w:val="26"/></w:rPr></w:style>'
              '</w:styles>')
    return _zip(path, [
        ("[Content_Types].xml", XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
         f'<Override PartName="/word/document.xml" ContentType="{CT}wordprocessingml.document.main+xml"/><Override PartName="/word/styles.xml" ContentType="{CT}wordprocessingml.styles+xml"/></Types>'),
        ("_rels/.rels", _rels([("rId1", R + "officeDocument", "word/document.xml")])),
        ("word/document.xml", doc),
        ("word/styles.xml", styles),
        ("word/_rels/document.xml.rels", _rels([("rId1", R + "styles", "styles.xml")])),
    ])


# ---------------------------------------------------------------- Excel
def _col(n):
    s = ""
    n += 1
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def make_xlsx(path, sheets):
    """sheets: [{"name":"Budget","rows":[["Item","Cost"],["Rent",1200],["Total","=SUM(B2:B2)"]]}] - first row is the header."""
    sheets = sheets or [{"name": "Sheet1", "rows": [[""]]}]
    files, ov, wbs, wbr = [], [], [], []
    for si, sh in enumerate(sheets[:10], 1):
        rows = sh.get("rows") or [[""]]
        width = {}
        out = []
        for ri, row in enumerate(rows, 1):
            cells = []
            for ci, v in enumerate(row):
                ref = f"{_col(ci)}{ri}"
                st = ' s="1"' if ri == 1 else ""
                if isinstance(v, bool):
                    v = str(v)
                if isinstance(v, (int, float)):
                    cells.append(f'<c r="{ref}"{st}><v>{v}</v></c>')
                elif isinstance(v, str) and v.startswith("="):
                    cells.append(f'<c r="{ref}"{st}><f>{_x(v[1:])}</f></c>')
                elif isinstance(v, str) and re.fullmatch(r"-?\d+(\.\d+)?", v.strip()):
                    cells.append(f'<c r="{ref}"{st}><v>{v.strip()}</v></c>')
                else:
                    cells.append(f'<c r="{ref}"{st} t="inlineStr"><is><t xml:space="preserve">{_x(v)}</t></is></c>')
                width[ci] = max(width.get(ci, 8), min(60, len(str(v)) + 3))
            out.append(f'<row r="{ri}">{"".join(cells)}</row>')
        cols = "<cols>" + "".join(f'<col min="{c + 1}" max="{c + 1}" width="{w}" customWidth="1"/>' for c, w in sorted(width.items())) + "</cols>"
        pane = '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>' if len(rows) > 1 else ""
        files.append((f"xl/worksheets/sheet{si}.xml", XML + '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">' + pane + cols + "<sheetData>" + "".join(out) + "</sheetData></worksheet>"))
        ov.append(f'<Override PartName="/xl/worksheets/sheet{si}.xml" ContentType="{CT}spreadsheetml.worksheet+xml"/>')
        name = re.sub(r"[\\/*?:\[\]]", "", str(sh.get("name") or f"Sheet{si}"))[:31] or f"Sheet{si}"
        wbs.append(f'<sheet name="{_x(name)}" sheetId="{si}" r:id="rId{si}"/>')
        wbr.append((f"rId{si}", R + "worksheet", f"worksheets/sheet{si}.xml"))
    n = len(wbr)
    wbr.append((f"rId{n + 1}", R + "styles", "styles.xml"))
    styles = (XML + '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
              '<fonts count="2"><font><sz val="11"/><name val="Calibri"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Calibri"/></font></fonts>'
              '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF1F3864"/><bgColor indexed="64"/></patternFill></fill></fills>'
              '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
              '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
              '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFont="1" applyFill="1"/></cellXfs>'
              '<cellStyles count="1"><cellStyle name="Normal" xfId="0" builtinId="0"/></cellStyles></styleSheet>')
    return _zip(path, [
        ("[Content_Types].xml", XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
         f'<Override PartName="/xl/workbook.xml" ContentType="{CT}spreadsheetml.sheet.main+xml"/><Override PartName="/xl/styles.xml" ContentType="{CT}spreadsheetml.styles+xml"/>' + "".join(ov) + "</Types>"),
        ("_rels/.rels", _rels([("rId1", R + "officeDocument", "xl/workbook.xml")])),
        ("xl/workbook.xml", XML + '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>' + "".join(wbs) + "</sheets></workbook>"),
        ("xl/_rels/workbook.xml.rels", _rels(wbr)),
        ("xl/styles.xml", styles),
    ] + files)


# ---------------------------------------------------------------- PowerPoint
NS = 'xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main"'
W, H = 12192000, 6858000


def _tb(i, name, x, y, w, h, paras, anchor="t"):
    return (f'<p:sp><p:nvSpPr><p:cNvPr id="{i}" name="{name}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="{x}" y="{y}"/><a:ext cx="{w}" cy="{h}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/></p:spPr>'
            f'<p:txBody><a:bodyPr wrap="square" lIns="0" rIns="0" anchor="{anchor}"><a:normAutofit/></a:bodyPr><a:lstStyle/>{paras}</p:txBody></p:sp>')


def _para(text, sz, color="FFFFFF", bold=False, bullet=False, after=900):
    ppr = f'<a:pPr marL="342900" indent="-342900"><a:spcAft><a:spcPts val="{after}"/></a:spcAft><a:buClr><a:srgbClr val="5BC0EB"/></a:buClr><a:buFont typeface="Arial"/><a:buChar char="&#8226;"/></a:pPr>' if bullet else f'<a:pPr><a:spcAft><a:spcPts val="{after}"/></a:spcAft></a:pPr>'
    return f'<a:p>{ppr}<a:r><a:rPr lang="en-US" sz="{sz}" b="{1 if bold else 0}"><a:solidFill><a:srgbClr val="{color}"/></a:solidFill><a:latin typeface="Calibri"/></a:rPr><a:t>{_x(text)}</a:t></a:r></a:p>'


def make_pptx(path, title, slides, subtitle=""):
    """slides: [{"title":"...","bullets":["...","..."],"notes":"..."}]"""
    allsl = []
    allsl.append(f'<p:sp><p:nvSpPr><p:cNvPr id="9" name="Bar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="914400" y="3020000"/><a:ext cx="1600000" cy="54000"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="5BC0EB"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>'
                 + _tb(2, "Title", 914400, 1300000, 10300000, 1600000, _para(title, 4800, bold=True), "b")
                 + _tb(3, "Subtitle", 914400, 3250000, 10300000, 1200000, _para(subtitle, 2200, "BFD7EA") if subtitle else ""))
    for s in slides[:25]:
        bl = [str(b) for b in (s.get("bullets") or [])][:7]
        sz = 2600 if len(bl) <= 4 else 2200
        allsl.append(f'<p:sp><p:nvSpPr><p:cNvPr id="9" name="Bar"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="685800" y="1350000"/><a:ext cx="900000" cy="45720"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:solidFill><a:srgbClr val="5BC0EB"/></a:solidFill><a:ln><a:noFill/></a:ln></p:spPr></p:sp>'
                     + _tb(2, "Title", 685800, 420000, 10800000, 850000, _para(str(s.get("title", "")), 3400, bold=True), "b")
                     + _tb(3, "Body", 685800, 1650000, 10800000, 4600000, "".join(_para(b, sz, "EAF4FB", bullet=True) for b in bl) or _para("", sz)))
    files, ov, sldids, prels = [], [], [], []
    for i, shapes in enumerate(allsl, 1):
        files.append((f"ppt/slides/slide{i}.xml", XML + f'<p:sld {NS}><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="0B1F3A"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/>{shapes}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>'))
        files.append((f"ppt/slides/_rels/slide{i}.xml.rels", _rels([("rId1", R + "slideLayout", "../slideLayouts/slideLayout1.xml")])))
        ov.append(f'<Override PartName="/ppt/slides/slide{i}.xml" ContentType="{CT}presentationml.slide+xml"/>')
        sldids.append(f'<p:sldId id="{255 + i}" r:id="rId{i + 1}"/>')
        prels.append((f"rId{i + 1}", R + "slide", f"slides/slide{i}.xml"))
    n = len(allsl)
    prels = [("rId1", R + "slideMaster", "slideMasters/slideMaster1.xml")] + prels + [(f"rId{n + 2}", R + "theme", "theme/theme1.xml")]
    pres = XML + f'<p:presentation {NS}><p:sldMasterIdLst><p:sldMasterId id="2147483648" r:id="rId1"/></p:sldMasterIdLst><p:sldIdLst>{"".join(sldids)}</p:sldIdLst><p:sldSz cx="{W}" cy="{H}"/><p:notesSz cx="6858000" cy="9144000"/></p:presentation>'
    empty_tree = '<p:cSld><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr/></p:spTree></p:cSld>'
    master = (XML + f'<p:sldMaster {NS}>{empty_tree}<p:clrMap bg1="lt1" tx1="dk1" bg2="lt2" tx2="dk2" accent1="accent1" accent2="accent2" accent3="accent3" accent4="accent4" accent5="accent5" accent6="accent6" hlink="hlink" folHlink="folHlink"/>'
              '<p:sldLayoutIdLst><p:sldLayoutId id="2147483649" r:id="rId1"/></p:sldLayoutIdLst></p:sldMaster>')
    layout = XML + f'<p:sldLayout {NS} type="blank" preserve="1">{empty_tree}<p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sldLayout>'
    fill3 = "".join('<a:solidFill><a:schemeClr val="phClr"/></a:solidFill>' for _ in range(3))
    theme = (XML + '<a:theme xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" name="Archie"><a:themeElements><a:clrScheme name="Archie">'
             '<a:dk1><a:srgbClr val="000000"/></a:dk1><a:lt1><a:srgbClr val="FFFFFF"/></a:lt1><a:dk2><a:srgbClr val="0B1F3A"/></a:dk2><a:lt2><a:srgbClr val="EAF4FB"/></a:lt2>'
             '<a:accent1><a:srgbClr val="5BC0EB"/></a:accent1><a:accent2><a:srgbClr val="1F3864"/></a:accent2><a:accent3><a:srgbClr val="2F5496"/></a:accent3><a:accent4><a:srgbClr val="9BC53D"/></a:accent4><a:accent5><a:srgbClr val="FDE74C"/></a:accent5><a:accent6><a:srgbClr val="E55934"/></a:accent6>'
             '<a:hlink><a:srgbClr val="5BC0EB"/></a:hlink><a:folHlink><a:srgbClr val="9BC53D"/></a:folHlink></a:clrScheme>'
             '<a:fontScheme name="Archie"><a:majorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:majorFont><a:minorFont><a:latin typeface="Calibri"/><a:ea typeface=""/><a:cs typeface=""/></a:minorFont></a:fontScheme>'
             f'<a:fmtScheme name="Archie"><a:fillStyleLst>{fill3}</a:fillStyleLst><a:lnStyleLst>' + "".join('<a:ln w="9525"><a:solidFill><a:schemeClr val="phClr"/></a:solidFill></a:ln>' for _ in range(3)) +
             '</a:lnStyleLst><a:effectStyleLst>' + "".join("<a:effectStyle><a:effectLst/></a:effectStyle>" for _ in range(3)) + f'</a:effectStyleLst><a:bgFillStyleLst>{fill3}</a:bgFillStyleLst></a:fmtScheme></a:themeElements></a:theme>')
    return _zip(path, [
        ("[Content_Types].xml", XML + '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>'
         f'<Override PartName="/ppt/presentation.xml" ContentType="{CT}presentationml.presentation.main+xml"/><Override PartName="/ppt/slideMasters/slideMaster1.xml" ContentType="{CT}presentationml.slideMaster+xml"/>'
         f'<Override PartName="/ppt/slideLayouts/slideLayout1.xml" ContentType="{CT}presentationml.slideLayout+xml"/><Override PartName="/ppt/theme/theme1.xml" ContentType="{CT}theme+xml"/>' + "".join(ov) + "</Types>"),
        ("_rels/.rels", _rels([("rId1", R + "officeDocument", "ppt/presentation.xml")])),
        ("ppt/presentation.xml", pres),
        ("ppt/_rels/presentation.xml.rels", _rels(prels)),
        ("ppt/slideMasters/slideMaster1.xml", master),
        ("ppt/slideMasters/_rels/slideMaster1.xml.rels", _rels([("rId1", R + "slideLayout", "../slideLayouts/slideLayout1.xml"), ("rId2", R + "theme", "../theme/theme1.xml")])),
        ("ppt/slideLayouts/slideLayout1.xml", layout),
        ("ppt/slideLayouts/_rels/slideLayout1.xml.rels", _rels([("rId1", R + "slideMaster", "../slideMasters/slideMaster1.xml")])),
        ("ppt/theme/theme1.xml", theme),
    ] + files)
