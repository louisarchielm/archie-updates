"""Archie's voice: British English (Ryan) and Quebec French (Antoine), picked by the language of the text."""
import asyncio
import re
import tempfile
from pathlib import Path

VOICES = {"en": "en-GB-RyanNeural", "fr": "fr-CA-AntoineNeural"}
_FR_WORDS = {"le", "la", "les", "des", "un", "une", "et", "est", "vous", "je", "bonjour", "rendez-vous",
             "courriel", "pour", "avec", "que", "pas", "dans", "mon", "ma", "nous", "merci", "aujourd'hui"}


def language(text, default="en"):
    """Very small language check: French if it has accents or several common French words."""
    words = re.findall(r"[a-zà-ÿ'’-]+", text.lower())
    hits = sum(w in _FR_WORDS for w in words)
    if re.search(r"[àâçéèêëîïôûùüÿœ]", text.lower()) or hits >= 2:
        return "fr"
    return default if words else default


def provider():
    """The paid voice when a key is saved in the settings (licensed for commercial use); otherwise the free one."""
    import os
    if os.environ.get("AZURE_SPEECH_KEY") and os.environ.get("AZURE_SPEECH_REGION"):
        return "azure"
    if os.environ.get("ELEVENLABS_KEY") and os.environ.get("ELEVENLABS_VOICE_ID"):
        return "elevenlabs"
    return "free"


def _azure(text, lang, out):
    import os
    import requests
    from xml.sax.saxutils import escape

    name = VOICES[lang]
    ssml = f"<speak version='1.0' xml:lang='{name[:5]}' xmlns='http://www.w3.org/2001/10/synthesis'><voice name='{name}'>{escape(text)}</voice></speak>"
    r = requests.post(f"https://{os.environ['AZURE_SPEECH_REGION'].strip()}.tts.speech.microsoft.com/cognitiveservices/v1", data=ssml.encode("utf-8"), timeout=30,
                      headers={"Ocp-Apim-Subscription-Key": os.environ["AZURE_SPEECH_KEY"].strip(), "Content-Type": "application/ssml+xml",
                               "X-Microsoft-OutputFormat": "audio-24khz-96kbitrate-mono-mp3", "User-Agent": "Archie"})
    if r.status_code != 200:
        raise RuntimeError(f"Azure voice answered {r.status_code}")
    Path(out).write_bytes(r.content)


def _eleven(text, lang, out):
    import os
    import requests

    r = requests.post(f"https://api.elevenlabs.io/v1/text-to-speech/{os.environ['ELEVENLABS_VOICE_ID'].strip()}?output_format=mp3_44100_96", timeout=40,
                      headers={"xi-api-key": os.environ["ELEVENLABS_KEY"].strip(), "Content-Type": "application/json"},
                      json={"text": text, "model_id": "eleven_multilingual_v2"})
    if r.status_code != 200:
        raise RuntimeError(f"ElevenLabs answered {r.status_code}")
    Path(out).write_bytes(r.content)


def speak_to_file(text, lang=None, out=None):
    """Writes an mp3 of Archie saying the text. Needs internet and `pip install edge-tts`."""
    lang = lang or language(text)
    out = Path(out) if out else Path(tempfile.gettempdir()) / f"archie-{lang}.mp3"
    pv = provider()
    if pv != "free":
        try:
            (_azure if pv == "azure" else _eleven)(text, lang, out)
            return out
        except Exception as e:  # the paid voice is down or the key is wrong: the free voice keeps him talking
            print(f"[voice] {pv} failed, using the free voice: {str(e)[:100]}", flush=True)
    import edge_tts

    asyncio.run(edge_tts.Communicate(text, VOICES[lang]).save(str(out)))
    return out
