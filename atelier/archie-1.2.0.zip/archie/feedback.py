"""Anonymous reports of Archie's generic mistakes, so the owner can fix them for everybody in a signed update.
Strict rules: nothing leaves without (1) the client's consent given at first launch (changeable in the settings) and (2) his yes on the exact text of each report.
Personal preferences (tone, length, names, how he signs) never leave: they are sorted out first. Anything that still looks like a name, address, number or
amount is refused rather than cleaned. A report is one short description of a kind of mistake plus a random install code (to count clients, not to know who)."""
import json
import os
import re
import threading
import time
import uuid
from pathlib import Path

import requests

OUTBOX = Path("archie-outbox.json")
INSTALL = Path("archie-install-id.txt")
LOCK = threading.Lock()
SORT = """An AI assistant (Archie) learned this rule from its owner's correction or from a failure:
"{rule}"
Decide:
- "personal": a preference of this one person (tone, length, language, names, how to sign, what to call him, his habits, his contacts, his clients, his work details).
- "generic": a mistake in how ANY assistant like this should understand or do things (misread a request, wrong action chosen, a feature that fails, a bug).
For "generic", also write ONE short description of the kind of mistake (max 25 words, English) that contains NO names, no email addresses, no phone numbers, no amounts, no dates, no company or product names and nothing about his work.
When unsure, say "personal".
JSON only: {{"kind": "personal" or "generic", "report": "..."}}"""
_PII = [re.compile(p, re.I) for p in (r"[\w.+-]+@[\w-]+\.[\w.]+", r"https?://|www\.", r"\+?\d[\d\s().-]{6,}\d", r"\d{4,}", r"[$€£]\s?\d|\d\s?(\$|€|£|dollars?|euros?)",
                                      r"\b(mr|mrs|ms|mme|m\.|monsieur|madame|dr)\b\.?\s+[A-Z]")]
_OK_CAPS = {"archie", "claude", "i", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday", "sunday", "english", "french", "icloud", "outlook", "gmail", "windows", "pc", "ai", "sms", "html"}


def consent():
    """True, False, or None when he has not been asked yet."""
    v = os.environ.get("ARCHIE_SHARE_FEEDBACK", "").strip().lower()
    return True if v in ("oui", "yes", "1", "true") else False if v in ("non", "no", "0", "false") else None


def install_id():
    try:
        return INSTALL.read_text().strip()
    except OSError:
        v = uuid.uuid4().hex[:16]
        INSTALL.write_text(v)
        return v


def looks_personal(text):
    """True when the text still carries something that could identify a person or his work: refused, never 'cleaned'."""
    if any(p.search(text) for p in _PII) or '"' in text or "“" in text or "«" in text:
        return True
    words = re.findall(r"[A-Za-zÀ-ÿ'’-]+", text)
    for i, w in enumerate(words):
        if i > 0 and w[:1].isupper() and w.lower() not in _OK_CAPS and not w.isupper():
            return True  # a capital letter in mid-sentence: probably a name
    return False


def _load():
    try:
        return json.loads(OUTBOX.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(v):
    OUTBOX.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding="utf-8")


def consider(rule_text):
    """A lesson was learned. If sharing is allowed and it is a generic mistake, queue an anonymous report for his approval. Returns the report or None."""
    if consent() is not True:
        return None
    from . import brain

    try:
        d = brain.ask_json(SORT.format(rule=rule_text[:300]), "You sort lessons. JSON only.", max_tokens=160)
    except BaseException:
        return None
    if not d or d.get("kind") != "generic":
        return None
    rep = re.sub(r"\s+", " ", str(d.get("report") or "")).strip()[:200]
    if len(rep) < 12 or looks_personal(rep):
        return None
    with LOCK:
        v = _load()
        if any(r["text"].lower() == rep.lower() for r in v):
            return None
        r = {"id": uuid.uuid4().hex[:8], "text": rep, "status": "pending", "ts": time.time()}
        v.append(r)
        _save(v[-60:])
    try:
        from . import autopilot

        autopilot.push("J'ai un signalement anonyme d'une erreur générale à vous montrer avant tout envoi. Dites « montre le signalement ».")
    except BaseException:
        pass
    return r


def consider_async(rule_text):
    threading.Thread(target=lambda: consider(rule_text), daemon=True).start() if not os.environ.get("ARCHIE_SYNC_FEEDBACK") else consider(rule_text)


def pending():
    return [r for r in _load() if r["status"] == "pending"]


def set_text(rid, text):
    text = re.sub(r"\s+", " ", text).strip()[:200]
    if looks_personal(text):
        raise ValueError("personal")
    with LOCK:
        v = _load()
        for r in v:
            if r["id"] == rid:
                r["text"] = text
        _save(v)


def mark(rid, status):
    with LOCK:
        v = _load()
        for r in v:
            if r["id"] == rid:
                r["status"] = status
        _save(v)


def send(rid):
    """After his yes. Sends exactly the approved text. Without an address it stays approved, waiting."""
    with LOCK:
        r = next((x for x in _load() if x["id"] == rid and x["status"] in ("pending", "approved")), None)
    if not r:
        raise RuntimeError("Signalement introuvable.")
    if consent() is not True:
        raise RuntimeError("Le partage est désactivé dans les réglages.")
    url = os.environ.get("ARCHIE_FEEDBACK_URL", "").strip()
    if not url.startswith("https://"):
        mark(rid, "approved")  # approved, kept until an address is set
        return "approved"
    from . import updater

    res = requests.post(url, json={"id": install_id(), "text": r["text"], "version": updater.version(), "ts": int(time.time())}, timeout=20)
    if not res.ok:
        mark(rid, "approved")
        raise RuntimeError(f"Le serveur a répondu {res.status_code}")
    mark(rid, "sent")
    return "sent"


def flush():
    """Sends the reports he already approved when the address was not set (called now and then)."""
    n = 0
    for r in [x for x in _load() if x["status"] == "approved"]:
        try:
            if send(r["id"]) == "sent":
                n += 1
        except BaseException:
            break
    return n
