"""Twilio voice: call you with an update, and the "client is on the other line" transfer.

Transfer flow:
  1. `connect "Jane Doe"` dials the client (who must be in contacts.json).
  2. When the client answers, the assistant introduces itself as an AI, and puts them on hold
     in a conference room.
  3. Only then does it ring YOU: "Jane Doe is on the other line. Press 1 to take the call,
     or 2 to send them to voicemail."
  4. Press 1 and you are joined into the same room. Press 2 (or don't answer) and the client is
     told you will get back to them.

The webhook server only accepts requests signed by Twilio.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlencode
from xml.sax.saxutils import escape

import requests

API = "https://api.twilio.com/2010-04-01/Accounts/{sid}/Calls"
LOCK = threading.Lock()
ROOMS = {}
ROOM_RE = re.compile(r"[0-9a-f]{12}")
CONF = (
    '<Dial><Conference beep="false" startConferenceOnEnter="{start}" '
    'endConferenceOnExit="true">{room}</Conference></Dial>'
)


def cfg(need_url=True):
    keys = ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM", "MY_PHONE"]
    if need_url:
        keys.append("PUBLIC_URL")
    c = {k: os.environ.get(k, "") for k in keys}
    missing = [k for k, v in c.items() if not v]
    if missing:
        raise SystemExit("Set these environment variables first: " + ", ".join(missing))
    c["PUBLIC_URL"] = c.get("PUBLIC_URL", "").rstrip("/")
    c["OWNER"] = os.environ.get("OWNER_NAME", "the owner")
    return c


def _post(c, path, data):
    sid = c["TWILIO_ACCOUNT_SID"]
    r = requests.post(
        API.format(sid=sid) + path, auth=(sid, c["TWILIO_AUTH_TOKEN"]), data=data, timeout=30
    )
    if r.status_code >= 300:
        raise RuntimeError(f"Twilio error {r.status_code}: {r.text[:200]}")
    return r.json()


def _url(c, path, **q):
    return c["PUBLIC_URL"] + path + ("?" + urlencode(q) if q else "")


def twiml(body):
    return f'<?xml version="1.0" encoding="UTF-8"?><Response>{body}</Response>'


# ---- commands used from the CLI -------------------------------------------------------

def callme(text):
    """Phone YOU and read a message aloud (meeting reminders, schedule changes)."""
    c = cfg(need_url=False)
    try:
        _post(c, ".json", {
            "To": c["MY_PHONE"], "From": c["TWILIO_FROM"],
            "Twiml": f"<Response><Say>{escape(text)}</Say></Response>",
        })
    except RuntimeError as e:
        if "trial" not in str(e).lower():
            raise
        # Twilio trial accounts may not send their own text. Ring with Twilio's sample message
        # instead, which still proves the phone line works.
        _post(c, ".json", {
            "To": c["MY_PHONE"], "From": c["TWILIO_FROM"],
            "Url": "http://demo.twilio.com/docs/voice.xml",
        })
        print("NOTE: this is a Twilio TRIAL account, so it can only play Twilio's sample message, "
              "not your own text. Upgrade the account to unlock custom messages and transfers.")


def load_contacts():
    path = os.environ.get("CONTACTS_FILE", "contacts.json")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise SystemExit(
            f"No {path}. Copy contacts.example.json to contacts.json and add the clients "
            "you allow the assistant to call. Edit this file yourself."
        )


def connect(name):
    """Dial a contact from contacts.json; you get called once they pick up."""
    contacts = load_contacts()
    hits = {k: v for k, v in contacts.items() if k.lower() == name.lower()}
    if not hits:
        raise SystemExit(f"'{name}' is not in contacts.json, so I will not call them.")
    label, number = next(iter(hits.items()))
    if not re.fullmatch(r"\+\d{8,15}", number):
        raise SystemExit(f"Number for '{label}' must look like +15145551234.")
    c = cfg()
    _post(c, ".json", {
        "To": number, "From": c["TWILIO_FROM"], "Timeout": 25,
        "Url": _url(c, "/client", room=secrets.token_hex(6), name=label),
    })
    return label


# ---- webhook handlers -----------------------------------------------------------------

def _decline(c, room):
    with LOCK:
        st = ROOMS.get(room)
        if not st or st["state"] != "ringing":
            return
        st["state"] = "declined"
        sid = st["client_sid"]
    try:
        _post(c, f"/{sid}.json", {"Twiml": (
            "<Response><Say>Sorry, " + escape(c["OWNER"]) + " cannot take the call right now. "
            "They will get back to you shortly.</Say><Hangup/></Response>")})
    except Exception as e:
        print("could not release client:", e)
    with LOCK:
        ROOMS.pop(room, None)


def _ring_owner(c, room, name):
    try:
        _post(c, ".json", {
            "To": c["MY_PHONE"], "From": c["TWILIO_FROM"], "Timeout": 20,
            "Url": _url(c, "/me", room=room, name=name),
            "StatusCallback": _url(c, "/me/status", room=room),
            "StatusCallbackMethod": "POST",
        })
    except Exception as e:
        print("could not call you:", e)
        _decline(c, room)


def h_client(c, p, q):
    room, name = q["room"], q.get("name", "there")[:60]
    with LOCK:
        ROOMS[room] = {"client_sid": p.get("CallSid", ""), "state": "ringing"}
    threading.Thread(target=_ring_owner, args=(c, room, name), daemon=True).start()
    return twiml(
        f"<Say>Hello {escape(name)}. This is Archie, the AI assistant of {escape(c['OWNER'])}. "
        "Please hold for a moment while I connect you.</Say>"
        + CONF.format(start="false", room=room)
    )


def h_me(c, p, q):
    name = q.get("name", "a client")[:60]
    act = escape(_url(c, "/me/choice", room=q["room"]))
    return twiml(
        f'<Gather numDigits="1" timeout="8" method="POST" action="{act}">'
        f"<Say>{escape(name)} is on the other line. Press 1 to take the call, "
        "or 2 to send them to voicemail.</Say></Gather>"
        f'<Redirect method="POST">{act}</Redirect>'
    )


def h_choice(c, p, q):
    room = q["room"]
    if p.get("Digits") == "1":
        with LOCK:
            st = ROOMS.get(room)
            ok = bool(st) and st["state"] == "ringing"
            if ok:
                st["state"] = "connected"
        if ok:
            return twiml("<Say>Connecting you now.</Say>" + CONF.format(start="true", room=room))
        return twiml("<Say>Sorry, that caller is no longer on the line.</Say><Hangup/>")
    threading.Thread(target=_decline, args=(c, room), daemon=True).start()
    return twiml("<Say>Okay. I will let them know.</Say><Hangup/>")


def h_status(c, p, q):
    """Your call ended. If you never accepted, release the client."""
    room = q["room"]
    with LOCK:
        st = ROOMS.get(room)
        if st and st["state"] == "connected":
            ROOMS.pop(room, None)
            return "<Response/>"
    threading.Thread(target=_decline, args=(c, room), daemon=True).start()
    return "<Response/>"


ROUTES = {"/client": h_client, "/me": h_me, "/me/choice": h_choice, "/me/status": h_status}


def signature_ok(token, url, params, header):
    data = url + "".join(k + v for k in sorted(params) for v in sorted(params[k]))
    mac = hmac.new(token.encode(), data.encode(), hashlib.sha1).digest()
    return hmac.compare_digest(base64.b64encode(mac).decode(), header or "")


def make_server(c, port):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            self.send_error(404)

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            params = parse_qs(self.rfile.read(n).decode("utf-8"), keep_blank_values=True)
            if not signature_ok(c["TWILIO_AUTH_TOKEN"], c["PUBLIC_URL"] + self.path, params,
                                self.headers.get("X-Twilio-Signature")):
                return self.send_error(403)
            path, _, qs = self.path.partition("?")
            q = {k: v[0] for k, v in parse_qs(qs).items()}
            route = ROUTES.get(path)
            if not route or not ROOM_RE.fullmatch(q.get("room", "")):
                return self.send_error(404)
            body = route(c, {k: v[0] for k, v in params.items()}, q).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/xml")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def serve(port=8080):
    c = cfg()
    print(f"Listening on 127.0.0.1:{port}. Your tunnel must forward {c['PUBLIC_URL']} here.")
    make_server(c, port).serve_forever()
