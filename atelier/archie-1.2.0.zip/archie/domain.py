"""What Archie knows about the owner's profession and company: the field, the jargon, the facts he has been told.
Learned from conversation (and by studying a topic on request), kept locally, fed into every answer so he understands specialist talk."""
import json
import re
import threading
import time
from pathlib import Path

FILE = Path("archie-domain.json")
_L = threading.Lock()
_LAST = {"t": 0.0}
MAX_TERMS = 300


def _load():
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            d.setdefault("field", "")
            d.setdefault("terms", {})
            d.setdefault("facts", [])
            return d
    except Exception:
        pass
    return {"field": "", "terms": {}, "facts": []}


def _save(d):
    try:
        FILE.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass


def _words(s):
    return {w for w in re.findall(r"[\w'-]+", (s or "").lower()) if len(w) > 3}


def set_field(field):
    with _L:
        d = _load()
        d["field"] = str(field)[:120]
        _save(d)


def add(terms=None, facts=None, field=None):
    with _L:
        d = _load()
        if field and not d["field"]:
            d["field"] = str(field)[:120]
        for k, v in (terms or {}).items():
            k, v = str(k).strip()[:60], str(v).strip()[:300]
            if k and v and (k.lower() not in {x.lower() for x in d["terms"]} or True):
                d["terms"][k] = v
        for f in facts or []:
            f = str(f).strip()[:300]
            if f and f not in d["facts"]:
                d["facts"].append(f)
        while len(d["terms"]) > MAX_TERMS:
            d["terms"].pop(next(iter(d["terms"])))
        d["facts"] = d["facts"][-150:]
        _save(d)


def count():
    d = _load()
    return len(d["terms"]) + len(d["facts"])


def for_prompt(question, limit=1800):
    """A few lines for the system prompt: his field, and the terms and facts that matter for this question."""
    d = _load()
    if not (d["field"] or d["terms"] or d["facts"]):
        return ""
    qw = _words(question)
    scored = []
    for k, v in d["terms"].items():
        scored.append((len(qw & _words(k + " " + v)) * 2 + (3 if k.lower() in (question or "").lower() else 0), f"{k}: {v}"))
    for f in d["facts"]:
        scored.append((len(qw & _words(f)), f))
    scored.sort(key=lambda x: -x[0])
    out, n = [], 0
    for s, line in scored:
        if n > limit or (s == 0 and len(out) >= 6):
            break
        out.append(line)
        n += len(line)
    head = (f" His line of work: {d['field']}." if d["field"] else "")
    return ("\nWhat you have learned about his work." + head + " Use these words and facts naturally, and talk like someone in his profession:\n- " + "\n- ".join(out)) if out else (head and "\n" + head.strip())


EXTRACT = """You maintain a glossary about the owner's profession and company, learned from what he says.
He said: "{u}"
You answered: "{a}"
Already known: {known}
Return JSON only: {{"field": "his profession or industry if clearly stated or obvious, else empty",
"terms": {{"specialist word or phrase he used": "short plain meaning in his context"}},
"facts": ["lasting facts he stated about his company, clients, rules, products or way of working"]}}
Only specialist jargon, names of his products/processes/clients, and lasting facts. Never greetings, small talk, one-off requests, opinions or private data (passwords, card numbers, health). Nothing already known. Empty values if nothing qualifies."""


def learn_async(user_text, answer, brain, min_gap=45):
    """In the background, after the answer: pick up new jargon or lasting facts. Never slows the conversation."""
    u = (user_text or "").strip()
    if len(u.split()) < 7 or time.time() - _LAST["t"] < min_gap:
        return
    _LAST["t"] = time.time()

    def run():
        try:
            d = _load()
            known = ", ".join(list(d["terms"])[-40:]) or "nothing yet"
            j = brain.ask_json(EXTRACT.format(u=u[:500], a=(answer or "")[:300], known=known), "You extract a glossary. JSON only.", timeout=60, max_tokens=400) or {}
            t = j.get("terms") if isinstance(j.get("terms"), dict) else {}
            f = j.get("facts") if isinstance(j.get("facts"), list) else []
            if t or f or j.get("field"):
                add(t, f, j.get("field") or None)
        except BaseException:
            pass
    threading.Thread(target=run, daemon=True).start()


STUDY = """{owner} works as: {field}. He asked you to study: {topic}.
Search the internet for reliable, current sources, then return JSON only:
{{"terms": {{"key concept or term": "one-sentence plain explanation"}}, "facts": ["important rule, figure, recent change or study result, with its date or source"]}}
12 terms and 8 facts at most, accurate, nothing invented."""


def study(topic, owner, brain):
    """He asks Archie to learn a subject. Returns how many things were learned."""
    d = _load()
    j = brain.ask(STUDY.format(owner=owner, field=d["field"] or "unknown", topic=topic[:200]), "You research and return JSON only.", timeout=240, web=True, max_tokens=1800, effort="deep")
    m = re.search(r"\{.*\}", j or "", re.S)
    try:
        data = json.loads(m.group(0)) if m else {}
    except Exception:
        data = {}
    t = data.get("terms") if isinstance(data.get("terms"), dict) else {}
    f = data.get("facts") if isinstance(data.get("facts"), list) else []
    add(t, f)
    return len(t) + len(f)


def forget():
    try:
        FILE.unlink()
    except OSError:
        pass
