import os
import sys
from datetime import datetime, time, timedelta
from zoneinfo import ZoneInfo

TZ = ZoneInfo(os.environ.get("ARCHIE_TZ", "America/Toronto"))
WORK_START = int(os.environ.get("WORK_START", "7"))
WORK_END = int(os.environ.get("WORK_END", "18"))


def _client():
    import caldav

    user = os.environ.get("ICLOUD_USER")
    pw = os.environ.get("ICLOUD_APP_PASSWORD")
    if not user or not pw:
        raise SystemExit(
            "Set ICLOUD_USER (your Apple ID email) and ICLOUD_APP_PASSWORD "
            "(an app-specific password from appleid.apple.com)."
        )
    return caldav.DAVClient(url="https://caldav.icloud.com/", username=user, password=pw)


def calendars():
    return _client().principal().calendars()


def _tz(d):
    return d.replace(tzinfo=TZ) if d.tzinfo is None else d.astimezone(TZ)


def events(start, end):
    """All calendar events between two aware datetimes, sorted by start."""
    out = []
    for cal in calendars():
        try:
            comps = cal.get_supported_components() or ["VEVENT"]
            if "VEVENT" not in comps:
                continue  # reminder lists show up as calendars too
            found = cal.date_search(start=start, end=end, expand=True)
        except Exception as e:
            print(f"warning: could not read calendar {cal.name}: {e}", file=sys.stderr)
            continue
        for ev in found:
            try:
                comp = ev.icalendar_component
                s = comp["dtstart"].dt
                e = comp["dtend"].dt if "dtend" in comp else s
            except Exception:
                continue
            timed = isinstance(s, datetime)
            if timed:
                s = _tz(s)
                e = _tz(e) if isinstance(e, datetime) else s
            out.append({
                "start": s, "end": e, "timed": timed,
                "title": str(comp.get("summary", "(no title)")),
                "calendar": cal.name,
            })
    out.sort(key=lambda x: x["start"] if x["timed"] else datetime.combine(x["start"], time(0), TZ))
    return out


def _busy(start, end):
    return [(e["start"], e["end"]) for e in events(start, end) if e["timed"]]


def free_slots(day, minutes=30, step=30):
    """Open slots on `day` (a date) inside working hours. Weekends return nothing."""
    if day.weekday() >= 5:
        return []
    start = datetime.combine(day, time(WORK_START), TZ)
    end = datetime.combine(day, time(WORK_END), TZ)
    busy = _busy(start, end)
    out, t = [], start
    while t + timedelta(minutes=minutes) <= end:
        t2 = t + timedelta(minutes=minutes)
        if not any(t < be and t2 > bs for bs, be in busy):
            out.append(t)
        t += timedelta(minutes=step)
    return out


def _target():
    name = os.environ.get("ICLOUD_CALENDAR")
    cals = []
    for c in calendars():
        try:
            ok = "VEVENT" in (c.get_supported_components() or ["VEVENT"])
        except Exception:
            ok = True
        if ok:
            cals.append(c)
    if name:
        for c in cals:
            if c.name == name:
                return c
        raise SystemExit(f"No calendar named '{name}'. Found: {[c.name for c in cals]}")
    if not cals:
        raise SystemExit("No event calendars found on this iCloud account.")
    import re

    for c in cals:  # the main calendar of the account, not a side calendar that the phone may hide
        if re.match(r"^(calendar|calendrier|home|domicile|maison|personal|personnel|perso|work|travail)$", (c.name or "").strip(), re.I):
            return c
    return cals[0]


def _raw_put(cal, title, start, end, notes=""):
    import uuid
    import requests

    def esc(x):
        return str(x).replace("\\", "\\\\").replace(";", "\\;").replace(",", "\\,").replace("\r", "").replace("\n", "\\n")

    def z(d):
        return d.astimezone(ZoneInfo("UTC")).strftime("%Y%m%dT%H%M%SZ")

    uid = str(uuid.uuid4()).upper()
    ics = "\r\n".join(["BEGIN:VCALENDAR", "VERSION:2.0", "PRODID:-//Archie//EN", "BEGIN:VEVENT", f"UID:{uid}",
                        f"DTSTAMP:{z(datetime.now(TZ))}", f"DTSTART:{z(start)}", f"DTEND:{z(end)}", f"SUMMARY:{esc(title)}"]
                       + ([f"DESCRIPTION:{esc(notes)}"] if notes else []) + ["END:VEVENT", "END:VCALENDAR", ""])
    url = str(cal.url).rstrip("/") + "/" + uid + ".ics"
    r = requests.put(url, data=ics.encode("utf-8"), auth=(os.environ.get("ICLOUD_USER"), os.environ.get("ICLOUD_APP_PASSWORD")),
                     headers={"Content-Type": "text/calendar; charset=utf-8"}, timeout=30)
    if r.status_code >= 300:
        raise RuntimeError(f"iCloud answered {r.status_code}")


def add_event(title, start, minutes=30, notes=""):
    """Add an event. Refuses to double-book."""
    end = start + timedelta(minutes=minutes)
    try:
        busy = _busy(start, end)
    except Exception:
        busy = []  # could not read the day: book anyway rather than refuse
    if busy:
        raise SystemExit("That time overlaps an existing event. Pick another slot.")
    cal = _target()
    try:
        cal.save_event(dtstart=start, dtend=end, summary=title, description=notes)
    except Exception:
        _raw_put(cal, title, start, end, notes)  # the library failed: send the event ourselves, straight to iCloud
    try:  # read it back: the proof that it is really in the calendar
        low = title.lower()[:20]
        seen = any(low in e["title"].lower() and abs((e["start"] - start).total_seconds()) < 180 for e in events(start - timedelta(minutes=1), end + timedelta(minutes=1)))
    except Exception:
        seen = None
    return cal.name, seen


def find_events(start, end):
    """Real calendar objects (not expanded) between two datetimes: [(object, info)]. Recurring events are flagged."""
    out = []
    for cal in calendars():
        try:
            if "VEVENT" not in (cal.get_supported_components() or ["VEVENT"]):
                continue
            found = cal.date_search(start=start, end=end, expand=False)
        except Exception:
            continue
        for ev in found:
            try:
                comp = ev.icalendar_component
                s = comp["dtstart"].dt
                if not isinstance(s, datetime):
                    continue
                e = comp["dtend"].dt if "dtend" in comp else s + timedelta(minutes=30)
                out.append((ev, {"start": _tz(s), "end": _tz(e) if isinstance(e, datetime) else _tz(s) + timedelta(minutes=30),
                                 "title": str(comp.get("summary", "(no title)")), "recurring": "rrule" in comp}))
            except Exception:
                continue
    out.sort(key=lambda x: x[1]["start"])
    return out


def cancel_event(obj):
    obj.delete()


def move_event(obj, info, new_start):
    """Moves one event to a new start (same length). Refuses to land on top of another event."""
    new_end = new_start + (info["end"] - info["start"])
    if any(bs < new_end and be > new_start and not (abs((bs - info["start"]).total_seconds()) < 60 and abs((be - info["end"]).total_seconds()) < 60)
           for bs, be in _busy(new_start, new_end)):
        raise SystemExit("That time overlaps an existing event. Pick another slot.")
    comp = obj.icalendar_component
    comp["dtstart"].dt, comp["dtend"].dt = new_start, new_end
    obj.save()
