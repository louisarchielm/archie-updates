"""What Archie may do on this PC.
Level 1 (looking and opening) runs at once. Level 2 (creating or moving files) only after you say yes.
Level 3 (delete, pay, passwords, sending files out, installing) never: Archie says so and you do it yourself.
Everything is limited to your Documents, Desktop, Downloads and Pictures folders and logged in archie-actions.log."""
import os
import re
import shutil
import time
import unicodedata
import webbrowser
import zipfile
from datetime import datetime
from pathlib import Path

HERE = Path(__file__).resolve().parent.parent
LOG = HERE / "archie-actions.log"
HOME = Path.home()
def _roots():
    """Documents, Desktop, Downloads, Pictures: on the PC itself and in every OneDrive folder (French names too)."""
    bases = [HOME]
    for k in ("OneDrive", "OneDriveConsumer", "OneDriveCommercial"):
        if os.environ.get(k):
            bases.append(Path(os.environ[k]))
    try:
        bases += sorted(HOME.glob("OneDrive*"))
    except OSError:
        pass
    out, seen = [], set()
    for base in bases:
        for n in ("Documents", "Desktop", "Bureau", "Downloads", "T\u00e9l\u00e9chargements", "Pictures", "Images"):
            f = base / n
            try:
                if f.is_dir() and f.resolve() not in seen:
                    seen.add(f.resolve())
                    out.append(f)
            except OSError:
                pass
    return out


ROOTS = _roots()
TEXT = {".txt", ".md", ".csv", ".json", ".log", ".rtf"}


def log(line):
    try:
        with open(LOG, "a", encoding="utf-8") as f:
            f.write(f"{datetime.now():%Y-%m-%d %H:%M:%S}  {line}\n")
    except OSError:
        pass


def _norm(s):
    return "".join(c for c in unicodedata.normalize("NFD", s.lower()) if unicodedata.category(c) != "Mn")


def inside(p):
    try:
        rp = Path(p).expanduser().resolve()
    except OSError:
        return False
    return any(rp == r.resolve() or r.resolve() in rp.parents for r in ROOTS)


# ---------- level 1 ----------
def open_app(name):
    """Starts an installed program by its Start-menu shortcut. Returns the program's name or None."""
    dirs = [Path(os.environ.get("ProgramData", "C:/ProgramData")) / "Microsoft/Windows/Start Menu/Programs",
            Path(os.environ.get("APPDATA", "")) / "Microsoft/Windows/Start Menu/Programs"]
    want, best = _norm(name).strip(), None
    for d in dirs:
        if not d.exists():
            continue
        for p in d.rglob("*.lnk"):
            stem = _norm(p.stem)
            if want and want in stem and "uninstall" not in stem and "desinstall" not in stem:
                if best is None or len(stem) < len(_norm(best.stem)):
                    best = p
    if not best:
        return None
    os.startfile(str(best))  # Windows only
    log(f"open app: {best.stem}")
    return best.stem


def open_url(url):
    if not re.match(r"^https?://", url or "", re.I):
        url = "https://" + (url or "")
    if not re.match(r"^https?://[\w.-]+\.[a-z]{2,}", url, re.I):
        return None
    webbrowser.open(url)
    log(f"open site: {url}")
    return url


def find_files(query, limit=12, seconds=6):
    words = [w for w in re.findall(r"\w+", _norm(query)) if len(w) > 1]
    out, t0 = [], time.time()
    if not words:
        return out
    for root in ROOTS:
        for dp, dn, fn in os.walk(root):
            dn[:] = [d for d in dn if not d.startswith(".") and dp[len(str(root)):].count(os.sep) < 4]
            for f in fn:
                if all(w in _norm(f) for w in words):
                    p = Path(dp) / f
                    try:
                        out.append({"path": str(p), "name": f, "folder": p.parent.name, "mtime": p.stat().st_mtime})
                    except OSError:
                        pass
            if time.time() - t0 > seconds:
                break
    out.sort(key=lambda x: -x["mtime"])
    return out[:limit]


def open_path(path):
    if not inside(path):
        raise PermissionError("outside the allowed folders")
    os.startfile(str(path))
    log(f"open: {path}")


def read_file(path, maxchars=6000, quiet=False):
    if not inside(path):
        raise PermissionError("outside the allowed folders")
    p = Path(path)
    ext = p.suffix.lower()
    if ext in TEXT:
        txt = p.read_text(encoding="utf-8", errors="replace")
    elif ext == ".docx":
        with zipfile.ZipFile(p) as z:
            xml = z.read("word/document.xml").decode("utf-8", "replace")
        txt = re.sub(r"<[^>]+>", " ", re.sub(r"</w:p>", "\n", xml))
    elif ext == ".pdf":
        try:
            from pypdf import PdfReader

            txt = "\n".join((pg.extract_text() or "") for pg in PdfReader(str(p)).pages[:15])
        except ImportError:
            raise RuntimeError("PDF reading is not installed")
    else:
        raise RuntimeError("I can only read text, Word and PDF files")
    if not quiet:
        log(f"read: {path}")
    return re.sub(r"[ \t]+", " ", txt).strip()[:maxchars]


# ---------- level 2 (only after a yes) ----------
def write_text(folder, filename, text):
    f = Path(folder) / re.sub(r'[\\/:*?"<>|]', "_", filename)
    if not inside(f.parent):
        raise PermissionError("outside the allowed folders")
    if f.exists():
        raise FileExistsError("a file with that name already exists")
    f.write_text(text, encoding="utf-8")
    log(f"created file: {f}")
    return f


def move(src, dest_folder, new_name=None):
    s, d = Path(src), Path(dest_folder)
    if not (inside(s) and inside(d)):
        raise PermissionError("outside the allowed folders")
    target = d / (new_name or s.name)
    if target.exists():
        raise FileExistsError("a file with that name already exists there")
    shutil.move(str(s), str(target))
    log(f"moved: {s} -> {target}")
    return target


# ---------- showing things inside Archie's own window ----------
import secrets
from urllib.parse import quote_plus, urlparse, parse_qs

_VIEW = {}  # token -> path, only files inside the allowed folders
_IMG = (".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp")


def embed_url(url):
    """A version of the address that can be shown inside Archie, or None if the site refuses (then it opens in its own window)."""
    import requests

    if not re.match(r"^https?://", url or "", re.I):
        url = "https://" + (url or "")
    u = urlparse(url)
    if not re.match(r"^[\w.-]+\.[a-z]{2,}$", u.hostname or "", re.I):
        return None
    host = (u.hostname or "").lower()
    if host.endswith("youtube.com") and u.path == "/watch" and parse_qs(u.query).get("v"):
        return "https://www.youtube.com/embed/" + parse_qs(u.query)["v"][0]
    if host == "youtu.be" and len(u.path) > 1:
        return "https://www.youtube.com/embed/" + u.path[1:]
    if host.endswith("youtube.com") and u.path.startswith("/embed/"):
        return url
    if "google." in host and u.path.startswith("/maps"):
        q = parse_qs(u.query).get("q") or [u.path.split("/place/")[-1].replace("+", " ") if "/place/" in u.path else ""]
        return "https://www.google.com/maps?q=" + quote_plus(q[0]) + "&output=embed" if q[0] else None
    try:
        r = requests.get(url, stream=True, timeout=6, headers={"User-Agent": "Mozilla/5.0"}, allow_redirects=True)
        h = {k.lower(): v for k, v in r.headers.items()}
        r.close()
    except Exception:
        return None
    xfo = h.get("x-frame-options", "").lower()
    csp = h.get("content-security-policy", "").lower()
    if xfo in ("deny", "sameorigin") or "frame-ancestors" in csp and "frame-ancestors *" not in csp:
        return None
    return r.url


def map_url(query):
    return "https://www.google.com/maps?q=" + quote_plus(query) + "&output=embed"


def file_view(path):
    """A visual to show a file in the app, or None (then it is simply opened). pdf and pictures only."""
    if not inside(path):
        raise PermissionError("outside the allowed folders")
    ext = os.path.splitext(str(path))[1].lower()
    if ext != ".pdf" and ext not in _IMG:
        return None
    tok = secrets.token_urlsafe(18)
    if len(_VIEW) > 50:
        _VIEW.clear()
    _VIEW[tok] = str(path)
    log(f"show in app: {path}")
    return {"type": "file", "title": os.path.basename(str(path)), "kind": "pdf" if ext == ".pdf" else "image", "url": "/api/file?t=" + tok}


def view_path(tok):
    p = _VIEW.get(tok)
    return p if p and inside(p) else None
