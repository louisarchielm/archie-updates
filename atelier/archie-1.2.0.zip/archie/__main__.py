import argparse
from datetime import date, datetime, timedelta

from . import icloud, phone


def _dt(s):
    d = datetime.fromisoformat(s)
    return d.replace(tzinfo=icloud.TZ) if d.tzinfo is None else d


def main():
    p = argparse.ArgumentParser(prog="archie")
    sub = p.add_subparsers(dest="cmd", required=True)

    a = sub.add_parser("agenda", help="list upcoming events")
    a.add_argument("--days", type=int, default=7)

    f = sub.add_parser("free", help="list open slots on a day (YYYY-MM-DD)")
    f.add_argument("day")
    f.add_argument("--minutes", type=int, default=30)

    ad = sub.add_parser("add", help="add an event (refuses to double-book)")
    ad.add_argument("title")
    ad.add_argument("start", help="e.g. 2026-11-20T14:00 (local time)")
    ad.add_argument("--minutes", type=int, default=30)
    ad.add_argument("--notes", default="")

    c = sub.add_parser("connect", help="call a contact, then call you to take the transfer")
    c.add_argument("contact")

    cm = sub.add_parser("callme", help="phone you and read a message aloud")
    cm.add_argument("text")

    ib = sub.add_parser("inbox", help="check mail once and send drafts to Telegram")
    ib.add_argument("--max", type=int, default=10)

    sub.add_parser("watch", help="keep checking mail and listening for Approve taps")

    sub.add_parser("msauth", help="sign in to Microsoft mail (Outlook, Hotmail, Microsoft 365)")

    sub.add_parser("selftest", help="check everything Archie needs and write archie-check.txt")

    sub.add_parser("testai", help="check the AI settings and say what is wrong")

    sub.add_parser("diagnose", help="check mail, Telegram and AI and say what is wrong")

    sp = sub.add_parser("say", help="make an mp3 of Archie saying something (English or French)")
    sp.add_argument("text")
    sp.add_argument("--out", default="archie-say.mp3")

    ap = sub.add_parser("app", help="open the Archie desktop app (voice + screen)")
    ap.add_argument("--no-window", action="store_true")

    sub.add_parser("server", help="run Archie as a server (rented machine): the app connects with an access code")
    sub.add_parser("remote", help="open the app window connected to your Archie server")
    up = sub.add_parser("update", help="check for a new version (add --apply to install it)")
    up.add_argument("--apply", action="store_true")
    sub.add_parser("rollback", help="put back the files from before the last update")
    sub.add_parser("token", help="make a new access code for the server")

    s = sub.add_parser("serve", help="run the Twilio webhook server")
    s.add_argument("--port", type=int, default=8080)


    args = p.parse_args()
    from . import config

    config.load_into_env()

    if args.cmd == "agenda":
        now = datetime.now(icloud.TZ)
        for e in icloud.events(now, now + timedelta(days=args.days)):
            if e["timed"]:
                print(f"{e['start']:%a %b %d %H:%M}-{e['end']:%H:%M}  {e['title']}  ({e['calendar']})")
            else:
                print(f"{e['start']:%a %b %d} all day  {e['title']}  ({e['calendar']})")

    elif args.cmd == "free":
        slots = icloud.free_slots(date.fromisoformat(args.day), args.minutes)
        print("\n".join(f"{t:%a %b %d %H:%M}" for t in slots) or "No open slots that day.")

    elif args.cmd == "add":
        icloud.add_event(args.title, _dt(args.start), args.minutes, args.notes)
        print("Added.")

    elif args.cmd == "connect":
        label = phone.connect(args.contact)
        print(f"Calling {label}. You will be called as soon as they pick up.")

    elif args.cmd == "callme":
        phone.callme(args.text)
        print("Calling you.")

    elif args.cmd == "inbox":
        from . import inbox

        print(inbox.process(args.max), "message(s) sent to Telegram.")
        print("Buttons work while this window stays open (10 minutes). Close it when you are done.", flush=True)
        inbox.listen(600)

    elif args.cmd == "watch":
        from . import inbox

        inbox.watch()

    elif args.cmd == "msauth":
        from . import msgraph

        print("Signed in as", msgraph.sign_in())

    elif args.cmd == "testai":
        from . import diagnose

        diagnose.test_ai()

    elif args.cmd == "diagnose":
        from . import diagnose

        diagnose.run()

    elif args.cmd == "say":
        from . import voice

        print("Saved", voice.speak_to_file(args.text, out=args.out))

    elif args.cmd == "app":
        from . import server

        server.run(not args.no_window)

    elif args.cmd == "server":
        import os

        os.environ["ARCHIE_SERVER_MODE"] = "1"
        from . import server

        server.run(False)

    elif args.cmd == "remote":
        from . import server

        server.remote()

    elif args.cmd == "update":
        from . import updater

        print("Version installée :", updater.version())
        m = updater.check()
        if not m:
            print("Archie est à jour.")
        else:
            print(f"Nouvelle version : {m['version']} - {m.get('notes', '')}")
            if args.apply:
                updater.apply(m)
                print("Installée. Fermez et relancez Archie.")
            else:
                print("Pour l'installer : python -m archie update --apply")

    elif args.cmd == "rollback":
        from . import updater

        print("Remis en place :", updater.rollback())

    elif args.cmd == "token":
        import secrets

        print(secrets.token_urlsafe(32))

    elif args.cmd == "serve":
        phone.serve(args.port)


if __name__ == "__main__":
    main()
