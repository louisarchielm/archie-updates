"""How Archie addresses the person talking: sir, ma'am, or no title. Decided from what they say and from the pitch of their voice."""
import re
import statistics
from pathlib import Path

FILE = Path("archie-title.txt")
_votes = []
_sticky = {"v": None}
SAY_F = re.compile(r"\b(call me (ma'?am|madam|miss|mrs|ms)|i(?:'m| am) a (woman|girl|lady)|i(?:'m| am) (a )?female|appelle[- ]moi (madame|mademoiselle)|je suis une? (femme|fille|dame)|c'est (madame|mademoiselle))\b", re.I)
SAY_M = re.compile(r"\b(call me (sir|mister|mr)|i(?:'m| am) a (man|guy|male)|appelle[- ]moi monsieur|je suis un (homme|gars|monsieur))\b", re.I)


def current():
    if _sticky["v"]:
        return _sticky["v"]
    try:
        v = FILE.read_text().strip()
        return v if v in ("m", "f", "n") else "m"
    except OSError:
        return "m"


def _save(v):
    try:
        FILE.write_text(v)
    except OSError:
        pass


def update(text="", pitch=None):
    """Learn from one sentence: what was said about it, and the median pitch (Hz) of the voice if it was measured."""
    if SAY_F.search(text or ""):
        _sticky["v"] = "f"; _save("f"); return "f"
    if SAY_M.search(text or ""):
        _sticky["v"] = "m"; _save("m"); return "m"
    try:
        p = float(pitch) if pitch else 0
    except (TypeError, ValueError):
        p = 0
    if 60 < p < 450:
        _votes.append("m" if p < 185 else "f")  # a voice in the middle range is still "sir" unless it is clearly higher or he is told otherwise
        del _votes[:-3]
        if _sticky["v"] and len(_votes) >= 2 and all(x != _sticky["v"] for x in _votes[-2:]):
            _sticky["v"] = None  # two sentences in a row sound like someone else
        if not _sticky["v"]:
            v = max(set(_votes), key=_votes.count) if len(_votes) > 1 else _votes[-1]
            _save(v)
            return v
    return current()


def apply(text):
    """Swap the title in a sentence Archie is about to say."""
    v = current()
    if v == "m" or not text:
        return text

    def one(m):
        w = m.group(0)
        fr = w.lower() == "monsieur"
        if v == "f":
            r = "madame" if fr else "ma'am"
        else:
            return ""
        return r.capitalize() if w[0].isupper() else r

    if v == "f":
        return re.sub(r"\b(sir|monsieur)\b", one, text, flags=re.I)
    text = re.sub(r"^\s*(sir|monsieur)\s*,\s*", "", text, flags=re.I)
    text = text[:1].upper() + text[1:]
    text = re.sub(r"\s*,?\s*\b(sir|monsieur)\b(?=\W|$)", "", text, flags=re.I)
    return re.sub(r"\s+([?!.])", r"\1", text).strip()


def word(lang):
    v = current()
    return {"m": "'sir' ('monsieur' in French)", "f": "'ma'am' ('madame' in French)", "n": "no title at all (never sir, never ma'am)"}[v]
