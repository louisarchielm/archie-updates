"""Archie Atelier: work orders for a garage.
The mechanic dictates what a customer asked for. Archie writes the work order, estimates the time, books it in the agenda,
and when the job is finished compares the real time with the estimate, so the next estimates get closer to this shop's reality.
Files (all stay on the PC): archie-workorders.json, archie-atelier-stats.json, archie-bons-de-travail.csv (opens in Excel)."""
import csv
import json
import re
import threading
import time
from datetime import datetime, timedelta
from pathlib import Path

FILE = Path("archie-workorders.json")
STATS = Path("archie-atelier-stats.json")
CSV = Path("archie-bons-de-travail.csv")
_L = threading.RLock()

PARSE = """You write garage work orders from what a mechanic dictates after a customer call (Quebec French or English).
Return JSON only: {{"is_job": true|false, "client": "customer name or empty", "vehicle": "year make model or empty", "job": "short clear description of the work",
"job_type": "2 to 4 lowercase words naming the kind of job, e.g. freins avant, changement d'huile, diagnostic bruit suspension",
"base_minutes": integer, realistic shop time for ONE competent mechanic for this job on this vehicle (include a short inspection; between 15 and 600),
"when": "YYYY-MM-DDTHH:MM local time if he asked for a specific time, else null", "notes": "anything useful: symptoms, parts, phone number"}}
Today is {today}. If the text is not about a customer job, return {{"is_job": false}}.
Jobs this shop already finished (type: estimated, real): {history}"""


# ---------- storage ----------
def _load():
    try:
        return json.loads(FILE.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []


def _save(v):
    FILE.write_text(json.dumps(v, ensure_ascii=False, indent=1), encoding="utf-8")
    try:
        with open(CSV, "w", newline="", encoding="utf-8-sig") as f:  # utf-8-sig: Excel shows the accents correctly
            w = csv.writer(f, delimiter=";")
            w.writerow(["No", "Client", "Véhicule", "Travail", "Prévu (min)", "Réel (min)", "Statut", "Début prévu", "Début réel", "Fin réelle", "Notes"])
            for o in v:
                w.writerow([o["id"], o["client"], o["vehicle"], o["job"], o["est_min"], o.get("actual_min", ""), o["status"], o.get("planned", ""),
                            o.get("started_at", ""), o.get("finished_at", ""), o.get("notes", "")])
    except OSError:
        pass  # the table is a convenience: never block the work order because Excel has the file open


def load():
    with _L:
        return _load()


def _stats():
    try:
        d = json.loads(STATS.read_text(encoding="utf-8"))
        return d if isinstance(d, dict) and "types" in d else {"types": {}, "n": 0, "sum_actual": 0, "sum_base": 0}
    except (OSError, ValueError):
        return {"types": {}, "n": 0, "sum_actual": 0, "sum_base": 0}


def _norm(s):
    return " ".join(re.findall(r"\w+", (s or "").lower().replace("’", "'")))


# ---------- the estimate that learns ----------
def estimate(job_type, base):
    """base: the model's first guess in minutes. Returns (minutes, low, high, n_known).
    Not enough history: stay close to the guess, corrected by how this shop differs from the guess overall.
    More history for this kind of job: lean on the real times."""
    st = _stats()
    base = max(10, min(600, int(base or 60)))
    m = (st["sum_base"] / st["n"]) if st["n"] else 60.0
    g = (st["sum_actual"] + 3 * m) / (st["sum_base"] + 3 * m) if st["n"] else 1.0  # shop-wide ratio, pulled to 1.0 while data is thin
    t = st["types"].get(_norm(job_type))
    if t and t["n"]:
        n = t["n"]
        est = (t["sum_actual"] + 2 * base * g) / (n + 2)
    else:
        n, est = 0, base * g
    est = max(10, int(round(est / 5.0)) * 5)
    spread = max(0.12, 0.35 - 0.06 * n)  # the range tightens as the shop's own data grows
    return est, max(10, int(round(est * (1 - spread) / 5.0)) * 5), int(round(est * (1 + spread) / 5.0)) * 5, n


def _history(limit=8):
    out = []
    for o in reversed(load()):
        if o["status"] == "done" and o.get("actual_min"):
            out.append(f"{o['job_type']}: {o['est_min']} min, {o['actual_min']} min")
        if len(out) >= limit:
            break
    return "; ".join(out) or "none yet"


def dur(m, fr=True):
    m = int(round(m))
    h, mi = divmod(m, 60)
    if h and mi:
        return f"{h} h {mi:02d}" if fr else f"{h} h {mi:02d} min"
    return f"{h} h" if h else f"{mi} min"


# ---------- creating a work order ----------
def parse(text):
    from . import brain, icloud

    today = datetime.now(icloud.TZ).strftime("%A %Y-%m-%d %H:%M")
    return brain.ask_json(f'The mechanic said: "{text}".', PARSE.format(today=today, history=_history()), max_tokens=500)


def _plan(minutes, when=None):
    """First free stretch in the agenda (or the asked time if free). Returns a datetime or None."""
    from . import icloud

    now = datetime.now(icloud.TZ)
    if when:
        try:
            w = datetime.fromisoformat(when)
            w = w.replace(tzinfo=icloud.TZ) if w.tzinfo is None else w
            if w > now and not icloud._busy(w, w + timedelta(minutes=minutes)):
                return w
        except (ValueError, SystemExit, Exception):
            pass
    for k in range(0, 15):
        day = (now + timedelta(days=k)).date()
        try:
            slots = icloud.free_slots(day, min(minutes, 600))
        except BaseException:
            return None
        for s in slots:
            if s >= now + timedelta(minutes=10):
                return s
    return None


def create(info, raw=""):
    """info: the parsed dict. Books the agenda. Returns the work order dict."""
    from . import icloud

    est, low, high, n = estimate(info.get("job_type") or info.get("job") or "", info.get("base_minutes"))
    with _L:
        v = _load()
        wid = (max([o["id"] for o in v]) + 1) if v else 1
        o = {"id": wid, "client": (info.get("client") or "").strip()[:60], "vehicle": (info.get("vehicle") or "").strip()[:60],
             "job": (info.get("job") or "").strip()[:140], "job_type": _norm(info.get("job_type") or info.get("job"))[:40],
             "base_min": int(info.get("base_minutes") or 60), "est_min": est, "low": low, "high": high, "known": n,
             "notes": (info.get("notes") or "").strip()[:200], "status": "planned", "created": datetime.now(icloud.TZ).isoformat(timespec="minutes")}
        s = _plan(est, info.get("when"))
        if s:
            title = " – ".join(x for x in (o["client"], o["vehicle"], o["job"]) if x)[:100]
            try:
                icloud.add_event(title, s, est, f"Bon de travail no {wid}. Prévu {dur(est)}. Ajouté par Archie.")
                o["planned"] = s.isoformat(timespec="minutes")
            except BaseException as e:
                o["plan_error"] = str(e)[:100]
        v.append(o)
        _save(v)
    return o


# ---------- start / finish ----------
def find(text, statuses=("planned", "started"), pick_first=False):
    """The open work order named in the sentence (client, vehicle or number). One match or None."""
    t = _norm(text)
    cands = [o for o in load() if o["status"] in statuses]
    hits = []
    for o in cands:
        c, vh = _norm(o["client"]), _norm(o["vehicle"])
        words = [w for w in c.split() if len(w) > 2]
        if (c and c in t) or (words and any(w in t.split() for w in words)) or (vh and vh in t) or re.search(rf"\b(no|numero|#|bt)\s*{o['id']}\b", t):
            hits.append(o)
    if pick_first and hits:  # several jobs for the same customer: the one already running, else the oldest
        return sorted(hits, key=lambda o: (o["status"] != "started", o["id"]))[0]
    return hits[0] if len(hits) == 1 else None


def current():
    s = [o for o in load() if o["status"] == "started"]
    return s[0] if len(s) == 1 else None


def start(wid):
    from . import icloud

    with _L:
        v = _load()
        for o in v:
            if o["id"] == wid and o["status"] in ("planned", "started"):
                if o["status"] == "planned":
                    o["status"] = "started"
                    o["started_at"] = datetime.now(icloud.TZ).isoformat(timespec="seconds")
                _save(v)
                return o
    return None


def finish(wid, actual_min=None):
    """Closes the order and learns. Returns (order, review dict) or (None, None)."""
    from . import icloud

    with _L:
        v = _load()
        for o in v:
            if o["id"] != wid or o["status"] not in ("started", "planned"):
                continue
            now = datetime.now(icloud.TZ)
            if actual_min is None:
                if not o.get("started_at"):
                    return None, None  # never started: the real time is unknown, ask him
                actual_min = max(1, int(round((now - datetime.fromisoformat(o["started_at"])).total_seconds() / 60)))
            o["status"], o["finished_at"], o["actual_min"] = "done", now.isoformat(timespec="seconds"), int(actual_min)
            before = estimate(o["job_type"], o["base_min"])[0]
            st = _stats()
            t = st["types"].setdefault(o["job_type"], {"n": 0, "sum_actual": 0, "sum_base": 0})
            t["n"] += 1
            t["sum_actual"] += int(actual_min)
            t["sum_base"] += o["base_min"]
            st["n"] += 1
            st["sum_actual"] += int(actual_min)
            st["sum_base"] += o["base_min"]
            STATS.write_text(json.dumps(st, ensure_ascii=False), encoding="utf-8")
            after = estimate(o["job_type"], o["base_min"])
            _save(v)
            return o, {"est": o["est_min"], "actual": int(actual_min), "diff": int(actual_min) - o["est_min"], "next": after[0], "was_next": before, "n": t["n"]}
    return None, None


def cancel(wid):
    from . import icloud

    with _L:
        v = _load()
        for o in v:
            if o["id"] == wid and o["status"] in ("planned", "started"):
                o["status"] = "cancelled"
                if o.get("planned"):
                    try:
                        s = datetime.fromisoformat(o["planned"])
                        for obj, info in icloud.find_events(s - timedelta(minutes=1), s + timedelta(minutes=o["est_min"] + 1)):
                            if f"no {wid}" in (str(obj) + info.get("title", "")) or o["client"] and o["client"].lower() in info.get("title", "").lower():
                                icloud.cancel_event(obj)
                                break
                    except BaseException:
                        pass
                _save(v)
                return o
    return None


def review_text(o, r, fr=True):
    who = " – ".join(x for x in (o["client"], o["vehicle"]) if x) or f"no {o['id']}"
    d = r["diff"]
    if abs(d) <= max(5, r["est"] * 0.1):
        verdict = ("Estimation juste." if fr else "The estimate was right.")
    elif d > 0:
        verdict = (f"Ça a pris {dur(d)} de plus que prévu." if fr else f"It took {dur(d, False)} longer than planned.")
    else:
        verdict = (f"Ça a pris {dur(-d)} de moins que prévu." if fr else f"It took {dur(-d, False)} less than planned.")
    if r["n"] == 1:
        learn = ("C'est la première fois que j'apprends ce type de travail." if fr else "This is the first time I learn this kind of job.")
    else:
        learn = (f"Je m'ajuste ({r['n']} travaux de ce type)." if fr else f"I am adjusting ({r['n']} jobs of this kind).")
    nxt = (f"La prochaine fois : {dur(r['next'])}." if fr else f"Next time: {dur(r['next'], False)}.")
    return (f"{who} : prévu {dur(r['est'])}, réel {dur(r['actual'])}. {verdict} {learn} {nxt}" if fr else
            f"{who}: planned {dur(r['est'], False)}, actual {dur(r['actual'], False)}. {verdict} {learn} {nxt}")


# ---------- what the screen shows ----------
def card(fr=True):
    v = load()
    live = [o for o in v if o["status"] in ("planned", "started")]
    live.sort(key=lambda o: (o["status"] != "started", o.get("planned") or "9999"))
    done = [o for o in v if o["status"] == "done"][-4:]
    rows = []
    for o in live + done[::-1]:
        when = ""
        if o.get("planned"):
            p = datetime.fromisoformat(o["planned"])
            when = (["lun", "mar", "mer", "jeu", "ven", "sam", "dim"][p.weekday()] + p.strftime(" %H:%M")) if fr else p.strftime("%a %I:%M %p").lstrip("0")
        rows.append({"id": o["id"], "when": when, "client": o["client"] or "?", "vehicle": o["vehicle"] or "?", "job": o["job"],
                     "est": dur(o["est_min"], fr) + (f" ({dur(o['low'], fr)}–{dur(o['high'], fr)})" if o["status"] == "planned" else ""),
                     "actual": dur(o["actual_min"], fr) if o.get("actual_min") else "", "status": o["status"]})
    return {"type": "wo", "title": "Bons de travail" if fr else "Work orders", "rows": rows,
            "labels": {"start": "Démarrer" if fr else "Start", "done": "Terminé" if fr else "Done", "empty": "Aucun bon de travail." if fr else "No work orders.",
                       "cols": ["Heure", "Client", "Travail", "Prévu", "", ""] if fr else ["Time", "Customer", "Job", "Planned", "", ""]}}


def learned(fr=True):
    st = _stats()
    rows = sorted(st["types"].items(), key=lambda kv: -kv[1]["n"])[:10]
    return [[k, str(t["n"]), dur(t["sum_actual"] / t["n"], fr)] for k, t in rows]
