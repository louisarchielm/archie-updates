"""Checks each part of Archie's email setup and says what is wrong. Never prints passwords or tokens."""
import imaplib
import os

import requests

from . import mailbox


def _clean(text):
    for k in ("ARCHIE_BOT_TOKEN", "TELEGRAM_BOT_TOKEN", "MAIL_APP_PASSWORD"):
        v = os.environ.get(k)
        if v:
            text = text.replace(v, "***")
    return text


def run():
    lines = []

    def say(ok, msg):
        lines.append(("OK    " if ok else "FAIL  ") + _clean(msg))
        print(lines[-1], flush=True)

    from . import msgraph

    ms = msgraph.enabled()
    need = ("OWNER_NAME", "ARCHIE_BOT_TOKEN", "TELEGRAM_CHAT_ID") if ms else \
        ("OWNER_NAME", "MAIL_USER", "MAIL_APP_PASSWORD", "ARCHIE_BOT_TOKEN", "TELEGRAM_CHAT_ID")
    for k in need:
        say(bool(os.environ.get(k)), f"{k} is {'saved' if os.environ.get(k) else 'MISSING (run its save file, then open a NEW window)'}")
    user = os.environ.get("MAIL_USER", "")
    if ms:
        try:
            say(True, "Microsoft sign-in works for " + msgraph.whoami())
            import requests as _r

            r = _r.get(msgraph.GRAPH + "/me/mailFolders/inbox/messages?$top=1&$select=subject",
                       headers={"Authorization": "Bearer " + msgraph._token()}, timeout=30)
            say(r.status_code == 200, f"can read the inbox (Microsoft answered {r.status_code})")
        except BaseException as e:
            say(False, "Microsoft mail problem: " + str(e)[:200])
    elif user:
        say(True, "mail address: " + user)
    try:
        if ms:
            raise SystemExit("__skip__")
        u, pw, imap_host, smtp_host = mailbox.settings()
        say(True, f"mail servers: {imap_host} / {smtp_host}")
        m = imaplib.IMAP4_SSL(imap_host)
        m.login(u, pw)
        m.select("INBOX", readonly=True)
        _, d = m.search(None, "ALL")
        say(True, f"mail login works, {len((d[0] or b'').split())} messages in the inbox")
        m.logout()
    except SystemExit as e:
        if str(e) != "__skip__":
            say(False, str(e))
    except Exception as e:
        say(False, "mail login failed: " + str(e)[:200] + "  (usually a wrong app password, or IMAP is switched off)")
    tok = os.environ.get("ARCHIE_BOT_TOKEN")
    chat = os.environ.get("TELEGRAM_CHAT_ID")
    if tok:
        try:
            r = requests.get(f"https://api.telegram.org/bot{tok}/getMe", timeout=30).json()
            say(bool(r.get("ok")), "Telegram bot: " + (("@" + r["result"]["username"]) if r.get("ok") else str(r)[:150]))
            if r.get("ok") and chat:
                r2 = requests.post(f"https://api.telegram.org/bot{tok}/sendMessage",
                                   json={"chat_id": chat, "text": "Archie test: Telegram works."}, timeout=30).json()
                say(bool(r2.get("ok")), "test message to your chat: " + ("sent" if r2.get("ok") else str(r2)[:200]))
        except Exception as e:
            say(False, "Telegram problem: " + str(e)[:200])
    try:
        from . import brain

        ans = brain.ask("Reply with the single word: ready", timeout=120)
        say(True, "AI answered: " + ans.strip()[:40])
    except Exception as e:
        say(False, "AI not reachable: " + str(e)[:150] + "  (is Ollama running?)")
    return "\n".join(lines)


def test_ai():
    """Checks the AI settings one by one and says what is wrong. Never prints the key."""
    import os

    import requests

    url = os.environ.get("ARCHIE_LLM_URL", "")
    key = os.environ.get("ARCHIE_LLM_KEY", "").strip()
    model = os.environ.get("ARCHIE_LLM_MODEL", "")
    print("Address saved :", url or "(none - using the free local AI)")
    print("Model saved   : %r" % model)
    print("Key saved     :", ("yes, %d characters, starts with %r" % (len(key), key[:7])) if key else "NO KEY SAVED")
    if "anthropic.com" not in url:
        print("The address is not https://api.anthropic.com - run save-ai.bat again.")
        return
    if not key.startswith("sk-ant-"):
        print("The key does not look right (it should start with sk-ant-). Run save-ai.bat again and paste the key.")
    h = {"x-api-key": key, "anthropic-version": "2023-06-01"}
    r = requests.get("https://api.anthropic.com/v1/models?limit=100", headers=h, timeout=30)
    print("\nAsking Anthropic which models your key can use ->", r.status_code)
    if r.ok:
        ids = [m["id"] for m in r.json().get("data", [])]
        print("Models available:", ", ".join(ids[:30]))
        if model.strip().lower().replace(".", "-") not in ids:
            print("\n>>> Your saved model name is NOT in that list. Use one of the names above in save-ai.bat.")
    else:
        print(r.text[:300])
        if r.status_code == 401:
            print(">>> The key is refused. Create a new key and run save-ai.bat again.")
        return
    from . import brain

    try:
        print("\nTest question ->", brain.ask("Say hello in five words.", "", 60))
    except Exception as e:
        print("\nTest question failed:", e)
