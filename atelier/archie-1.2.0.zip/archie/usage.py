"""Counts what the AI costs (Claude only) and enforces a monthly cap in dollars. Kept in archie-usage.json.
ARCHIE_MONTHLY_CAP = dollars per month (0 or empty = no cap). Warn at 80 %, fall back to the cheap model at 100 %, stop at 150 %."""
import json
import os
import time
from pathlib import Path

FILE = Path("archie-usage.json")
PRICE = {"haiku": (0.10, 0.50), "sonnet": (2.0, 10.0), "opus": (4.0, 20.0)}  # $ per million tokens (in, out)
SEARCH = 0.01  # $ per web search
CHEAP = "claude-haiku-5-5"


def _month():
    return time.strftime("%Y-%m")


def _load():
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        if d.get("month") == _month():
            return d
    except (OSError, ValueError):
        pass
    return {"month": _month(), "usd": 0.0, "calls": 0, "searches": 0, "by_model": {}}


def cap():
    try:
        return float(os.environ.get("ARCHIE_MONTHLY_CAP", "0").replace(",", ".").replace("$", "").strip() or 0)
    except ValueError:
        return 0.0


def cost(model, tin, tout, searches=0):
    p = next((v for k, v in PRICE.items() if k in model), PRICE["sonnet"])  # unknown model: assume the dearer price
    return tin * p[0] / 1e6 + tout * p[1] / 1e6 + searches * SEARCH


def record(model, usage):
    try:
        d = _load()
        s = ((usage.get("server_tool_use") or {}).get("web_search_requests")) or 0
        c = cost(model, usage.get("input_tokens", 0) + usage.get("cache_creation_input_tokens", 0) + usage.get("cache_read_input_tokens", 0) * 0.1,
                 usage.get("output_tokens", 0), s)
        d["usd"] = round(d["usd"] + c, 6)
        d["calls"] += 1
        d["searches"] += s
        m = d["by_model"].setdefault(model, 0.0)
        d["by_model"][model] = round(m + c, 6)
        FILE.write_text(json.dumps(d), encoding="utf-8")
    except Exception:
        pass


def level():
    """'ok' | 'warn' (80 %) | 'over' (100 %: cheap model only) | 'stop' (150 %)."""
    c = cap()
    if c <= 0:
        return "ok"
    u = _load()["usd"]
    return "stop" if u >= c * 1.5 else "over" if u >= c else "warn" if u >= c * 0.8 else "ok"


def allow_deep():
    """Opus is allowed only with a monthly cap set, and only while spending is under ARCHIE_OPUS_BELOW percent of it (default 40)."""
    c = cap()
    if c <= 0 or level() != "ok":
        return False
    try:
        pct = float(os.environ.get("ARCHIE_OPUS_BELOW", "40").replace(",", ".").replace("%", "").strip() or 40)
    except ValueError:
        pct = 40.0
    return _load()["usd"] < c * pct / 100


def status(fr=True):
    d, c = _load(), cap()
    line = f"{d['usd']:.2f} $ " + ("ce mois-ci" if fr else "this month") + (f" / {c:.2f} $" if c > 0 else "") + f" ({d['calls']} " + ("appels" if fr else "calls") + ")"
    lv = level()
    if lv == "warn":
        line += (" - proche du plafond." if fr else " - close to the cap.")
    elif lv == "over":
        line += (" - plafond atteint, modèle économique seulement." if fr else " - cap reached, cheap model only.")
    elif lv == "stop":
        line += (" - suspendu jusqu'au mois prochain." if fr else " - paused until next month.")
    return line
