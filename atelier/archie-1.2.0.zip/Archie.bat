@echo off
rem Archie - le seul fichier a ouvrir. Au premier lancement il s'installe tout seul.
cd /d "%~dp0"
title ARCHIE
if not exist ".venv\Scripts\python.exe" goto install
if /i "%~1"=="hidden" goto run
fc /b requirements.txt .venv\req.done >nul 2>&1
if errorlevel 1 goto run
rem tout est deja installe : Archie demarre sans fenetre noire
call :vbs
start "" wscript //nologo archie-hidden.vbs
exit /b
:run
rem ferme l'ancien Archie (sans laisser de fenetre noire d'erreur), puis met a jour les composants seulement si la liste a change
echo.>archie-restart.flag
for /f "tokens=5" %%p in ('netstat -ano ^| findstr ":8765 " ^| findstr LISTENING') do taskkill /F /PID %%p >nul 2>&1
ping -n 2 127.0.0.1 >nul
del archie-restart.flag >nul 2>&1
call ".venv\Scripts\activate.bat"
fc /b requirements.txt .venv\req.done >nul 2>&1
if errorlevel 1 (
  echo Mise a jour des composants d'Archie...
  pip install -q -r requirements.txt
  if errorlevel 1 goto pipfail
  copy /y requirements.txt .venv\req.done >nul
)
if not exist ".venv\lnk.v2" powershell -NoProfile -Command "$d=[Environment]::GetFolderPath('Desktop'); Remove-Item ($d+'\Archie.lnk') -ErrorAction SilentlyContinue; $s=(New-Object -ComObject WScript.Shell).CreateShortcut($d+'\ARCHIE.lnk'); $s.TargetPath='wscript.exe'; $s.Arguments='//nologo archie-hidden.vbs'; $s.WorkingDirectory='%~dp0'; $s.IconLocation='%~dp0archie\ui\archie.ico'; $s.Description='ARCHIE'; $s.WindowStyle=7; $s.Save()" >nul 2>&1
if not exist ".venv\lnk.v2" echo.>".venv\lnk.v2"
call :vbs
if /i "%~1"=="hidden" goto runhidden
echo Archie demarre... Une fenetre va s'ouvrir. Reduisez cette fenetre noire cette fois-ci : elle n'apparaitra plus aux prochaines ouvertures.
python -m archie app
if errorlevel 1 (
  if exist archie-restart.flag exit /b
  echo.
  echo Archie s'est arrete avec une erreur. Prenez une photo de cet ecran et envoyez-la a AnchorLine.
  pause
)
exit /b

:runhidden
python -m archie app 2>archie-error.txt
if errorlevel 1 (
  if exist archie-restart.flag exit /b
  start "" notepad archie-error.txt
)
exit /b

:install
echo Premiere ouverture : installation d'Archie. Cela prend quelques minutes et demande internet.
where py >nul 2>nul
if errorlevel 1 (
  echo Python n'est pas installe. Installation de Python...
  winget install -e --id Python.Python.3.12 --silent --accept-package-agreements --accept-source-agreements
  echo.
  echo Python est installe. FERMEZ cette fenetre et double-cliquez de nouveau sur Archie.
  pause
  exit /b
)
py -3.12 -m venv .venv
if errorlevel 1 py -3 -m venv .venv
if not exist ".venv\Scripts\python.exe" (
  echo Impossible de preparer Archie. Prenez une photo de cet ecran pour AnchorLine.
  pause
  exit /b 1
)
call ".venv\Scripts\activate.bat"
pip install -r requirements.txt
if errorlevel 1 goto pipfail
copy /y requirements.txt .venv\req.done >nul
goto run

:pipfail
if /i "%~1"=="hidden" (
  start "" "%~dp0Archie.bat"
  exit /b 1
)
echo.
echo L'installation a echoue. Verifiez internet puis double-cliquez de nouveau sur Archie. Sinon, photo de l'ecran a AnchorLine.
pause
exit /b 1

:vbs
>archie-hidden.vbs echo Set s=CreateObject("WScript.Shell")
>>archie-hidden.vbs echo d=CreateObject("Scripting.FileSystemObject").GetParentFolderName(WScript.ScriptFullName)
>>archie-hidden.vbs echo s.CurrentDirectory=d
>>archie-hidden.vbs echo s.Run "cmd /c """ ^& d ^& "\Archie.bat"" hidden",0,False
exit /b
