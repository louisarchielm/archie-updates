@echo off
rem Ancien nom, garde pour que le demarrage automatique continue de marcher.
call "%~dp0Archie.bat"
