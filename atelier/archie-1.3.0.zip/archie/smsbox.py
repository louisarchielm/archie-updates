"""Texts from the owner's phone: an iPhone Shortcut forwards each incoming message to Archie, Archie keeps it,
tells the owner, drafts a reply, and (after a yes) queues it for a second Shortcut that sends it from the phone.
Archie never sends anything himself and never reaches into the phone: the phone pushes, the phone pulls."""
import hmac
import json
import os
import socket
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse

FILE = Path("archie-sms.json")
_L = threading.Lock()
_HITS = {}
MAXTXT = 2000


def enabled():
    return len(os.environ.get("ARCHIE_SMS_TOKEN", "")) >= 12


def port():
    try:
        return int(os.environ.get("ARCHIE_SMS_PORT", "8766"))
    except ValueError:
        return 8766


def lan_ip():
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("10.255.255.255", 1))
        ip = s.getsockname()[0]
        s.close()
        return ip
    except Exception:
        return "127.0.0.1"


def _load():
    try:
        d = json.loads(FILE.read_text(encoding="utf-8"))
        if isinstance(d, dict):
            d.setdefault("in", [])
            d.setdefault("out", [])
            return d
    except Exception:
        pass
    return {"in": [], "out": []}


def _save(d):
    d["in"] = d["in"][-200:]
    d["out"] = d["out"][-100:]
    try:
        FILE.write_text(json.dumps(d, ensure_ascii=False, indent=1), encoding="utf-8")
    except Exception:
        pass


def receive(sender, text):
    sender, text = str(sender or "").strip()[:80] or "?", str(text or "").strip()[:MAXTXT]
    if not text:
        return None
    with _L:
        d = _load()
        for o in d["in"][-5:]:  # the phone sometimes fires twice for one message
            if o["from"] == sender and o["text"] == text and time.time() - o["ts"] < 90:
                return None
        m = {"id": uuid.uuid4().hex[:8], "from": sender, "text": text, "ts": time.time(), "read": False}
        d["in"].append(m)
        _save(d)
    return m


def unread():
    return [m for m in _load()["in"] if not m.get("read")]


def mark_read(ids):
    with _L:
        d = _load()
        for m in d["in"]:
            if m["id"] in ids:
                m["read"] = True
        _save(d)


def recent(sender=None, n=6):
    ms = _load()["in"]
    if sender:
        s = sender.lower()
        ms = [m for m in ms if s in m["from"].lower()]
    return ms[-n:]


def last_sender(max_age=1800):
    ms = _load()["in"]
    return ms[-1] if ms and time.time() - ms[-1]["ts"] <= max_age else None


def queue_reply(to, text):
    with _L:
        d = _load()
        d["out"].append({"id": uuid.uuid4().hex[:8], "to": str(to)[:80], "text": str(text)[:MAXTXT], "ts": time.time(), "sent": False})
        _save(d)


def take_reply():
    """Handed to the phone's second Shortcut: the oldest queued reply, marked as sent."""
    with _L:
        d = _load()
        for o in d["out"]:
            if not o["sent"]:
                o["sent"] = True
                _save(d)
                return o
    return None


def pending_out():
    return [o for o in _load()["out"] if not o["sent"]]


def _ok_token(given):
    tok = os.environ.get("ARCHIE_SMS_TOKEN", "")
    return bool(tok) and hmac.compare_digest(str(given or ""), tok)


def _rate(ip):
    now = time.time()
    h = [t for t in _HITS.get(ip, []) if now - t < 60]
    h.append(now)
    _HITS[ip] = h
    return len(h) <= 60


def make_handler(on_new):
    class H(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def _send(self, code, body="ok"):
            b = body.encode("utf-8")
            self.send_response(code)
            self.send_header("Content-Type", "text/plain; charset=utf-8")
            self.send_header("Content-Length", str(len(b)))
            self.end_headers()
            self.wfile.write(b)

        def _auth(self, q, body):
            return _ok_token(self.headers.get("X-Token") or (q.get("t") or [""])[0] or body.get("t", ""))

        def do_POST(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if not _rate(self.client_address[0]):
                return self._send(429, "slow down")
            try:
                n = min(int(self.headers.get("Content-Length") or 0), 20000)
                raw = self.rfile.read(n).decode("utf-8", "replace")
            except Exception:
                return self._send(400, "bad")
            body = {}
            try:
                j = json.loads(raw)
                body = j if isinstance(j, dict) else {}
            except Exception:
                body = {k: v[0] for k, v in parse_qs(raw).items()}
            if not self._auth(q, body):
                return self._send(403, "no")
            if u.path != "/sms-in":
                return self._send(404, "no")
            m = receive(body.get("from") or (q.get("from") or [""])[0], body.get("text") or body.get("body") or (q.get("text") or [""])[0])
            if m:
                try:
                    on_new(m)
                except BaseException:
                    pass
            self._send(200)

        def do_GET(self):
            u = urlparse(self.path)
            q = parse_qs(u.query)
            if not _rate(self.client_address[0]):
                return self._send(429, "slow down")
            if not self._auth(q, {}):
                return self._send(403, "no")
            if u.path == "/sms-out":
                o = take_reply()
                return self._send(200, (o["to"] + "\n" + o["text"]) if o else "")
            self._send(404, "no")
    return H


def start(on_new):
    if not enabled():
        return False
    try:
        srv = ThreadingHTTPServer(("0.0.0.0", port()), make_handler(on_new))
    except OSError:
        return False
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return True
