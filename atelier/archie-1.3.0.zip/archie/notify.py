"""Reaching the owner outside the app: a phone call when it is urgent, a text message when it is not."""
import os
import time

import requests

from . import phone, tier


def configured():
    return tier.phone_ok() and all(os.environ.get(k) for k in ("TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM", "MY_PHONE"))


def quiet():
    """No phone calls during quiet hours (default 22:00 to 07:00); texts still go out."""
    try:
        a, b = [int(x) for x in os.environ.get("ARCHIE_QUIET", "22-7").split("-")]
    except ValueError:
        return False
    h = time.localtime().tm_hour
    return (a <= h or h < b) if a > b else (a <= h < b)


def sms(text):
    c = phone.cfg(need_url=False)
    r = requests.post(f"https://api.twilio.com/2010-04-01/Accounts/{c['TWILIO_ACCOUNT_SID']}/Messages.json",
                      auth=(c["TWILIO_ACCOUNT_SID"], c["TWILIO_AUTH_TOKEN"]),
                      data={"To": c["MY_PHONE"], "From": c["TWILIO_FROM"], "Body": text[:600]}, timeout=30)
    if r.status_code >= 300:
        raise RuntimeError(f"Twilio text error {r.status_code}: {r.text[:160]}")


def route(level, text):
    """urgent: call (unless quiet hours) and a text copy. normal: text. Returns the channels used."""
    used = []
    if not configured():
        return used
    try:
        if level == "urgent":
            if not quiet():
                phone.callme(text, talk=True)  # two-way when the public address is set up, otherwise he just reads it
                used.append("call")
            sms(text)
            used.append("text")
        elif level == "normal":
            sms(text)
            used.append("text")
    except BaseException as e:
        print("Notify failed:", str(e)[:160], flush=True)
    return used
