"""Twilio voice: call you with an update, and the "client is on the other line" transfer.

Transfer flow:
  1. `connect "Jane Doe"` dials the client (who must be in contacts.json).
  2. When the client answers, the assistant introduces itself as an AI, and puts them on hold
     in a conference room.
  3. Only then does it ring YOU: "Jane Doe is on the other line. Press 1 to take the call,
     or 2 to send them to voicemail."
  4. Press 1 and you are joined into the same room. Press 2 (or don't answer) and the client is
     told you will get back to them.

The webhook server only accepts requests signed by Twilio.
"""
import base64
import hashlib
import hmac
import json
import os
import re
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlencode
from xml.sax.saxutils import escape

import requests

API = "https://api.twilio.com/2010-04-01/Accounts/{sid}/Calls"
LOCK = threading.Lock()
ROOMS = {}
ROOM_RE = re.compile(r"[0-9a-f]{12}")
CONF = (
    '<Dial><Conference beep="false" startConferenceOnEnter="{start}" '
    'endConferenceOnExit="true">{room}</Conference></Dial>'
)


def cfg(need_url=True):
    keys = ["TWILIO_ACCOUNT_SID", "TWILIO_AUTH_TOKEN", "TWILIO_FROM", "MY_PHONE"]
    if need_url:
        keys.append("PUBLIC_URL")
    c = {k: os.environ.get(k, "") for k in keys}
    missing = [k for k, v in c.items() if not v]
    if missing:
        raise SystemExit("Set these environment variables first: " + ", ".join(missing))
    c["PUBLIC_URL"] = c.get("PUBLIC_URL", "").rstrip("/")
    c["OWNER"] = os.environ.get("OWNER_NAME", "the owner")
    return c


def _post(c, path, data):
    sid = c["TWILIO_ACCOUNT_SID"]
    r = requests.post(
        API.format(sid=sid) + path, auth=(sid, c["TWILIO_AUTH_TOKEN"]), data=data, timeout=30
    )
    if r.status_code >= 300:
        raise RuntimeError(f"Twilio error {r.status_code}: {r.text[:200]}")
    return r.json()


def _url(c, path, **q):
    return c["PUBLIC_URL"] + path + ("?" + urlencode(q) if q else "")


def twiml(body):
    return f'<?xml version="1.0" encoding="UTF-8"?><Response>{body}</Response>'


# ---- commands used from the CLI -------------------------------------------------------

def callme(text, talk=False):
    """Phone YOU and read a message aloud (meeting reminders, schedule changes). With talk=True and a public address set up, the call turns into a two-way conversation."""
    c = cfg(need_url=False)
    if talk and os.environ.get("PUBLIC_URL"):
        try:
            c["PUBLIC_URL"] = os.environ["PUBLIC_URL"].rstrip("/")
            _post(c, ".json", {"To": c["MY_PHONE"], "From": c["TWILIO_FROM"], "Url": _url(c, "/voice", g=text[:200])})
            return
        except RuntimeError:
            pass
    try:
        _post(c, ".json", {
            "To": c["MY_PHONE"], "From": c["TWILIO_FROM"],
            "Twiml": f"<Response><Say>{escape(text)}</Say></Response>",
        })
    except RuntimeError as e:
        if "trial" not in str(e).lower():
            raise
        # Twilio trial accounts may not send their own text. Ring with Twilio's sample message
        # instead, which still proves the phone line works.
        _post(c, ".json", {
            "To": c["MY_PHONE"], "From": c["TWILIO_FROM"],
            "Url": "http://demo.twilio.com/docs/voice.xml",
        })
        print("NOTE: this is a Twilio TRIAL account, so it can only play Twilio's sample message, "
              "not your own text. Upgrade the account to unlock custom messages and transfers.")


def load_contacts():
    path = os.environ.get("CONTACTS_FILE", "contacts.json")
    try:
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        raise SystemExit(
            f"No {path}. Copy contacts.example.json to contacts.json and add the clients "
            "you allow the assistant to call. Edit this file yourself."
        )


def connect(name):
    """Dial a contact from contacts.json; you get called once they pick up."""
    contacts = load_contacts()
    hits = {k: v for k, v in contacts.items() if k.lower() == name.lower()}
    if not hits:
        raise SystemExit(f"'{name}' is not in contacts.json, so I will not call them.")
    label, number = next(iter(hits.items()))
    if not re.fullmatch(r"\+\d{8,15}", number):
        raise SystemExit(f"Number for '{label}' must look like +15145551234.")
    c = cfg()
    _post(c, ".json", {
        "To": number, "From": c["TWILIO_FROM"], "Timeout": 25,
        "Url": _url(c, "/client", room=secrets.token_hex(6), name=label),
    })
    return label


# ---- webhook handlers -----------------------------------------------------------------

def _decline(c, room):
    with LOCK:
        st = ROOMS.get(room)
        if not st or st["state"] != "ringing":
            return
        st["state"] = "declined"
        sid = st["client_sid"]
    try:
        _post(c, f"/{sid}.json", {"Twiml": (
            "<Response><Say>Sorry, " + escape(c["OWNER"]) + " cannot take the call right now. "
            "They will get back to you shortly.</Say><Hangup/></Response>")})
    except Exception as e:
        print("could not release client:", e)
    with LOCK:
        ROOMS.pop(room, None)


def _ring_owner(c, room, name):
    try:
        _post(c, ".json", {
            "To": c["MY_PHONE"], "From": c["TWILIO_FROM"], "Timeout": 20,
            "Url": _url(c, "/me", room=room, name=name),
            "StatusCallback": _url(c, "/me/status", room=room),
            "StatusCallbackMethod": "POST",
        })
    except Exception as e:
        print("could not call you:", e)
        _decline(c, room)


def h_client(c, p, q):
    room, name = q["room"], q.get("name", "there")[:60]
    with LOCK:
        ROOMS[room] = {"client_sid": p.get("CallSid", ""), "state": "ringing"}
    threading.Thread(target=_ring_owner, args=(c, room, name), daemon=True).start()
    return twiml(
        f"<Say>Hello {escape(name)}. This is Archie, the AI assistant of {escape(c['OWNER'])}. "
        "Please hold for a moment while I connect you.</Say>"
        + CONF.format(start="false", room=room)
    )


def h_me(c, p, q):
    name = q.get("name", "a client")[:60]
    act = escape(_url(c, "/me/choice", room=q["room"]))
    return twiml(
        f'<Gather numDigits="1" timeout="8" method="POST" action="{act}">'
        f"<Say>{escape(name)} is on the other line. Press 1 to take the call, "
        "or 2 to send them to voicemail.</Say></Gather>"
        f'<Redirect method="POST">{act}</Redirect>'
    )


def h_choice(c, p, q):
    room = q["room"]
    if p.get("Digits") == "1":
        with LOCK:
            st = ROOMS.get(room)
            ok = bool(st) and st["state"] == "ringing"
            if ok:
                st["state"] = "connected"
        if ok:
            return twiml("<Say>Connecting you now.</Say>" + CONF.format(start="true", room=room))
        return twiml("<Say>Sorry, that caller is no longer on the line.</Say><Hangup/>")
    threading.Thread(target=_decline, args=(c, room), daemon=True).start()
    return twiml("<Say>Okay. I will let them know.</Say><Hangup/>")


def h_status(c, p, q):
    """Your call ended. If you never accepted, release the client."""
    room = q["room"]
    with LOCK:
        st = ROOMS.get(room)
        if st and st["state"] == "connected":
            ROOMS.pop(room, None)
            return "<Response/>"
    threading.Thread(target=_decline, args=(c, room), daemon=True).start()
    return "<Response/>"


ROUTES = {"/client": h_client, "/me": h_me, "/me/choice": h_choice, "/me/status": h_status}


def signature_ok(token, url, params, header):
    data = url + "".join(k + v for k in sorted(params) for v in sorted(params[k]))
    mac = hmac.new(token.encode(), data.encode(), hashlib.sha1).digest()
    return hmac.compare_digest(base64.b64encode(mac).decode(), header or "")


# ---- two-way conversation by phone (Twilio ConversationRelay) ----------------------------------
# Twilio listens (speech to text), sends each sentence here over a websocket, Archie answers in text, Twilio speaks it.
# Calls from you reach Archie only after your passcode on the keypad; calls Archie places to you need none.
import base64 as _b64
import time
import json as _json


def _tok(c, sid):
    return hmac.new(c["TWILIO_AUTH_TOKEN"].encode(), ("relay:" + sid).encode(), hashlib.sha256).hexdigest()[:32]


def _digits(s):
    return re.sub(r"\D", "", s or "")


def _same_number(a, b):
    return bool(_digits(a)) and _digits(a)[-10:] == _digits(b)[-10:]


def _lang_tag():
    try:
        from . import memory

        return "fr-CA" if memory.get_lang() == "fr" else "en-US"
    except Exception:
        return "en-US"


def _relay_twiml(c, sid, greeting):
    ws = c["PUBLIC_URL"].replace("https://", "wss://", 1).replace("http://", "ws://", 1) + "/relay?" + urlencode({"sid": sid, "k": _tok(c, sid)})
    return twiml(
        '<Connect><ConversationRelay url="' + escape(ws, {'"': "&quot;"}) + '" welcomeGreeting="' + escape(greeting[:300], {'"': "&quot;"})
        + '" language="' + _lang_tag() + '" interruptible="speech" dtmfDetection="false"/></Connect>')


def _greeting(q):
    g = (q.get("g") or "").strip()
    fr = _lang_tag().startswith("fr")
    return g or ("Bonjour, c'est Archie. Comment puis-je vous aider ?" if fr else "Hello, this is Archie. How can I help?")


def h_voice(c, p, q):
    """Twilio asks what to do with a call. Inbound: only from your own number, only after the passcode. Outbound (Archie called you): straight in."""
    fr = _lang_tag().startswith("fr")
    sid = p.get("CallSid", "")
    outbound = (p.get("Direction", "") or "").startswith("outbound")
    if outbound:
        if not _same_number(p.get("To", ""), c["MY_PHONE"]):
            return twiml("<Hangup/>")
        return _relay_twiml(c, sid, _greeting(q))
    pin = _digits(os.environ.get("ARCHIE_PHONE_PIN", ""))
    if not _same_number(p.get("From", ""), c["MY_PHONE"]) or len(pin) < 4:
        return twiml("<Say>" + ("Désolé, ce numéro n'est pas disponible." if fr else "Sorry, this number is not available.") + "</Say><Hangup/>")
    act = escape(_url(c, "/voice/pin"))
    return twiml(f'<Gather numDigits="{len(pin)}" timeout="10" method="POST" action="{act}"><Say>'
                 + ("Bonjour. Entrez votre code." if fr else "Hello. Please enter your passcode.") + "</Say></Gather><Hangup/>")


def h_voice_pin(c, p, q):
    fr = _lang_tag().startswith("fr")
    pin = _digits(os.environ.get("ARCHIE_PHONE_PIN", ""))
    if len(pin) >= 4 and _same_number(p.get("From", ""), c["MY_PHONE"]) and hmac.compare_digest(_digits(p.get("Digits", "")), pin):
        return _relay_twiml(c, p.get("CallSid", ""), _greeting({}))
    return twiml("<Say>" + ("Code incorrect. Au revoir." if fr else "Wrong passcode. Goodbye.") + "</Say><Hangup/>")


def _ws_read(rf):
    h = rf.read(2)
    if len(h) < 2:
        return None, b""
    op, ln, masked = h[0] & 15, h[1] & 127, h[1] & 128
    if ln == 126:
        ln = int.from_bytes(rf.read(2), "big")
    elif ln == 127:
        ln = int.from_bytes(rf.read(8), "big")
    if ln > 1_000_000:
        return None, b""
    mask = rf.read(4) if masked else b""
    data = b""
    while len(data) < ln:
        chunk = rf.read(ln - len(data))
        if not chunk:
            return None, b""
        data += chunk
    if masked:
        data = bytes(b ^ mask[i % 4] for i, b in enumerate(data))
    return op, data


def _ws_send(wf, text, op=1):
    d = text.encode("utf-8") if isinstance(text, str) else text
    n = len(d)
    head = bytes([0x80 | op]) + (bytes([n]) if n < 126 else b"\x7e" + n.to_bytes(2, "big") if n < 65536 else b"\x7f" + n.to_bytes(8, "big"))
    wf.write(head + d)
    wf.flush()


def _speakable(t):
    t = re.sub(r"[*_`#>]+", "", t or "")
    t = re.sub(r"\s+", " ", t).strip()
    return t[:900]


def relay_session(c, rf, wf, answer=None):
    """One phone conversation. `answer(text) -> text` is Archie's brain; passed in for tests."""
    if answer is None:
        from . import assistant

        def answer(text):
            r = assistant.reply(text, channel="phone")
            out = r[0] or ""
            v = r[3] if len(r) > 3 else None
            if isinstance(v, dict) and v.get("type") == "confirm":  # no screen on a call: read out what he is about to approve
                lines = [str(x) for x in (v.get("lines") or []) if str(x).strip() and str(x).strip()[:30] not in out]
                out = out + " " + ". ".join(lines[:3])
            elif isinstance(v, dict) and v.get("type") == "table" and v.get("rows"):
                out = out + " " + ". ".join(" ".join(str(c) for c in row) for row in v["rows"][:4])
            return out
    fr_wait = ["Un instant.", "Je regarde ça."] if _lang_tag().startswith("fr") else ["One moment.", "Let me check."]
    lock = threading.Lock()
    t0 = time.time()
    sent = {"n": 0}

    def say(txt, last=True):
        with lock:
            _ws_send(wf, _json.dumps({"type": "text", "token": txt, "last": last}))

    def work(text):
        done = threading.Event()

        def filler():
            if not done.wait(3.2):
                say(fr_wait[sent["n"] % 2] + " ", last=False)
                sent["n"] += 1
        threading.Thread(target=filler, daemon=True).start()
        try:
            out = _speakable(answer(text)) or ("Je n'ai pas de réponse." if _lang_tag().startswith("fr") else "I have no answer to that.")
        except BaseException:
            out = "Désolé, une erreur est survenue." if _lang_tag().startswith("fr") else "Sorry, something went wrong."
        done.set()
        say(out)

    while time.time() - t0 < 1200:
        op, data = _ws_read(rf)
        if op is None or op == 8:
            break
        if op == 9:
            with lock:
                _ws_send(wf, data, op=10)
            continue
        if op != 1:
            continue
        try:
            m = _json.loads(data.decode("utf-8", "replace"))
        except Exception:
            continue
        if m.get("type") == "prompt" and m.get("last", True) and str(m.get("voicePrompt", "")).strip():
            threading.Thread(target=work, args=(str(m["voicePrompt"])[:1000],), daemon=True).start()
    try:
        _ws_send(wf, b"", op=8)
    except Exception:
        pass


RELAY_ANSWER = [None]


def make_server(c, port):
    class Handler(BaseHTTPRequestHandler):
        def log_message(self, *a):
            pass

        def do_GET(self):
            path, _, qs = self.path.partition("?")
            q = {k: v[0] for k, v in parse_qs(qs).items()}
            if path == "/relay" and (self.headers.get("Upgrade", "").lower() == "websocket"):
                sid, k = q.get("sid", ""), q.get("k", "")
                if not sid or not hmac.compare_digest(k, _tok(c, sid)):
                    return self.send_error(403)
                key = self.headers.get("Sec-WebSocket-Key", "")
                acc = _b64.b64encode(hashlib.sha1((key + "258EAFA5-E914-47DA-95CA-C5AB0DC85B11").encode()).digest()).decode()
                self.send_response(101, "Switching Protocols")
                self.send_header("Upgrade", "websocket")
                self.send_header("Connection", "Upgrade")
                self.send_header("Sec-WebSocket-Accept", acc)
                self.end_headers()
                self.close_connection = True
                try:
                    self.connection.settimeout(1300)
                    relay_session(c, self.rfile, self.wfile, RELAY_ANSWER[0])
                except Exception:
                    pass
                return
            self.send_error(404)

        def do_POST(self):
            n = int(self.headers.get("Content-Length") or 0)
            params = parse_qs(self.rfile.read(n).decode("utf-8"), keep_blank_values=True)
            if not signature_ok(c["TWILIO_AUTH_TOKEN"], c["PUBLIC_URL"] + self.path, params,
                                self.headers.get("X-Twilio-Signature")):
                return self.send_error(403)
            path, _, qs = self.path.partition("?")
            q = {k: v[0] for k, v in parse_qs(qs).items()}
            route = ROUTES.get(path)
            if path in ("/voice", "/voice/pin"):
                body = (h_voice if path == "/voice" else h_voice_pin)(c, {k: v[0] for k, v in params.items()}, q).encode()
                self.send_response(200)
                self.send_header("Content-Type", "text/xml")
                self.send_header("Content-Length", str(len(body)))
                self.end_headers()
                return self.wfile.write(body)
            if not route or not ROOM_RE.fullmatch(q.get("room", "")):
                return self.send_error(404)
            body = route(c, {k: v[0] for k, v in params.items()}, q).encode()
            self.send_response(200)
            self.send_header("Content-Type", "text/xml")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    return ThreadingHTTPServer(("127.0.0.1", port), Handler)


def serve(port=8080):
    c = cfg()
    print(f"Listening on 127.0.0.1:{port}. Your tunnel must forward {c['PUBLIC_URL']} here.")
    make_server(c, port).serve_forever()
