"""Settings entered in the app itself (gear button), kept in archie-config.json on this PC and applied at once.
Passwords are typed by the owner in the app: they are never shown again, only "saved"."""
import json
import os
import re
import subprocess
from pathlib import Path

PATH = Path("archie-config.json")
ROOT = Path(__file__).resolve().parent.parent
# key, label, secret, section, hint
FIELDS = [
    ("OWNER_NAME", "Votre nom (comme Archie signe vos courriels)", False, "Général", ""),
    ("ARCHIE_LLM_KEY", "Clé Claude (commence par sk-ant-)", True, "Intelligence", "console.anthropic.com → API keys → Create key"),
    ("ARCHIE_LLM_MODEL", "Modèle (vide = automatique : rapide, plus fin seulement si la question l'exige)", False, "Intelligence", "Laissez vide pour le choix automatique, ou écrivez par exemple claude-sonnet-5-5 pour imposer un modèle"),
    ("ARCHIE_OPUS_BELOW", "Le modèle le plus fin (Opus) seulement tant que la dépense du mois est sous ce pourcentage du plafond (défaut 40)", False, "Intelligence", "Nécessite un plafond mensuel"),
    ("ARCHIE_RESEARCH_NEW", "Chercher sur le web les nouveaux contacts (écrivez non pour désactiver)", False, "Téléphone", "À la première prise de contact Archie cherche l'entreprise de l'expéditeur. Il ne vous appelle que si cela ressemble à un gros contrat ET que le message est urgent"),
    ("ARCHIE_VIP_LABEL", "Comment appeler vos clients importants (ex. client prioritaire, client clé)", False, "Téléphone", "Ce mot est utilisé partout par Archie. Laissez vide pour « client prioritaire »"),
    ("ARCHIE_MONTHLY_CAP", "Plafond mensuel de l'intelligence, en dollars (ex. 15)", False, "Intelligence", "À 80 % Archie avertit, à 100 % il passe au modèle économique, à 150 % il se met en pause jusqu'au mois suivant"),
    ("ARCHIE_UPDATE_URL", "Adresse des mises à jour (donnée par AnchorLine)", False, "Mises à jour", "Archie vérifie seul s'il y a une nouvelle version signée"),
    ("ARCHIE_AUTO_UPDATE", "Installer seul les mises à jour au moment calme ? (oui ou non)", False, "Mises à jour", "Non : Archie demande d'abord. Oui : il met à jour quand vous ne l'utilisez pas"),
    ("ARCHIE_SHARE_FEEDBACK", "Partager des signalements anonymes d'erreurs générales avec AnchorLine ? (oui ou non)", False, "Confidentialité", "Jamais vos courriels, agenda, fichiers, contacts ni préférences. Vous approuvez chaque signalement avant l'envoi"),
    ("ARCHIE_FEEDBACK_URL", "Adresse des signalements (donnée par AnchorLine)", False, "Confidentialité", ""),
    ("MAIL_USER", "Adresse courriel", False, "Courriel", "Gmail, Outlook.com, iCloud, Yahoo"),
    ("MAIL_APP_PASSWORD", "Mot de passe d'application du courriel", True, "Courriel", "Pas votre mot de passe normal : un mot de passe d'application"),
    ("MS_CLIENT_ID", "Outlook : identifiant d'application Microsoft (pas un mot de passe)", False, "Courriel Outlook / Microsoft 365", "portal.azure.com → Inscriptions d'applications → ID d'application (client)"),
    ("ICLOUD_USER", "Identifiant Apple (courriel iCloud)", False, "Agenda iCloud", ""),
    ("ICLOUD_CALENDAR", "Nom de l'agenda à utiliser (facultatif)", False, "Agenda iCloud", "Laissez vide pour l'agenda principal"),
    ("ICLOUD_APP_PASSWORD", "Mot de passe d'application Apple (abcd-efgh-ijkl-mnop)", True, "Agenda iCloud", "appleid.apple.com → Connexion et sécurité → Mots de passe d'app"),
    ("TWILIO_ACCOUNT_SID", "Twilio Account SID (commence par AC)", False, "Téléphone", "twilio.com → tableau de bord"),
    ("TWILIO_AUTH_TOKEN", "Twilio Auth Token", True, "Téléphone", ""),
    ("TWILIO_FROM", "Numéro Twilio (+1...)", False, "Téléphone", ""),
    ("ARCHIE_PHONE_PIN", "Code à chiffres pour vous identifier quand VOUS appelez Archie (4 à 8 chiffres)", True, "Téléphone", "Sans ce code, les appels entrants sont refusés"),
    ("ARCHIE_SMS_TOKEN", "Code secret pour lire les textos de l'iPhone (12 caractères ou plus)", True, "Téléphone", "Inventez un long code; il sert aussi dans le raccourci de l'iPhone"),
    ("ARCHIE_SMS_PORT", "Port pour les textos de l'iPhone (défaut 8766)", False, "Téléphone", ""),
    ("MY_PHONE", "Votre cellulaire (+1...)", False, "Téléphone", "Archie vous appelle et vous texte à ce numéro"),
    ("AZURE_SPEECH_KEY", "Voix payante Azure : clé Speech", True, "Voix", "portal.azure.com → Speech → Clés et point de terminaison. Licence commerciale : à utiliser avant de vendre"),
    ("AZURE_SPEECH_REGION", "Voix payante Azure : région (ex. canadacentral)", False, "Voix", ""),
    ("ELEVENLABS_KEY", "Voix payante ElevenLabs : clé API (si vous n'utilisez pas Azure)", True, "Voix", "elevenlabs.io → Profil → API keys"),
    ("ELEVENLABS_VOICE_ID", "Voix payante ElevenLabs : identifiant de la voix", False, "Voix", "elevenlabs.io → Voices → ID de la voix choisie"),
    ("PUBLIC_URL", "Adresse publique (seulement pour appeler des clients)", False, "Téléphone", "Facultatif"),
]
KEYS = {f[0] for f in FIELDS}


def _read():
    try:
        return json.loads(PATH.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def load_into_env():
    """Called at start-up: what was entered in the app wins over anything older."""
    for k, v in _read().items():
        if k in KEYS and v:
            os.environ[k] = v
    os.environ.setdefault("ARCHIE_LLM_URL", "https://api.anthropic.com")
    if os.environ.get("ARCHIE_LLM_KEY") and not os.environ.get("ARCHIE_LLM_URL", "").startswith("http"):
        os.environ["ARCHIE_LLM_URL"] = "https://api.anthropic.com"


def _clean(k, v):
    v = (v or "").strip().strip('"\'')
    if k in ("MAIL_APP_PASSWORD", "ICLOUD_APP_PASSWORD"):
        v = v.replace(" ", "")
    if k in ("TWILIO_FROM", "MY_PHONE") and v:
        v = re.sub(r"[ ()\-.]", "", v)
        if not re.fullmatch(r"\+\d{8,15}", v):
            raise ValueError("Le numéro doit ressembler à +15145551234")
    if k == "ARCHIE_LLM_KEY" and v and not v.startswith("sk-ant-"):
        raise ValueError("La clé Claude commence par sk-ant-")
    if k in ("MAIL_USER", "ICLOUD_USER") and v and "@" not in v:
        raise ValueError("Il faut une adresse courriel")
    if k == "ARCHIE_UPDATE_URL" and v and not (v.startswith("https://") or v.startswith("http://127.0.0.1")):
        raise ValueError("L'adresse des mises à jour commence par https://")
    if k == "ARCHIE_SHARE_FEEDBACK" and v and v.lower() not in ("oui", "non", "yes", "no"):
        raise ValueError("Écrivez oui ou non")
    if k == "ARCHIE_FEEDBACK_URL" and v and not v.startswith("https://"):
        raise ValueError("L'adresse des signalements commence par https://")
    if k == "ARCHIE_AUTO_UPDATE" and v and v.lower() not in ("oui", "non", "yes", "no"):
        raise ValueError("Écrivez oui ou non")
    if k == "ARCHIE_VIP_LABEL" and v and not re.fullmatch(r"[\w' \-éèêàçùôîïÉÈ]{2,30}", v.strip()):
        raise ValueError("Un mot ou deux, 30 lettres au plus (ex. client clé)")
    if k == "ARCHIE_MONTHLY_CAP" and v:
        try:
            if float(v.replace(",", ".").replace("$", "").strip()) < 0:
                raise ValueError
        except ValueError:
            raise ValueError("Le plafond est un nombre de dollars (ex. 15), ou vide pour aucun plafond")
    if k == "ARCHIE_LLM_MODEL" and v and not v.lower().startswith("claude"):
        raise ValueError("Le modèle commence par claude (ex. claude-haiku-5-5)")
    return v


def save(values, lang="fr"):
    """values: {KEY: text}. Empty text means 'keep what is saved'. Returns the status."""
    cur = _read()
    for k, v in (values or {}).items():
        if k in KEYS and v is not None and str(v).strip():
            try:
                cur[k] = _clean(k, str(v))
            except ValueError as e:
                from . import i18n

                raise ValueError(i18n.err(str(e), lang))
    PATH.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
    load_into_env()
    return status(lang)


def clear(key):
    cur = _read()
    cur.pop(key, None)
    PATH.write_text(json.dumps(cur, ensure_ascii=False, indent=1), encoding="utf-8")
    os.environ.pop(key, None)


def status(lang="fr"):
    cur = _read()
    out = []
    from . import tier

    phone_on = tier.phone_ok()
    for k, label, secret, section, hint in FIELDS:
        if section == "Téléphone" and not phone_on:
            continue  # the Base version has no phone
        v = cur.get(k) or os.environ.get(k, "")
        from . import i18n

        lb, hn = i18n.field(k, label, hint, lang)
        out.append({"key": k, "label": lb, "secret": secret, "section": i18n.section(section, lang), "hint": hn, "set": bool(v),
                    "value": "" if secret else v})
    return out


def _lnk():
    return Path(os.environ.get("APPDATA", "")) / "Microsoft" / "Windows" / "Start Menu" / "Programs" / "Startup" / "Archie.lnk"


def autostart_state():
    return os.name == "nt" and _lnk().exists()


def set_autostart(on):
    if os.name != "nt":
        return False
    if on:
        bat = str(ROOT / "open-archie-app.bat")
        ps = ("$s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Startup')+'\\Archie.lnk');"
              f"$s.TargetPath='wscript.exe';$s.Arguments='//nologo archie-hidden.vbs';$s.WorkingDirectory='{ROOT}';$s.IconLocation='{ROOT / 'archie' / 'ui' / 'archie.ico'}';$s.WindowStyle=7;$s.Save()")
        subprocess.run(["powershell", "-NoProfile", "-Command", ps], check=True, timeout=30)
    else:
        try:
            _lnk().unlink()
        except OSError:
            pass
    return autostart_state()
